/**
 * Copyright (c) 2026 Enzien Audio, Ltd.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions, and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the phrase "powered by heavy",
 *    the heavy logo, and a hyperlink to https://enzienaudio.com, all in a visible
 *    form.
 * 
 *   2.1 If the Application is distributed in a store system (for example,
 *       the Apple "App Store" or "Google Play"), the phrase "powered by heavy"
 *       shall be included in the app description or the copyright text as well as
 *       the in the app itself. The heavy logo will shall be visible in the app
 *       itself as well.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */

#ifndef _HEAVY_EQVU_H_
#define _HEAVY_EQVU_H_

#include "HvHeavy.h"

#ifdef __cplusplus
extern "C" {
#endif

#if HV_APPLE
#pragma mark - Heavy Context
#endif

typedef enum {
  HV_EQVU_PARAM_IN__10_QLMF2_F = 0x1D24AC9F, // _10_QLMF2_f
  HV_EQVU_PARAM_IN__11_QLMF2_F = 0x7194B67C, // _11_QLMF2_f
  HV_EQVU_PARAM_IN__12_DBLMF = 0xB8C98687, // _12_dBLMF
  HV_EQVU_PARAM_IN__13_HZHMF = 0x8451A779, // _13_HzHMF
  HV_EQVU_PARAM_IN__14_QHMF2_F = 0x1D1507D4, // _14_QHMF2_f
  HV_EQVU_PARAM_IN__15_QHMF2_F = 0xF6147049, // _15_QHMF2_f
  HV_EQVU_PARAM_IN__16_DBHMF = 0x6D8F80F2, // _16_dBHMF
  HV_EQVU_PARAM_IN__17_HZHF = 0xE9051A9D, // _17_HzHF
  HV_EQVU_PARAM_IN__18_QHF_F = 0xBFFB11FC, // _18_QHF_f
  HV_EQVU_PARAM_IN__1_INPUT = 0x5A63170A, // _1_INPUT
  HV_EQVU_PARAM_IN__20_DBHF = 0x5E915D93, // _20_dBHF
  HV_EQVU_PARAM_IN__2_DRY = 0x49127601, // _2_DRY
  HV_EQVU_PARAM_IN__3_WET = 0x685033DE, // _3_WET
  HV_EQVU_PARAM_IN__4_OUTPUT = 0xAC813ECB, // _4_OUTPUT
  HV_EQVU_PARAM_IN__5_HZLF = 0x158602FD, // _5_HzLF
  HV_EQVU_PARAM_IN__6_QLF_F = 0xCC4785E3, // _6_QLF_f
  HV_EQVU_PARAM_IN__8_DBLF = 0x9D2964A6, // _8_dBLF
  HV_EQVU_PARAM_IN__9_HZLMF = 0xCD86A9DF, // _9_HzLMF
} Hv_EQVU_ParameterIn;


/**
 * Creates a new patch instance.
 * Sample rate should be positive and in Hertz, e.g. 44100.0.
 */
HeavyContextInterface *hv_EQVU_new(double sampleRate);

/**
 * Creates a new patch instance.
 * @param sampleRate  Sample rate should be positive (> 0) and in Hertz, e.g. 48000.0.
 * @param poolKb  Pool size is in kilobytes, and determines the maximum amount of memory
 *   allocated to messages at any time. By default this is 10 KB.
 * @param inQueueKb  The size of the input message queue in kilobytes. It determines the
 *   amount of memory dedicated to holding scheduled messages between calls to
 *   process(). Default is 2 KB.
 * @param outQueueKb  The size of the output message queue in kilobytes. It determines the
 *   amount of memory dedicated to holding scheduled messages to the default sendHook.
 *   See getNextSentMessage() for info on accessing these messages. Default is 0 KB.
 */
HeavyContextInterface *hv_EQVU_new_with_options(double sampleRate, int poolKb, int inQueueKb, int outQueueKb);

/**
 * Free the patch instance.
 */
void hv_EQVU_free(HeavyContextInterface *instance);


#ifdef __cplusplus
} // extern "C"
#endif

#endif // _HEAVY_EQVU_H_
