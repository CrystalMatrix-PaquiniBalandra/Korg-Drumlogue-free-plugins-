/**
 * Copyright (c) 2026 Enzien Audio, Ltd.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions, and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the phrase "powered by heavy",
 *    the heavy logo, and a hyperlink to https://enzienaudio.com, all in a visible
 *    form.
 * 
 *   2.1 If the Application is distributed in a store system (for example,
 *       the Apple "App Store" or "Google Play"), the phrase "powered by heavy"
 *       shall be included in the app description or the copyright text as well as
 *       the in the app itself. The heavy logo will shall be visible in the app
 *       itself as well.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */

#include "Heavy_EQXG.hpp"

#include <new>

#define Context(_c) static_cast<Heavy_EQXG *>(_c)


/*
 * C Functions
 */

extern "C" {
  HV_EXPORT HeavyContextInterface *hv_EQXG_new(double sampleRate) {
    // allocate aligned memory
    void *ptr = hv_malloc(sizeof(Heavy_EQXG));
    // ensure non-null
    if (!ptr) return nullptr;
    // call constructor
    new(ptr) Heavy_EQXG(sampleRate);
    return Context(ptr);
  }

  HV_EXPORT HeavyContextInterface *hv_EQXG_new_with_options(double sampleRate,
      int poolKb, int inQueueKb, int outQueueKb) {
    // allocate aligned memory
    void *ptr = hv_malloc(sizeof(Heavy_EQXG));
    // ensure non-null
    if (!ptr) return nullptr;
    // call constructor
    new(ptr) Heavy_EQXG(sampleRate, poolKb, inQueueKb, outQueueKb);
    return Context(ptr);
  }

  HV_EXPORT void hv_EQXG_free(HeavyContextInterface *instance) {
    // call destructor
    Context(instance)->~Heavy_EQXG();
    // free memory
    hv_free(instance);
  }
} // extern "C"







/*
 * Class Functions
 */

Heavy_EQXG::Heavy_EQXG(double sampleRate, int poolKb, int inQueueKb, int outQueueKb)
    : HeavyContext(sampleRate, poolKb, inQueueKb, outQueueKb) {
  numBytes += sLine_init(&sLine_a1h8OI0F);
  numBytes += sLine_init(&sLine_iXq9G3dq);
  numBytes += sLine_init(&sLine_J8bo8D5A);
  numBytes += sLine_init(&sLine_nQC9UoFF);
  numBytes += sLine_init(&sLine_Fdgoci8h);
  numBytes += sBiquad_init(&sBiquad_s_Tci8RSJ6);
  numBytes += sLine_init(&sLine_bLFyKYuK);
  numBytes += sLine_init(&sLine_h3r8mTrw);
  numBytes += sLine_init(&sLine_Ht5dOgWg);
  numBytes += sLine_init(&sLine_AryZBwSH);
  numBytes += sLine_init(&sLine_PEKBNvbj);
  numBytes += sBiquad_init(&sBiquad_s_gd8SwpqA);
  numBytes += sLine_init(&sLine_M5MdyXVa);
  numBytes += sLine_init(&sLine_Au4NMxWh);
  numBytes += sLine_init(&sLine_2p9tPAWo);
  numBytes += sLine_init(&sLine_VyxAfLkq);
  numBytes += sLine_init(&sLine_NJMJ9A3T);
  numBytes += sBiquad_init(&sBiquad_s_pd5Vn7tk);
  numBytes += sLine_init(&sLine_nZsHhqQa);
  numBytes += sLine_init(&sLine_XzPyo4Fb);
  numBytes += sLine_init(&sLine_4rPgkFbc);
  numBytes += sLine_init(&sLine_bPD7AoOX);
  numBytes += sLine_init(&sLine_fEPfEfAZ);
  numBytes += sBiquad_init(&sBiquad_s_MgvNYUMf);
  numBytes += sLine_init(&sLine_155H8MeN);
  numBytes += sLine_init(&sLine_qjVZNmDs);
  numBytes += sLine_init(&sLine_maIsr8Jz);
  numBytes += sLine_init(&sLine_A2E1S2eK);
  numBytes += sLine_init(&sLine_YTZ21Ar9);
  numBytes += sBiquad_init(&sBiquad_s_qOAHNAK7);
  numBytes += sLine_init(&sLine_xzYAORI8);
  numBytes += sLine_init(&sLine_jkO3N5Eu);
  numBytes += sLine_init(&sLine_1zbO8QCm);
  numBytes += sLine_init(&sLine_MmTpPFlc);
  numBytes += sLine_init(&sLine_pgDeE4OS);
  numBytes += sBiquad_init(&sBiquad_s_ydhVuJA5);
  numBytes += sLine_init(&sLine_OzcbV3S7);
  numBytes += sLine_init(&sLine_gCEJnBeR);
  numBytes += sLine_init(&sLine_ZckGuuDs);
  numBytes += sLine_init(&sLine_5mGWt5zM);
  numBytes += sLine_init(&sLine_9E0MgvAm);
  numBytes += sBiquad_init(&sBiquad_s_uqPQwIrc);
  numBytes += sLine_init(&sLine_ash1rAvt);
  numBytes += sLine_init(&sLine_DrZuI3C7);
  numBytes += sLine_init(&sLine_21dWG5fr);
  numBytes += sLine_init(&sLine_bmu98AIv);
  numBytes += sLine_init(&sLine_Dg5eZUUB);
  numBytes += sBiquad_init(&sBiquad_s_jmhJ71LR);
  numBytes += cVar_init_f(&cVar_l0We788u, 0.0f);
  numBytes += cVar_init_f(&cVar_3UFyK7Cd, 0.0f);
  numBytes += cVar_init_f(&cVar_V9hQ4Qon, 0.0f);
  numBytes += cVar_init_f(&cVar_7VpUeZAn, 0.0f);
  numBytes += cVar_init_f(&cVar_LZhobZcH, 0.0f);
  numBytes += cVar_init_f(&cVar_0cjZ6r5S, 0.0f);
  numBytes += cVar_init_f(&cVar_JpOdF2Ww, 0.0f);
  numBytes += cVar_init_f(&cVar_6KGdmx3c, 0.0f);
  numBytes += cVar_init_f(&cVar_w4qHAfcN, 0.0f);
  numBytes += cVar_init_f(&cVar_Uk1jXxWe, 0.0f);
  numBytes += cVar_init_f(&cVar_NdC6URMp, 0.0f);
  numBytes += cVar_init_f(&cVar_0OkImWsp, 0.0f);
  numBytes += cVar_init_f(&cVar_vb33XxG3, 0.0f);
  numBytes += cExpr_init(&cExpr_xoRK8LNL, &Heavy_EQXG::cExpr_xoRK8LNL_evaluate);
  numBytes += sVarf_init(&sVarf_7fsqzj0S, 0.0f, 0.0f, false);
  numBytes += sVarf_init(&sVarf_qdb4mxol, 0.0f, 0.0f, false);
  numBytes += cVar_init_f(&cVar_C1CtRy2Y, 0.0f);
  numBytes += cExpr_init(&cExpr_ySWsOjQk, &Heavy_EQXG::cExpr_ySWsOjQk_evaluate);
  numBytes += sVarf_init(&sVarf_8tT1Yfnx, 0.0f, 0.0f, false);
  numBytes += sVarf_init(&sVarf_W0PxtU51, 0.0f, 0.0f, false);
  numBytes += cVar_init_f(&cVar_1ndrvePX, 0.0f);
  numBytes += cVar_init_f(&cVar_PEjDmpB9, 0.0f);
  numBytes += cVar_init_f(&cVar_wQIJM1MH, 0.0f);
  numBytes += cVar_init_f(&cVar_ARDjZI0l, 0.0f);
  numBytes += cVar_init_f(&cVar_Psm43837, 0.0f);
  numBytes += cVar_init_f(&cVar_7AbCdT1a, 0.0f);
  numBytes += cBinop_init(&cBinop_v7wqYbWB, 1.0f); // __pow
  numBytes += cIf_init(&cIf_HUDiI4aA, false);
  numBytes += cBinop_init(&cBinop_J8ZLAt8X, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_wpEsHBj9, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_uUGwglUK, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_PM4CQp96, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_VNRxaa1l, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_gXRwClEW, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_g8o8eFhx, 0.0f); // __pow
  numBytes += cBinop_init(&cBinop_JvDuMT5E, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_dPgrGt8t, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_UehNHBnE, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_dtNVN428, 0.0f); // __add
  numBytes += cBinop_init(&cBinop_yRDlJQg1, 0.0f); // __add
  numBytes += cBinop_init(&cBinop_fFZUUrI4, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_o05VMu73, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_xH7mCNT0, 0.0f); // __add
  numBytes += cBinop_init(&cBinop_k4GjkXFV, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_VxMpyrlh, 0.0f); // __add
  numBytes += cBinop_init(&cBinop_rRXOQ8hI, 0.0f); // __sub
  numBytes += cBinop_init(&cBinop_XraT1NMn, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_kHpbQK7g, 0.0f); // __add
  numBytes += cBinop_init(&cBinop_0JRVcXwh, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_HjKM2nDM, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_8rXCiOU1, 0.0f); // __add
  numBytes += cBinop_init(&cBinop_cyV2XSgh, 0.0f); // __sub
  numBytes += cBinop_init(&cBinop_osOGSw5l, 44100.0f); // __div
  numBytes += cBinop_init(&cBinop_dnm66s8g, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_eeavqtO6, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_C8JVmvqu, 0.0f); // __add
  numBytes += cBinop_init(&cBinop_ussrspm8, 0.0f); // __add
  numBytes += cVar_init_f(&cVar_8wMLcTLv, 0.0f);
  numBytes += cVar_init_f(&cVar_I05JD4SC, 0.0f);
  numBytes += cVar_init_f(&cVar_4cxHS2Wh, 0.0f);
  numBytes += cVar_init_f(&cVar_Jr9kjrrb, 0.0f);
  numBytes += cBinop_init(&cBinop_7LmZhDJ9, 1.0f); // __pow
  numBytes += cIf_init(&cIf_f0QBTFn0, false);
  numBytes += cBinop_init(&cBinop_P6QboYGW, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_VTQ3EVDm, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_Ivf9CXSs, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_NTdHNla3, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_fdGYRU7q, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_eZtjwU8Q, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_adH8WeA3, 0.0f); // __pow
  numBytes += cBinop_init(&cBinop_OWuqk46D, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_3b4D1HCr, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_IDvMPIs3, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_hhpEyFxd, 0.0f); // __add
  numBytes += cBinop_init(&cBinop_8WMx5xhl, 0.0f); // __add
  numBytes += cBinop_init(&cBinop_YMz9wByx, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_bPqLtOHr, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_rMpB5clD, 0.0f); // __add
  numBytes += cBinop_init(&cBinop_FO3qp0XZ, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_LS8f7DkT, 0.0f); // __add
  numBytes += cBinop_init(&cBinop_moK6xZuj, 0.0f); // __sub
  numBytes += cBinop_init(&cBinop_Sa0qkLxo, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_IaQhLkuV, 0.0f); // __add
  numBytes += cBinop_init(&cBinop_KzfnvdkG, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_mJsYp4lP, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_EX3FHxHl, 0.0f); // __add
  numBytes += cBinop_init(&cBinop_wFLksmzi, 0.0f); // __sub
  numBytes += cBinop_init(&cBinop_jmGS1eTI, 44100.0f); // __div
  numBytes += cBinop_init(&cBinop_LWuzZ4NZ, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_5xL3amem, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_I2wcByUj, 0.0f); // __add
  numBytes += cBinop_init(&cBinop_1MbC7QSp, 0.0f); // __add
  numBytes += cVar_init_f(&cVar_35DfO4jz, 0.0f);
  numBytes += cVar_init_f(&cVar_GwROfLTq, 0.0f);
  numBytes += cVar_init_f(&cVar_o2UmZQ3B, 0.0f);
  numBytes += cVar_init_f(&cVar_6sSuUCaK, 0.0f);
  numBytes += cBinop_init(&cBinop_Bvu0xRQp, 1.0f); // __pow
  numBytes += cIf_init(&cIf_NKBBx3XR, false);
  numBytes += cBinop_init(&cBinop_xmME8jTe, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_3COGahD8, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_3GNEhJf2, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_HVPzfaUi, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_2U2pXZHn, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_htrqCgtS, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_48yPb4h5, 0.0f); // __pow
  numBytes += cBinop_init(&cBinop_NlYBg7Pj, 0.0f); // __div
  numBytes += cBinop_init(&cBinop_IB6CgVD7, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_uOVRzxpw, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_MZBVtj6N, 0.0f); // __div
  numBytes += cBinop_init(&cBinop_pZiSmF00, 44100.0f); // __div
  numBytes += cBinop_init(&cBinop_TDFMrtJw, 0.0f); // __mul
  numBytes += cVar_init_f(&cVar_l7nXL7ZP, 0.0f);
  numBytes += cVar_init_f(&cVar_OUgR2NC5, 0.0f);
  numBytes += cVar_init_f(&cVar_7obNbeKG, 0.0f);
  numBytes += cVar_init_f(&cVar_o7F4NWbG, 0.0f);
  numBytes += cBinop_init(&cBinop_h6rxrDWX, 1.0f); // __pow
  numBytes += cIf_init(&cIf_7n3CLJFM, false);
  numBytes += cBinop_init(&cBinop_XDkxgdjQ, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_lzqROrgU, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_PYGGk0OX, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_U3JFXviw, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_qOciTCFL, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_9mIcSLgc, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_ldE2pCmW, 0.0f); // __pow
  numBytes += cBinop_init(&cBinop_itEJDUYw, 0.0f); // __div
  numBytes += cBinop_init(&cBinop_r55bYmbR, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_JYbyacpz, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_hmoiiBdj, 0.0f); // __div
  numBytes += cBinop_init(&cBinop_EvLwhReo, 44100.0f); // __div
  numBytes += cBinop_init(&cBinop_JINScce4, 0.0f); // __mul
  numBytes += cVar_init_f(&cVar_9lVWR3ub, 0.0f);
  numBytes += cVar_init_f(&cVar_ataxigwR, 0.0f);
  numBytes += cVar_init_f(&cVar_nFgkWlTx, 0.0f);
  numBytes += cVar_init_f(&cVar_5uRrxHzu, 0.0f);
  numBytes += cBinop_init(&cBinop_P9sNnmtu, 1.0f); // __pow
  numBytes += cIf_init(&cIf_Y8FoNwRx, false);
  numBytes += cBinop_init(&cBinop_mjHowSRL, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_gQjQQ4vr, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_S8dbcGF7, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_0uuG5uaQ, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_bmaov9yu, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_hhBJdOfJ, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_RjfE78Zb, 0.0f); // __pow
  numBytes += cBinop_init(&cBinop_EWh7MO26, 0.0f); // __div
  numBytes += cBinop_init(&cBinop_cB30ZWhk, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_7GnztpIl, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_Hmhup659, 0.0f); // __div
  numBytes += cBinop_init(&cBinop_xbPFE0iT, 44100.0f); // __div
  numBytes += cBinop_init(&cBinop_zWwIMay1, 0.0f); // __mul
  numBytes += cVar_init_f(&cVar_W4LGt2tX, 0.0f);
  numBytes += cVar_init_f(&cVar_eMQnRg9A, 0.0f);
  numBytes += cVar_init_f(&cVar_5pDdUbg2, 0.0f);
  numBytes += cVar_init_f(&cVar_liIWQIbN, 0.0f);
  numBytes += cBinop_init(&cBinop_cEu8ec9A, 1.0f); // __pow
  numBytes += cIf_init(&cIf_msvaJsMd, false);
  numBytes += cBinop_init(&cBinop_Y4ATJTUd, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_7jmnwMCy, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_7vZweQM2, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_8Ndd3DW3, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_HhibIAMp, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_ey7rSAFu, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_FX0VI0Uu, 0.0f); // __pow
  numBytes += cBinop_init(&cBinop_ZEZyewg4, 0.0f); // __div
  numBytes += cBinop_init(&cBinop_Q5YynIRf, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_tJF0Nuw7, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_mTtPPXQl, 0.0f); // __div
  numBytes += cBinop_init(&cBinop_lde22gjG, 44100.0f); // __div
  numBytes += cBinop_init(&cBinop_52uWYgrv, 0.0f); // __mul
  numBytes += cVar_init_f(&cVar_M3oQp4Ve, 0.0f);
  numBytes += cVar_init_f(&cVar_SHJb5Ynb, 0.0f);
  numBytes += cVar_init_f(&cVar_wJEHGN67, 0.0f);
  numBytes += cVar_init_f(&cVar_EFcqmf1S, 0.0f);
  numBytes += cBinop_init(&cBinop_VwIhOZJu, 1.0f); // __pow
  numBytes += cIf_init(&cIf_hPxtjKuy, false);
  numBytes += cBinop_init(&cBinop_fN3enji8, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_ThndDvab, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_YGfCiaYk, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_FYmNLWuE, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_52nxqyyV, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_XJe9QmCK, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_i4Nlf9D8, 0.0f); // __pow
  numBytes += cBinop_init(&cBinop_WJqwwhtg, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_726lQ9WK, 44100.0f); // __div
  numBytes += cBinop_init(&cBinop_KO2uv9Fi, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_tf9PBytf, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_fkYtbevu, 0.0f); // __add
  numBytes += cBinop_init(&cBinop_nAzcy9pH, 0.0f); // __add
  numBytes += cBinop_init(&cBinop_vR2m7Zgi, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_13JXjWfK, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_Nln7hMTr, 0.0f); // __add
  numBytes += cBinop_init(&cBinop_zllYAxK9, 0.0f); // __add
  numBytes += cBinop_init(&cBinop_D00TzFPJ, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_0FLQ2YKl, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_GMGVSidx, 0.0f); // __add
  numBytes += cBinop_init(&cBinop_F5Z7lB8D, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_0bzDLlAS, 0.0f); // __add
  numBytes += cBinop_init(&cBinop_XwQmnbq4, 0.0f); // __sub
  numBytes += cBinop_init(&cBinop_WULOXzmB, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_XeK9sjnq, 0.0f); // __add
  numBytes += cBinop_init(&cBinop_i7cOWIzw, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_PKqQbfjY, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_GpBW1SB8, 0.0f); // __add
  numBytes += cBinop_init(&cBinop_XUhMlWKg, 0.0f); // __sub
  numBytes += cVar_init_f(&cVar_RFDk3Fcc, 0.0f);
  numBytes += cVar_init_f(&cVar_IbwJ1A2I, 0.0f);
  numBytes += cVar_init_f(&cVar_F3oBGzNB, 0.0f);
  numBytes += cVar_init_f(&cVar_aJK8Z7Zx, 0.0f);
  numBytes += cBinop_init(&cBinop_sKjq2O7D, 1.0f); // __pow
  numBytes += cIf_init(&cIf_0QrFuHq1, false);
  numBytes += cBinop_init(&cBinop_PeWNsROi, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_0uBhdAT2, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_xLKz4gsf, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_PAKkz2sB, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_npXMRj4V, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_JSHQxc1D, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_A4Ky0zBO, 0.0f); // __pow
  numBytes += cBinop_init(&cBinop_YHWEnaKF, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_OMxLiEzC, 44100.0f); // __div
  numBytes += cBinop_init(&cBinop_szOx6k8q, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_PDa1hSnp, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_c0iBPaVV, 0.0f); // __add
  numBytes += cBinop_init(&cBinop_svft0jJU, 0.0f); // __add
  numBytes += cBinop_init(&cBinop_DV2iIsRs, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_3eI1PbLG, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_dQe8j2Ro, 0.0f); // __add
  numBytes += cBinop_init(&cBinop_fNox5GFo, 0.0f); // __add
  numBytes += cBinop_init(&cBinop_RHySeYtN, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_fT7eVLpo, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_loZzczJH, 0.0f); // __add
  numBytes += cBinop_init(&cBinop_RQxBgPhx, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_CvFRt24M, 0.0f); // __add
  numBytes += cBinop_init(&cBinop_xVUbs3aG, 0.0f); // __sub
  numBytes += cBinop_init(&cBinop_5ZIb5bXT, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_Q1GuReFw, 0.0f); // __add
  numBytes += cBinop_init(&cBinop_cbtP7agn, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_btEpF8I6, 0.0f); // __mul
  numBytes += cBinop_init(&cBinop_wkTxKhXH, 0.0f); // __add
  numBytes += cBinop_init(&cBinop_o3TKnGQP, 0.0f); // __sub
  numBytes += sVarf_init(&sVarf_auxpCdpT, 0.0f, 0.0f, false);
  numBytes += sVarf_init(&sVarf_IO2nLrVI, 0.0f, 0.0f, false);
  numBytes += cExpr_init(&cExpr_ACaiVDZs, &Heavy_EQXG::cExpr_ACaiVDZs_evaluate);
  numBytes += sVarf_init(&sVarf_C4FV78so, 0.0f, 0.0f, false);
  numBytes += sVarf_init(&sVarf_52RZEkY8, 0.0f, 0.0f, false);
  numBytes += cExpr_init(&cExpr_rGnQ6PCJ, &Heavy_EQXG::cExpr_rGnQ6PCJ_evaluate);
  numBytes += cVar_init_f(&cVar_ArBpLlYR, 0.0f);
  numBytes += cVar_init_f(&cVar_ZdOguBOi, 0.0f);
  
  // schedule a message to trigger all loadbangs via the __hv_init receiver
  scheduleMessageForReceiver(0xCE5CC65B, msg_initWithBang(HV_MESSAGE_ON_STACK(1), 0));
}

Heavy_EQXG::~Heavy_EQXG() {
  cExpr_free(&cExpr_xoRK8LNL);
  cExpr_free(&cExpr_ySWsOjQk);
  cExpr_free(&cExpr_ACaiVDZs);
  cExpr_free(&cExpr_rGnQ6PCJ);
}

HvTable *Heavy_EQXG::getTableForHash(hv_uint32_t tableHash) {
  return nullptr;
}

void Heavy_EQXG::scheduleMessageForReceiver(hv_uint32_t receiverHash, HvMessage *m) {
  switch (receiverHash) {
    case 0x6C094A05: { // 1001-wsin
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_sETn01qM_sendMessage);
      break;
    }
    case 0xFF8E6281: { // _10_QLMF_f
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_vIcGdniV_sendMessage);
      break;
    }
    case 0x37A5C60F: { // _11_HzLMF
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_UinlIhJL_sendMessage);
      break;
    }
    case 0xD21C13A: { // _12_HzLMF2
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_WYIQQJvS_sendMessage);
      break;
    }
    case 0x98569D43: { // _13_dBHMF
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_T8uOsa4p_sendMessage);
      break;
    }
    case 0x5B350C53: { // _14_QHMF_f
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_HLJOjE3V_sendMessage);
      break;
    }
    case 0x53BB4812: { // _15_HzHMF
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_KINERtMe_sendMessage);
      break;
    }
    case 0x5A37DAD4: { // _16_HzHMF2
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_AR0E0n41_sendMessage);
      break;
    }
    case 0x24953B24: { // _17_dBHF
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_kLoG54H5_sendMessage);
      break;
    }
    case 0x4C756476: { // _19_QHF_f
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_ymQeFfZQ_sendMessage);
      break;
    }
    case 0x5A63170A: { // _1_INPUT
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_Nhj9GLBN_sendMessage);
      break;
    }
    case 0x169C2AB2: { // _20_HzHF
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_1EFEUnSY_sendMessage);
      break;
    }
    case 0x49127601: { // _2_DRY
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_vh5cTuVK_sendMessage);
      break;
    }
    case 0x685033DE: { // _3_WET
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_Mmt0bjH7_sendMessage);
      break;
    }
    case 0xAC813ECB: { // _4_OUTPUT
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_grhiBA9v_sendMessage);
      break;
    }
    case 0x22D96F77: { // _5_dBLF
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_OFDmCy9C_sendMessage);
      break;
    }
    case 0xBFBBD1AA: { // _7_QLF_f
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_dwuZER69_sendMessage);
      break;
    }
    case 0xA539E829: { // _8_HzLF
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_YycZaRiu_sendMessage);
      break;
    }
    case 0xBD14ABDA: { // _9_dBLMF
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_P3ajtPLY_sendMessage);
      break;
    }
    case 0xCE5CC65B: { // __hv_init
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_5TU0b4z2_sendMessage);
      break;
    }
    default: return;
  }
}

int Heavy_EQXG::getParameterInfo(int index, HvParameterInfo *info) {
  if (info != nullptr) {
    switch (index) {
      case 0: {
        info->name = "_10_QLMF_f";
        info->hash = 0xFF8E6281;
        info->type = HvParameterType::HV_PARAM_TYPE_PARAMETER_IN;
        info->minVal = 0.1f;
        info->maxVal = 3.671f;
        info->defaultVal = 0.707f;
        break;
      }
      case 1: {
        info->name = "_11_HzLMF";
        info->hash = 0x37A5C60F;
        info->type = HvParameterType::HV_PARAM_TYPE_PARAMETER_IN;
        info->minVal = 200.0f;
        info->maxVal = 2500.0f;
        info->defaultVal = 700.0f;
        break;
      }
      case 2: {
        info->name = "_12_HzLMF2";
        info->hash = 0xD21C13A;
        info->type = HvParameterType::HV_PARAM_TYPE_PARAMETER_IN;
        info->minVal = 65.0f;
        info->maxVal = 830.0f;
        info->defaultVal = 700.0f;
        break;
      }
      case 3: {
        info->name = "_13_dBHMF";
        info->hash = 0x98569D43;
        info->type = HvParameterType::HV_PARAM_TYPE_PARAMETER_IN;
        info->minVal = -15.0f;
        info->maxVal = 15.0f;
        info->defaultVal = 0.0f;
        break;
      }
      case 4: {
        info->name = "_14_QHMF_f";
        info->hash = 0x5B350C53;
        info->type = HvParameterType::HV_PARAM_TYPE_PARAMETER_IN;
        info->minVal = 0.1f;
        info->maxVal = 3.671f;
        info->defaultVal = 0.707f;
        break;
      }
      case 5: {
        info->name = "_15_HzHMF";
        info->hash = 0x53BB4812;
        info->type = HvParameterType::HV_PARAM_TYPE_PARAMETER_IN;
        info->minVal = 600.0f;
        info->maxVal = 7000.0f;
        info->defaultVal = 2500.0f;
        break;
      }
      case 6: {
        info->name = "_16_HzHMF2";
        info->hash = 0x5A37DAD4;
        info->type = HvParameterType::HV_PARAM_TYPE_PARAMETER_IN;
        info->minVal = 1800.0f;
        info->maxVal = 21000.0f;
        info->defaultVal = 2500.0f;
        break;
      }
      case 7: {
        info->name = "_17_dBHF";
        info->hash = 0x24953B24;
        info->type = HvParameterType::HV_PARAM_TYPE_PARAMETER_IN;
        info->minVal = -15.0f;
        info->maxVal = 15.0f;
        info->defaultVal = 0.0f;
        break;
      }
      case 8: {
        info->name = "_19_QHF_f";
        info->hash = 0x4C756476;
        info->type = HvParameterType::HV_PARAM_TYPE_PARAMETER_IN;
        info->minVal = 0.707f;
        info->maxVal = 1.207f;
        info->defaultVal = 0.707f;
        break;
      }
      case 9: {
        info->name = "_1_INPUT";
        info->hash = 0x5A63170A;
        info->type = HvParameterType::HV_PARAM_TYPE_PARAMETER_IN;
        info->minVal = -20.0f;
        info->maxVal = 20.0f;
        info->defaultVal = 0.0f;
        break;
      }
      case 10: {
        info->name = "_20_HzHF";
        info->hash = 0x169C2AB2;
        info->type = HvParameterType::HV_PARAM_TYPE_PARAMETER_IN;
        info->minVal = 1500.0f;
        info->maxVal = 16000.0f;
        info->defaultVal = 10000.0f;
        break;
      }
      case 11: {
        info->name = "_2_DRY";
        info->hash = 0x49127601;
        info->type = HvParameterType::HV_PARAM_TYPE_PARAMETER_IN;
        info->minVal = 0.0f;
        info->maxVal = 10.0f;
        info->defaultVal = 0.0f;
        break;
      }
      case 12: {
        info->name = "_3_WET";
        info->hash = 0x685033DE;
        info->type = HvParameterType::HV_PARAM_TYPE_PARAMETER_IN;
        info->minVal = 0.0f;
        info->maxVal = 10.0f;
        info->defaultVal = 10.0f;
        break;
      }
      case 13: {
        info->name = "_4_OUTPUT";
        info->hash = 0xAC813ECB;
        info->type = HvParameterType::HV_PARAM_TYPE_PARAMETER_IN;
        info->minVal = -20.0f;
        info->maxVal = 20.0f;
        info->defaultVal = 0.0f;
        break;
      }
      case 14: {
        info->name = "_5_dBLF";
        info->hash = 0x22D96F77;
        info->type = HvParameterType::HV_PARAM_TYPE_PARAMETER_IN;
        info->minVal = -15.0f;
        info->maxVal = 15.0f;
        info->defaultVal = 0.0f;
        break;
      }
      case 15: {
        info->name = "_7_QLF_f";
        info->hash = 0xBFBBD1AA;
        info->type = HvParameterType::HV_PARAM_TYPE_PARAMETER_IN;
        info->minVal = 0.607f;
        info->maxVal = 1.107f;
        info->defaultVal = 0.707f;
        break;
      }
      case 16: {
        info->name = "_8_HzLF";
        info->hash = 0xA539E829;
        info->type = HvParameterType::HV_PARAM_TYPE_PARAMETER_IN;
        info->minVal = 30.0f;
        info->maxVal = 450.0f;
        info->defaultVal = 100.0f;
        break;
      }
      case 17: {
        info->name = "_9_dBLMF";
        info->hash = 0xBD14ABDA;
        info->type = HvParameterType::HV_PARAM_TYPE_PARAMETER_IN;
        info->minVal = -15.0f;
        info->maxVal = 15.0f;
        info->defaultVal = 0.0f;
        break;
      }
      default: {
        info->name = "invalid parameter index";
        info->hash = 0;
        info->type = HvParameterType::HV_PARAM_TYPE_PARAMETER_IN;
        info->minVal = 0.0f;
        info->maxVal = 0.0f;
        info->defaultVal = 0.0f;
        break;
      }
    }
  }
  return 18;
}



/*
 * Send Function Implementations
 */


void Heavy_EQXG::cVar_l0We788u_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_GhJHMk0L_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_ygYBBM11_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_fkxPdjyQ_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_rCdcKyCY_sendMessage);
}

void Heavy_EQXG::cVar_3UFyK7Cd_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 2.0f, 0, m, &cBinop_rIH3KrHO_sendMessage);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 2.0f, 0, m, &cBinop_hfoClX9T_sendMessage);
}

void Heavy_EQXG::cVar_V9hQ4Qon_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_OH06B7x4_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_MXmb8Lcr_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_JyuUlu5f_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_zLQNpwPP_sendMessage);
}

void Heavy_EQXG::cVar_7VpUeZAn_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_qJGdv7wZ_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_ujGtMhWa_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_XvW8K2u5_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_hdl2TR08_sendMessage);
}

void Heavy_EQXG::cVar_LZhobZcH_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 2.0f, 0, m, &cBinop_CZAuGODj_sendMessage);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 2.0f, 0, m, &cBinop_2na66f76_sendMessage);
}

void Heavy_EQXG::cVar_0cjZ6r5S_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_mOFOfYY3_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_zyXRzaXH_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_5CfWRX4K_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_EE5vDQyY_sendMessage);
}

void Heavy_EQXG::cVar_JpOdF2Ww_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_LXyLdGKE_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_eS7RKjkt_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_smlZreZr_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_TOzaZisJ_sendMessage);
}

void Heavy_EQXG::cVar_6KGdmx3c_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 2.0f, 0, m, &cBinop_VpiPV1Gd_sendMessage);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 2.0f, 0, m, &cBinop_2uGGQO98_sendMessage);
}

void Heavy_EQXG::cVar_w4qHAfcN_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_YteJvDxa_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_w9HHDPpp_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_c2Z9k4Gt_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_AWqBnvlH_sendMessage);
}

void Heavy_EQXG::cVar_Uk1jXxWe_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_hf67HOhZ_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_cKUHE21O_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_4epP6vZs_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_XwFw5ZMu_sendMessage);
}

void Heavy_EQXG::cVar_NdC6URMp_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 2.0f, 0, m, &cBinop_yjUIc8pD_sendMessage);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 2.0f, 0, m, &cBinop_dz0idCbn_sendMessage);
}

void Heavy_EQXG::cVar_0OkImWsp_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_cFfYNWbv_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_2aOJqMq0_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_OK34KQ45_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_NsYj5ptU_sendMessage);
}

void Heavy_EQXG::cVar_vb33XxG3_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cExpr_onMessage(_c, &Context(_c)->cExpr_xoRK8LNL, 0, m, &cExpr_xoRK8LNL_sendMessage);
}

void Heavy_EQXG::cExpr_xoRK8LNL_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  sVarf_onMessage(_c, &Context(_c)->sVarf_7fsqzj0S, m);
  sVarf_onMessage(_c, &Context(_c)->sVarf_qdb4mxol, m);
}

float Heavy_EQXG::cExpr_xoRK8LNL_evaluate(const float* args) {
  	return hv_pow_f(10 , ((float)(args[0])) / 20);
}

void Heavy_EQXG::cVar_C1CtRy2Y_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cExpr_onMessage(_c, &Context(_c)->cExpr_ySWsOjQk, 0, m, &cExpr_ySWsOjQk_sendMessage);
}

void Heavy_EQXG::cExpr_ySWsOjQk_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  sVarf_onMessage(_c, &Context(_c)->sVarf_8tT1Yfnx, m);
  sVarf_onMessage(_c, &Context(_c)->sVarf_W0PxtU51, m);
}

float Heavy_EQXG::cExpr_ySWsOjQk_evaluate(const float* args) {
  	return hv_pow_f(10 , ((float)(args[0])) / 20);
}

void Heavy_EQXG::cVar_1ndrvePX_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cExpr_onMessage(_c, &Context(_c)->cExpr_rGnQ6PCJ, 0, m, &cExpr_rGnQ6PCJ_sendMessage);
}

void Heavy_EQXG::cVar_PEjDmpB9_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cExpr_onMessage(_c, &Context(_c)->cExpr_ACaiVDZs, 0, m, &cExpr_ACaiVDZs_sendMessage);
}

void Heavy_EQXG::cUnop_Vx3sKXLJ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_feD3CcAW_sendMessage(_c, 0, m);
  cBinop_onMessage(_c, &Context(_c)->cBinop_J8ZLAt8X, HV_BINOP_MULTIPLY, 0, m, &cBinop_J8ZLAt8X_sendMessage);
}

void Heavy_EQXG::cUnop_9zwNc2hu_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_12LxjHgS_sendMessage(_c, 0, m);
  cBinop_onMessage(_c, &Context(_c)->cBinop_dPgrGt8t, HV_BINOP_MULTIPLY, 0, m, &cBinop_dPgrGt8t_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_fFZUUrI4, HV_BINOP_MULTIPLY, 0, m, &cBinop_fFZUUrI4_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_k4GjkXFV, HV_BINOP_MULTIPLY, 0, m, &cBinop_k4GjkXFV_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_0JRVcXwh, HV_BINOP_MULTIPLY, 0, m, &cBinop_0JRVcXwh_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_HjKM2nDM, HV_BINOP_MULTIPLY, 0, m, &cBinop_HjKM2nDM_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_eeavqtO6, HV_BINOP_MULTIPLY, 0, m, &cBinop_eeavqtO6_sendMessage);
}

void Heavy_EQXG::cBinop_c6w65lhW_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 20.0f, 0, m, &cBinop_6aGkvW6p_sendMessage);
}

void Heavy_EQXG::cBinop_6aGkvW6p_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_dnm66s8g, HV_BINOP_MULTIPLY, 0, m, &cBinop_dnm66s8g_sendMessage);
}

void Heavy_EQXG::cVar_wQIJM1MH_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_7kdqSEsP_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_VHnKNYWv_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, -24.0f, 0, m, &cBinop_wYfDGvbH_sendMessage);
}

void Heavy_EQXG::cBinop_wYfDGvbH_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 40.0f, 0, m, &cBinop_Nj8OjJiI_sendMessage);
}

void Heavy_EQXG::cVar_ARDjZI0l_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_gt8FpRoV_sendMessage);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 20000.0f, 0, m, &cBinop_c6w65lhW_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_bePCh1aH_sendMessage);
}

void Heavy_EQXG::cVar_Psm43837_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 100.0f, 0, m, &cBinop_59I39FmI_sendMessage);
}

void Heavy_EQXG::cVar_7AbCdT1a_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 24.0f, 0, m, &cBinop_VHnKNYWv_sendMessage);
}

void Heavy_EQXG::cUnop_AUBiTTFL_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 2.0f, 0, m, &cBinop_bE0Zlcid_sendMessage);
}

void Heavy_EQXG::cMsg_r2nB1aCr_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setSymbol(m, 0, "samplerate");
  cSystem_onMessage(_c, NULL, 0, m, &cSystem_OA00oGSm_sendMessage);
}

void Heavy_EQXG::cSystem_OA00oGSm_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_osOGSw5l, HV_BINOP_DIVIDE, 1, m, &cBinop_osOGSw5l_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_Pqy609au_sendMessage);
}

void Heavy_EQXG::cUnop_Xumu9ZpV_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 8.0f, 0, m, &cBinop_OZZoqCD2_sendMessage);
}

void Heavy_EQXG::cBinop_ZTkn0WlP_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_ARDjZI0l, 0, m, &cVar_ARDjZI0l_sendMessage);
}

void Heavy_EQXG::cBinop_N5vCZOuK_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 12.0f, 0, m, &cBinop_3i4rL6JJ_sendMessage);
}

void Heavy_EQXG::cBinop_3i4rL6JJ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_v7wqYbWB, HV_BINOP_POW, 1, m, &cBinop_v7wqYbWB_sendMessage);
  cMsg_9CCyfX08_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_v7wqYbWB_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 440.0f, 0, m, &cBinop_ZTkn0WlP_sendMessage);
}

void Heavy_EQXG::cMsg_9CCyfX08_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 2.0f);
  cBinop_onMessage(_c, &Context(_c)->cBinop_v7wqYbWB, HV_BINOP_POW, 0, m, &cBinop_v7wqYbWB_sendMessage);
}

void Heavy_EQXG::cIf_HUDiI4aA_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  switch (letIn) {
    case 0: {
      cMsg_yS4ldI2Y_sendMessage(_c, 0, m);
      break;
    }
    case 1: {
      cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 440.0f, 0, m, &cBinop_MqfAH92y_sendMessage);
      break;
    }
    default: return;
  }
}

void Heavy_EQXG::cUnop_57vYfAxf_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 12.0f, 0, m, &cBinop_GYMqOvuH_sendMessage);
}

void Heavy_EQXG::cBinop_MqfAH92y_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_LOG2, m, &cUnop_57vYfAxf_sendMessage);
}

void Heavy_EQXG::cBinop_GYMqOvuH_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 69.0f, 0, m, &cBinop_gU7XSnBZ_sendMessage);
}

void Heavy_EQXG::cBinop_gU7XSnBZ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 69.0f, 0, m, &cBinop_N5vCZOuK_sendMessage);
}

void Heavy_EQXG::cCast_rCdcKyCY_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cIf_onMessage(_c, &Context(_c)->cIf_HUDiI4aA, 0, m, &cIf_HUDiI4aA_sendMessage);
}

void Heavy_EQXG::cCast_fkxPdjyQ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_GREATER_THAN, 0.0f, 0, m, &cBinop_NPJRwPBW_sendMessage);
}

void Heavy_EQXG::cBinop_NPJRwPBW_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cIf_onMessage(_c, &Context(_c)->cIf_HUDiI4aA, 1, m, &cIf_HUDiI4aA_sendMessage);
}

void Heavy_EQXG::cMsg_yS4ldI2Y_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, -1500.0f);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 69.0f, 0, m, &cBinop_N5vCZOuK_sendMessage);
}

void Heavy_EQXG::cBinop_59I39FmI_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 0.1f, 0, m, &cBinop_3YYNestT_sendMessage);
}

void Heavy_EQXG::cBinop_3YYNestT_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_0nBZuvL7_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_rw6OmAoQ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 0.1f, 0, m, &cBinop_3rs65NUY_sendMessage);
}

void Heavy_EQXG::cBinop_3rs65NUY_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_Bhdw1FA5_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_eN8XMgwY_sendMessage);
}

void Heavy_EQXG::cMsg_L1u9DjwN_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_Fdgoci8h, 0, m, NULL);
}

void Heavy_EQXG::cMsg_h73RZZsE_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_nQC9UoFF, 0, m, NULL);
}

void Heavy_EQXG::cMsg_PBw8vlhk_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_J8bo8D5A, 0, m, NULL);
}

void Heavy_EQXG::cMsg_Aluyq21l_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_iXq9G3dq, 0, m, NULL);
}

void Heavy_EQXG::cMsg_2lg7L4uo_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_a1h8OI0F, 0, m, NULL);
}

void Heavy_EQXG::cCast_36dtRkFc_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_SIN, m, &cUnop_Vx3sKXLJ_sendMessage);
}

void Heavy_EQXG::cCast_G1ToxTbc_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_COS, m, &cUnop_9zwNc2hu_sendMessage);
}

void Heavy_EQXG::cSend_feD3CcAW_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cReceive_sETn01qM_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cSend_12LxjHgS_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cSend_iId4GzBi_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cMsg_0nBZuvL7_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 0.0f, 0, m, &cBinop_6oqMPmw5_sendMessage);
}

void Heavy_EQXG::cBinop_6oqMPmw5_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_J8ZLAt8X, HV_BINOP_MULTIPLY, 1, m, &cBinop_J8ZLAt8X_sendMessage);
}

void Heavy_EQXG::cBinop_J8ZLAt8X_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 0.5f, 0, m, &cBinop_sHfheuKX_sendMessage);
}

void Heavy_EQXG::cBinop_sHfheuKX_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_GV4uMSRH_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_c4nrXE1H_sendMessage);
}

void Heavy_EQXG::cMsg_7kdqSEsP_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 0.0f, 0, m, &cBinop_ukjWlYaQ_sendMessage);
}

void Heavy_EQXG::cBinop_ukjWlYaQ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_rXsSWYNP_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_LlsJfxt1_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_EGJDHlAY_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_K1WRac9c_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_UB8ZIdvD_sendMessage);
}

void Heavy_EQXG::cBinop_wpEsHBj9_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_2lg7L4uo_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_uUGwglUK_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_Aluyq21l_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_PM4CQp96_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_PBw8vlhk_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_VNRxaa1l_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_h73RZZsE_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_gXRwClEW_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_L1u9DjwN_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cCast_Bhdw1FA5_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_Psm43837, 1, m, &cVar_Psm43837_sendMessage);
}

void Heavy_EQXG::cCast_eN8XMgwY_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_ARDjZI0l, 0, m, &cVar_ARDjZI0l_sendMessage);
}

void Heavy_EQXG::cCast_gt8FpRoV_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_Psm43837, 0, m, &cVar_Psm43837_sendMessage);
}

void Heavy_EQXG::cCast_bePCh1aH_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_wQIJM1MH, 0, m, &cVar_wQIJM1MH_sendMessage);
}

void Heavy_EQXG::cSend_CHXnv0d5_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cBinop_Nj8OjJiI_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_x4spWHnb_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_pfYMXgKX_sendMessage);
}

void Heavy_EQXG::cCast_x4spWHnb_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_g8o8eFhx, HV_BINOP_POW, 1, m, &cBinop_g8o8eFhx_sendMessage);
}

void Heavy_EQXG::cCast_pfYMXgKX_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_zyr0RINl_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cMsg_zyr0RINl_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 10.0f);
  cBinop_onMessage(_c, &Context(_c)->cBinop_g8o8eFhx, HV_BINOP_POW, 0, m, &cBinop_g8o8eFhx_sendMessage);
}

void Heavy_EQXG::cBinop_g8o8eFhx_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_yUwFuFX7_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_0F5R05q9_sendMessage);
}

void Heavy_EQXG::cCast_zLQNpwPP_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_ARDjZI0l, 0, m, &cVar_ARDjZI0l_sendMessage);
}

void Heavy_EQXG::cCast_JyuUlu5f_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_7AbCdT1a, 0, m, &cVar_7AbCdT1a_sendMessage);
}

void Heavy_EQXG::cCast_OSg9Cp2v_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_ARDjZI0l, 0, m, &cVar_ARDjZI0l_sendMessage);
}

void Heavy_EQXG::cCast_1YsbiTXI_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_7AbCdT1a, 0, m, &cVar_7AbCdT1a_sendMessage);
}

void Heavy_EQXG::cBinop_bE0Zlcid_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_JvDuMT5E, HV_BINOP_MULTIPLY, 1, m, &cBinop_JvDuMT5E_sendMessage);
}

void Heavy_EQXG::cBinop_JvDuMT5E_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_rZk4SKvt_sendMessage(_c, 0, m);
  cBinop_onMessage(_c, &Context(_c)->cBinop_yRDlJQg1, HV_BINOP_ADD, 1, m, &cBinop_yRDlJQg1_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_rRXOQ8hI, HV_BINOP_SUBTRACT, 1, m, &cBinop_rRXOQ8hI_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_cyV2XSgh, HV_BINOP_SUBTRACT, 1, m, &cBinop_cyV2XSgh_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_ussrspm8, HV_BINOP_ADD, 1, m, &cBinop_ussrspm8_sendMessage);
}

void Heavy_EQXG::cCast_c4nrXE1H_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_JvDuMT5E, HV_BINOP_MULTIPLY, 0, m, &cBinop_JvDuMT5E_sendMessage);
}

void Heavy_EQXG::cCast_GV4uMSRH_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_iId4GzBi_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cCast_rXsSWYNP_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_gXRwClEW, HV_BINOP_MULTIPLY, 0, m, &cBinop_gXRwClEW_sendMessage);
}

void Heavy_EQXG::cCast_K1WRac9c_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_uUGwglUK, HV_BINOP_MULTIPLY, 0, m, &cBinop_uUGwglUK_sendMessage);
}

void Heavy_EQXG::cCast_EGJDHlAY_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_PM4CQp96, HV_BINOP_MULTIPLY, 0, m, &cBinop_PM4CQp96_sendMessage);
}

void Heavy_EQXG::cCast_UB8ZIdvD_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_wpEsHBj9, HV_BINOP_MULTIPLY, 0, m, &cBinop_wpEsHBj9_sendMessage);
}

void Heavy_EQXG::cCast_LlsJfxt1_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_VNRxaa1l, HV_BINOP_MULTIPLY, 0, m, &cBinop_VNRxaa1l_sendMessage);
}

void Heavy_EQXG::cCast_0F5R05q9_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_SQRT, m, &cUnop_AUBiTTFL_sendMessage);
}

void Heavy_EQXG::cCast_yUwFuFX7_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_CHXnv0d5_sendMessage(_c, 0, m);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_njs3ugpT_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_qJXnT1aD_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_fHAEqM2B_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_ieL8XjKg_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_2tJVdmAF_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_Aox0N5Jc_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_ZUNADZcf_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_9hhoSJ6q_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_STWQY5K4_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_tAmTUbCi_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_g7bM1Rkk_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_q07yIr2v_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_eqdPK4FL_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_i5OD10W1_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_9gSPIxnA_sendMessage);
}

void Heavy_EQXG::cSend_rZk4SKvt_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cBinop_hlfFdZuw_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -1.0f, 0, m, &cBinop_913I0baF_sendMessage);
}

void Heavy_EQXG::cBinop_dPgrGt8t_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_dtNVN428, HV_BINOP_ADD, 0, m, &cBinop_dtNVN428_sendMessage);
}

void Heavy_EQXG::cBinop_MRSnfQiu_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_dtNVN428, HV_BINOP_ADD, 1, m, &cBinop_dtNVN428_sendMessage);
}

void Heavy_EQXG::cCast_fHAEqM2B_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 1.0f, 0, m, &cBinop_hlfFdZuw_sendMessage);
}

void Heavy_EQXG::cCast_qJXnT1aD_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_MRSnfQiu_sendMessage);
}

void Heavy_EQXG::cCast_njs3ugpT_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_UehNHBnE, HV_BINOP_MULTIPLY, 1, m, &cBinop_UehNHBnE_sendMessage);
}

void Heavy_EQXG::cBinop_UehNHBnE_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_wpEsHBj9, HV_BINOP_MULTIPLY, 1, m, &cBinop_wpEsHBj9_sendMessage);
}

void Heavy_EQXG::cBinop_dtNVN428_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_yRDlJQg1, HV_BINOP_ADD, 0, m, &cBinop_yRDlJQg1_sendMessage);
}

void Heavy_EQXG::cBinop_913I0baF_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_dPgrGt8t, HV_BINOP_MULTIPLY, 1, m, &cBinop_dPgrGt8t_sendMessage);
}

void Heavy_EQXG::cBinop_yRDlJQg1_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_UehNHBnE, HV_BINOP_MULTIPLY, 0, m, &cBinop_UehNHBnE_sendMessage);
}

void Heavy_EQXG::cBinop_03eU8TG9_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_xH7mCNT0, HV_BINOP_ADD, 1, m, &cBinop_xH7mCNT0_sendMessage);
}

void Heavy_EQXG::cBinop_Z1gfWgXg_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -1.0f, 0, m, &cBinop_zmSL7qG9_sendMessage);
}

void Heavy_EQXG::cBinop_fFZUUrI4_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_xH7mCNT0, HV_BINOP_ADD, 0, m, &cBinop_xH7mCNT0_sendMessage);
}

void Heavy_EQXG::cCast_ieL8XjKg_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 2.0f, 0, m, &cBinop_5jRCR17X_sendMessage);
}

void Heavy_EQXG::cCast_2tJVdmAF_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 1.0f, 0, m, &cBinop_03eU8TG9_sendMessage);
}

void Heavy_EQXG::cCast_Aox0N5Jc_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_Z1gfWgXg_sendMessage);
}

void Heavy_EQXG::cBinop_5jRCR17X_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_o05VMu73, HV_BINOP_MULTIPLY, 1, m, &cBinop_o05VMu73_sendMessage);
}

void Heavy_EQXG::cBinop_o05VMu73_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_uUGwglUK, HV_BINOP_MULTIPLY, 1, m, &cBinop_uUGwglUK_sendMessage);
}

void Heavy_EQXG::cBinop_xH7mCNT0_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_o05VMu73, HV_BINOP_MULTIPLY, 0, m, &cBinop_o05VMu73_sendMessage);
}

void Heavy_EQXG::cBinop_zmSL7qG9_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_fFZUUrI4, HV_BINOP_MULTIPLY, 1, m, &cBinop_fFZUUrI4_sendMessage);
}

void Heavy_EQXG::cBinop_3v67qHDZ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -1.0f, 0, m, &cBinop_Ei0M4z84_sendMessage);
}

void Heavy_EQXG::cBinop_k4GjkXFV_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_VxMpyrlh, HV_BINOP_ADD, 0, m, &cBinop_VxMpyrlh_sendMessage);
}

void Heavy_EQXG::cBinop_VxMpyrlh_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_rRXOQ8hI, HV_BINOP_SUBTRACT, 0, m, &cBinop_rRXOQ8hI_sendMessage);
}

void Heavy_EQXG::cBinop_qi0GAZZZ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_VxMpyrlh, HV_BINOP_ADD, 1, m, &cBinop_VxMpyrlh_sendMessage);
}

void Heavy_EQXG::cBinop_rRXOQ8hI_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_XraT1NMn, HV_BINOP_MULTIPLY, 0, m, &cBinop_XraT1NMn_sendMessage);
}

void Heavy_EQXG::cCast_9hhoSJ6q_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_qi0GAZZZ_sendMessage);
}

void Heavy_EQXG::cCast_ZUNADZcf_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_XraT1NMn, HV_BINOP_MULTIPLY, 1, m, &cBinop_XraT1NMn_sendMessage);
}

void Heavy_EQXG::cCast_STWQY5K4_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 1.0f, 0, m, &cBinop_3v67qHDZ_sendMessage);
}

void Heavy_EQXG::cBinop_XraT1NMn_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_PM4CQp96, HV_BINOP_MULTIPLY, 1, m, &cBinop_PM4CQp96_sendMessage);
}

void Heavy_EQXG::cBinop_Ei0M4z84_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_k4GjkXFV, HV_BINOP_MULTIPLY, 1, m, &cBinop_k4GjkXFV_sendMessage);
}

void Heavy_EQXG::cBinop_kUkZYZBC_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_kHpbQK7g, HV_BINOP_ADD, 1, m, &cBinop_kHpbQK7g_sendMessage);
}

void Heavy_EQXG::cBinop_kHpbQK7g_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -2.0f, 0, m, &cBinop_XbrX5nqT_sendMessage);
}

void Heavy_EQXG::cBinop_sPxQZ8zK_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_0JRVcXwh, HV_BINOP_MULTIPLY, 1, m, &cBinop_0JRVcXwh_sendMessage);
}

void Heavy_EQXG::cBinop_0JRVcXwh_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_kHpbQK7g, HV_BINOP_ADD, 0, m, &cBinop_kHpbQK7g_sendMessage);
}

void Heavy_EQXG::cCast_g7bM1Rkk_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_sPxQZ8zK_sendMessage);
}

void Heavy_EQXG::cCast_tAmTUbCi_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 1.0f, 0, m, &cBinop_kUkZYZBC_sendMessage);
}

void Heavy_EQXG::cBinop_XbrX5nqT_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_VNRxaa1l, HV_BINOP_MULTIPLY, 1, m, &cBinop_VNRxaa1l_sendMessage);
}

void Heavy_EQXG::cBinop_5shCuvWd_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_HjKM2nDM, HV_BINOP_MULTIPLY, 1, m, &cBinop_HjKM2nDM_sendMessage);
}

void Heavy_EQXG::cBinop_HjKM2nDM_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_8rXCiOU1, HV_BINOP_ADD, 0, m, &cBinop_8rXCiOU1_sendMessage);
}

void Heavy_EQXG::cBinop_8rXCiOU1_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_cyV2XSgh, HV_BINOP_SUBTRACT, 0, m, &cBinop_cyV2XSgh_sendMessage);
}

void Heavy_EQXG::cBinop_BbzAQUdh_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_8rXCiOU1, HV_BINOP_ADD, 1, m, &cBinop_8rXCiOU1_sendMessage);
}

void Heavy_EQXG::cCast_q07yIr2v_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_BbzAQUdh_sendMessage);
}

void Heavy_EQXG::cCast_eqdPK4FL_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 1.0f, 0, m, &cBinop_5shCuvWd_sendMessage);
}

void Heavy_EQXG::cBinop_cyV2XSgh_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_gXRwClEW, HV_BINOP_MULTIPLY, 1, m, &cBinop_gXRwClEW_sendMessage);
}

void Heavy_EQXG::cMsg_SLuK5yUJ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  cUnop_onMessage(_c, HV_UNOP_ATAN, m, &cUnop_Xumu9ZpV_sendMessage);
}

void Heavy_EQXG::cBinop_OZZoqCD2_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_osOGSw5l, HV_BINOP_DIVIDE, 0, m, &cBinop_osOGSw5l_sendMessage);
}

void Heavy_EQXG::cCast_Pqy609au_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_SLuK5yUJ_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_osOGSw5l_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_dnm66s8g, HV_BINOP_MULTIPLY, 1, m, &cBinop_dnm66s8g_sendMessage);
}

void Heavy_EQXG::cBinop_dnm66s8g_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_36dtRkFc_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_G1ToxTbc_sendMessage);
}

void Heavy_EQXG::cBinop_jrwzAMW0_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_eeavqtO6, HV_BINOP_MULTIPLY, 1, m, &cBinop_eeavqtO6_sendMessage);
}

void Heavy_EQXG::cBinop_eeavqtO6_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_C8JVmvqu, HV_BINOP_ADD, 0, m, &cBinop_C8JVmvqu_sendMessage);
}

void Heavy_EQXG::cBinop_C8JVmvqu_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_ussrspm8, HV_BINOP_ADD, 0, m, &cBinop_ussrspm8_sendMessage);
}

void Heavy_EQXG::cBinop_QHGr6Giw_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_C8JVmvqu, HV_BINOP_ADD, 1, m, &cBinop_C8JVmvqu_sendMessage);
}

void Heavy_EQXG::cCast_i5OD10W1_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_QHGr6Giw_sendMessage);
}

void Heavy_EQXG::cCast_9gSPIxnA_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 1.0f, 0, m, &cBinop_jrwzAMW0_sendMessage);
}

void Heavy_EQXG::cBinop_ussrspm8_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_wQIJM1MH, 1, m, &cVar_wQIJM1MH_sendMessage);
}

void Heavy_EQXG::cBinop_hfoClX9T_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 0.2f, 0, m, &cBinop_6WTvubpS_sendMessage);
}

void Heavy_EQXG::cBinop_6WTvubpS_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 3.0f, 0, m, &cBinop_rw6OmAoQ_sendMessage);
}

void Heavy_EQXG::cUnop_flVuGrwf_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_13xQFrm9_sendMessage(_c, 0, m);
  cBinop_onMessage(_c, &Context(_c)->cBinop_P6QboYGW, HV_BINOP_MULTIPLY, 0, m, &cBinop_P6QboYGW_sendMessage);
}

void Heavy_EQXG::cUnop_aGogO5Lw_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_iUTZAsIH_sendMessage(_c, 0, m);
  cBinop_onMessage(_c, &Context(_c)->cBinop_3b4D1HCr, HV_BINOP_MULTIPLY, 0, m, &cBinop_3b4D1HCr_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_YMz9wByx, HV_BINOP_MULTIPLY, 0, m, &cBinop_YMz9wByx_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_FO3qp0XZ, HV_BINOP_MULTIPLY, 0, m, &cBinop_FO3qp0XZ_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_KzfnvdkG, HV_BINOP_MULTIPLY, 0, m, &cBinop_KzfnvdkG_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_mJsYp4lP, HV_BINOP_MULTIPLY, 0, m, &cBinop_mJsYp4lP_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_5xL3amem, HV_BINOP_MULTIPLY, 0, m, &cBinop_5xL3amem_sendMessage);
}

void Heavy_EQXG::cBinop_huTlBzbE_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 20.0f, 0, m, &cBinop_G440q0Ri_sendMessage);
}

void Heavy_EQXG::cBinop_G440q0Ri_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_LWuzZ4NZ, HV_BINOP_MULTIPLY, 0, m, &cBinop_LWuzZ4NZ_sendMessage);
}

void Heavy_EQXG::cVar_8wMLcTLv_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_QuB1zSnQ_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_2BigvtvB_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, -24.0f, 0, m, &cBinop_lpZ2JzON_sendMessage);
}

void Heavy_EQXG::cBinop_lpZ2JzON_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 40.0f, 0, m, &cBinop_U5QEcj5D_sendMessage);
}

void Heavy_EQXG::cVar_I05JD4SC_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_lyfw85O5_sendMessage);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 20000.0f, 0, m, &cBinop_huTlBzbE_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_dYNPVFpd_sendMessage);
}

void Heavy_EQXG::cVar_4cxHS2Wh_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 100.0f, 0, m, &cBinop_gOP3q3hf_sendMessage);
}

void Heavy_EQXG::cVar_Jr9kjrrb_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 24.0f, 0, m, &cBinop_2BigvtvB_sendMessage);
}

void Heavy_EQXG::cUnop_6SNQI8Tk_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 2.0f, 0, m, &cBinop_UP8RWXpV_sendMessage);
}

void Heavy_EQXG::cMsg_EcpnNrhI_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setSymbol(m, 0, "samplerate");
  cSystem_onMessage(_c, NULL, 0, m, &cSystem_E1K3KkTj_sendMessage);
}

void Heavy_EQXG::cSystem_E1K3KkTj_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_jmGS1eTI, HV_BINOP_DIVIDE, 1, m, &cBinop_jmGS1eTI_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_hPLvRJhq_sendMessage);
}

void Heavy_EQXG::cUnop_pXWYql9B_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 8.0f, 0, m, &cBinop_B4L6CsEE_sendMessage);
}

void Heavy_EQXG::cBinop_voBgbP0m_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_I05JD4SC, 0, m, &cVar_I05JD4SC_sendMessage);
}

void Heavy_EQXG::cBinop_GdAtHMqS_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 12.0f, 0, m, &cBinop_cLwfonPH_sendMessage);
}

void Heavy_EQXG::cBinop_cLwfonPH_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_7LmZhDJ9, HV_BINOP_POW, 1, m, &cBinop_7LmZhDJ9_sendMessage);
  cMsg_edcwXkyl_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_7LmZhDJ9_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 440.0f, 0, m, &cBinop_voBgbP0m_sendMessage);
}

void Heavy_EQXG::cMsg_edcwXkyl_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 2.0f);
  cBinop_onMessage(_c, &Context(_c)->cBinop_7LmZhDJ9, HV_BINOP_POW, 0, m, &cBinop_7LmZhDJ9_sendMessage);
}

void Heavy_EQXG::cIf_f0QBTFn0_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  switch (letIn) {
    case 0: {
      cMsg_1moLIdl2_sendMessage(_c, 0, m);
      break;
    }
    case 1: {
      cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 440.0f, 0, m, &cBinop_xidapH7G_sendMessage);
      break;
    }
    default: return;
  }
}

void Heavy_EQXG::cUnop_PrbayA8l_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 12.0f, 0, m, &cBinop_wrNWe2jr_sendMessage);
}

void Heavy_EQXG::cBinop_xidapH7G_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_LOG2, m, &cUnop_PrbayA8l_sendMessage);
}

void Heavy_EQXG::cBinop_wrNWe2jr_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 69.0f, 0, m, &cBinop_6k9C73hH_sendMessage);
}

void Heavy_EQXG::cBinop_6k9C73hH_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 69.0f, 0, m, &cBinop_GdAtHMqS_sendMessage);
}

void Heavy_EQXG::cCast_ygYBBM11_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cIf_onMessage(_c, &Context(_c)->cIf_f0QBTFn0, 0, m, &cIf_f0QBTFn0_sendMessage);
}

void Heavy_EQXG::cCast_GhJHMk0L_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_GREATER_THAN, 0.0f, 0, m, &cBinop_m4tKykz8_sendMessage);
}

void Heavy_EQXG::cBinop_m4tKykz8_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cIf_onMessage(_c, &Context(_c)->cIf_f0QBTFn0, 1, m, &cIf_f0QBTFn0_sendMessage);
}

void Heavy_EQXG::cMsg_1moLIdl2_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, -1500.0f);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 69.0f, 0, m, &cBinop_GdAtHMqS_sendMessage);
}

void Heavy_EQXG::cBinop_t5ehTDWr_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 0.1f, 0, m, &cBinop_J0QncqGx_sendMessage);
}

void Heavy_EQXG::cBinop_J0QncqGx_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_odudQEdB_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_X1mLPNw3_sendMessage);
}

void Heavy_EQXG::cBinop_gOP3q3hf_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 0.1f, 0, m, &cBinop_oZaKER5k_sendMessage);
}

void Heavy_EQXG::cBinop_oZaKER5k_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_3PZyzDqP_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cMsg_ySdfxGt8_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_PEKBNvbj, 0, m, NULL);
}

void Heavy_EQXG::cMsg_1PCgHqBW_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_AryZBwSH, 0, m, NULL);
}

void Heavy_EQXG::cMsg_B5eDClbp_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_Ht5dOgWg, 0, m, NULL);
}

void Heavy_EQXG::cMsg_SQb1V41R_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_h3r8mTrw, 0, m, NULL);
}

void Heavy_EQXG::cMsg_fS9RMpmQ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_bLFyKYuK, 0, m, NULL);
}

void Heavy_EQXG::cCast_pmRxxPsb_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_SIN, m, &cUnop_flVuGrwf_sendMessage);
}

void Heavy_EQXG::cCast_vqdli3CW_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_COS, m, &cUnop_aGogO5Lw_sendMessage);
}

void Heavy_EQXG::cSend_13xQFrm9_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cReceive_sETn01qM_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cSend_iUTZAsIH_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cSend_MexNhS6s_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cMsg_3PZyzDqP_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 0.0f, 0, m, &cBinop_q5wucgOv_sendMessage);
}

void Heavy_EQXG::cBinop_q5wucgOv_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_P6QboYGW, HV_BINOP_MULTIPLY, 1, m, &cBinop_P6QboYGW_sendMessage);
}

void Heavy_EQXG::cBinop_P6QboYGW_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 0.5f, 0, m, &cBinop_LACjfvIY_sendMessage);
}

void Heavy_EQXG::cBinop_LACjfvIY_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_FHk45CPi_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_4ueuUrVf_sendMessage);
}

void Heavy_EQXG::cMsg_QuB1zSnQ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 0.0f, 0, m, &cBinop_6vyq12Os_sendMessage);
}

void Heavy_EQXG::cBinop_6vyq12Os_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_ho7qNy34_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_ZwGxcPn6_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_DvZ7enFc_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_oLphsUvX_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_Hwrv8rne_sendMessage);
}

void Heavy_EQXG::cBinop_VTQ3EVDm_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_fS9RMpmQ_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_Ivf9CXSs_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_SQb1V41R_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_NTdHNla3_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_B5eDClbp_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_fdGYRU7q_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_1PCgHqBW_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_eZtjwU8Q_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_ySdfxGt8_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cCast_odudQEdB_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_4cxHS2Wh, 1, m, &cVar_4cxHS2Wh_sendMessage);
}

void Heavy_EQXG::cCast_X1mLPNw3_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_I05JD4SC, 0, m, &cVar_I05JD4SC_sendMessage);
}

void Heavy_EQXG::cCast_dYNPVFpd_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_8wMLcTLv, 0, m, &cVar_8wMLcTLv_sendMessage);
}

void Heavy_EQXG::cCast_lyfw85O5_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_4cxHS2Wh, 0, m, &cVar_4cxHS2Wh_sendMessage);
}

void Heavy_EQXG::cSend_03umGaTN_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cBinop_U5QEcj5D_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_IubraloE_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_7T5L19hK_sendMessage);
}

void Heavy_EQXG::cCast_7T5L19hK_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_o3QBjKc1_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cCast_IubraloE_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_adH8WeA3, HV_BINOP_POW, 1, m, &cBinop_adH8WeA3_sendMessage);
}

void Heavy_EQXG::cMsg_o3QBjKc1_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 10.0f);
  cBinop_onMessage(_c, &Context(_c)->cBinop_adH8WeA3, HV_BINOP_POW, 0, m, &cBinop_adH8WeA3_sendMessage);
}

void Heavy_EQXG::cBinop_adH8WeA3_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_b84xmZEK_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_YRhPKAry_sendMessage);
}

void Heavy_EQXG::cCast_OH06B7x4_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_Jr9kjrrb, 0, m, &cVar_Jr9kjrrb_sendMessage);
}

void Heavy_EQXG::cCast_MXmb8Lcr_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_I05JD4SC, 0, m, &cVar_I05JD4SC_sendMessage);
}

void Heavy_EQXG::cCast_mqtGSCWy_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_Jr9kjrrb, 0, m, &cVar_Jr9kjrrb_sendMessage);
}

void Heavy_EQXG::cCast_uqdqcmfA_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_I05JD4SC, 0, m, &cVar_I05JD4SC_sendMessage);
}

void Heavy_EQXG::cBinop_UP8RWXpV_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_OWuqk46D, HV_BINOP_MULTIPLY, 1, m, &cBinop_OWuqk46D_sendMessage);
}

void Heavy_EQXG::cBinop_OWuqk46D_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_Jkjevizz_sendMessage(_c, 0, m);
  cBinop_onMessage(_c, &Context(_c)->cBinop_8WMx5xhl, HV_BINOP_ADD, 1, m, &cBinop_8WMx5xhl_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_moK6xZuj, HV_BINOP_SUBTRACT, 1, m, &cBinop_moK6xZuj_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_wFLksmzi, HV_BINOP_SUBTRACT, 1, m, &cBinop_wFLksmzi_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_1MbC7QSp, HV_BINOP_ADD, 1, m, &cBinop_1MbC7QSp_sendMessage);
}

void Heavy_EQXG::cCast_4ueuUrVf_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_OWuqk46D, HV_BINOP_MULTIPLY, 0, m, &cBinop_OWuqk46D_sendMessage);
}

void Heavy_EQXG::cCast_FHk45CPi_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_MexNhS6s_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cCast_ZwGxcPn6_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_fdGYRU7q, HV_BINOP_MULTIPLY, 0, m, &cBinop_fdGYRU7q_sendMessage);
}

void Heavy_EQXG::cCast_Hwrv8rne_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_VTQ3EVDm, HV_BINOP_MULTIPLY, 0, m, &cBinop_VTQ3EVDm_sendMessage);
}

void Heavy_EQXG::cCast_DvZ7enFc_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_NTdHNla3, HV_BINOP_MULTIPLY, 0, m, &cBinop_NTdHNla3_sendMessage);
}

void Heavy_EQXG::cCast_ho7qNy34_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_eZtjwU8Q, HV_BINOP_MULTIPLY, 0, m, &cBinop_eZtjwU8Q_sendMessage);
}

void Heavy_EQXG::cCast_oLphsUvX_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_Ivf9CXSs, HV_BINOP_MULTIPLY, 0, m, &cBinop_Ivf9CXSs_sendMessage);
}

void Heavy_EQXG::cCast_YRhPKAry_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_SQRT, m, &cUnop_6SNQI8Tk_sendMessage);
}

void Heavy_EQXG::cCast_b84xmZEK_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_03umGaTN_sendMessage(_c, 0, m);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_ZkkmzqaB_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_dLKOQmcI_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_N99Z2o8d_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_RyHvRXT8_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_JO4FBcMZ_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_eyNiDjT5_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_wFrK34La_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_iyAR74NN_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_23R9k38w_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_gu28yKEc_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_dqwlPwns_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_Ce5jwpB4_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_Nr9U7NAN_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_aqo0HP3N_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_gEIPUN3x_sendMessage);
}

void Heavy_EQXG::cSend_Jkjevizz_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cBinop_HbNEvT6r_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -1.0f, 0, m, &cBinop_c4woT95I_sendMessage);
}

void Heavy_EQXG::cBinop_3b4D1HCr_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_hhpEyFxd, HV_BINOP_ADD, 0, m, &cBinop_hhpEyFxd_sendMessage);
}

void Heavy_EQXG::cBinop_0XcGqdBs_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_hhpEyFxd, HV_BINOP_ADD, 1, m, &cBinop_hhpEyFxd_sendMessage);
}

void Heavy_EQXG::cCast_N99Z2o8d_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 1.0f, 0, m, &cBinop_HbNEvT6r_sendMessage);
}

void Heavy_EQXG::cCast_dLKOQmcI_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_0XcGqdBs_sendMessage);
}

void Heavy_EQXG::cCast_ZkkmzqaB_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_IDvMPIs3, HV_BINOP_MULTIPLY, 1, m, &cBinop_IDvMPIs3_sendMessage);
}

void Heavy_EQXG::cBinop_IDvMPIs3_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_VTQ3EVDm, HV_BINOP_MULTIPLY, 1, m, &cBinop_VTQ3EVDm_sendMessage);
}

void Heavy_EQXG::cBinop_hhpEyFxd_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_8WMx5xhl, HV_BINOP_ADD, 0, m, &cBinop_8WMx5xhl_sendMessage);
}

void Heavy_EQXG::cBinop_c4woT95I_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_3b4D1HCr, HV_BINOP_MULTIPLY, 1, m, &cBinop_3b4D1HCr_sendMessage);
}

void Heavy_EQXG::cBinop_8WMx5xhl_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_IDvMPIs3, HV_BINOP_MULTIPLY, 0, m, &cBinop_IDvMPIs3_sendMessage);
}

void Heavy_EQXG::cBinop_xN99jcvf_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_rMpB5clD, HV_BINOP_ADD, 1, m, &cBinop_rMpB5clD_sendMessage);
}

void Heavy_EQXG::cBinop_x6drYp1w_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -1.0f, 0, m, &cBinop_y1GsG8jG_sendMessage);
}

void Heavy_EQXG::cBinop_YMz9wByx_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_rMpB5clD, HV_BINOP_ADD, 0, m, &cBinop_rMpB5clD_sendMessage);
}

void Heavy_EQXG::cCast_eyNiDjT5_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_x6drYp1w_sendMessage);
}

void Heavy_EQXG::cCast_JO4FBcMZ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 1.0f, 0, m, &cBinop_xN99jcvf_sendMessage);
}

void Heavy_EQXG::cCast_RyHvRXT8_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 2.0f, 0, m, &cBinop_9Yfhhu7t_sendMessage);
}

void Heavy_EQXG::cBinop_9Yfhhu7t_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_bPqLtOHr, HV_BINOP_MULTIPLY, 1, m, &cBinop_bPqLtOHr_sendMessage);
}

void Heavy_EQXG::cBinop_bPqLtOHr_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_Ivf9CXSs, HV_BINOP_MULTIPLY, 1, m, &cBinop_Ivf9CXSs_sendMessage);
}

void Heavy_EQXG::cBinop_rMpB5clD_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_bPqLtOHr, HV_BINOP_MULTIPLY, 0, m, &cBinop_bPqLtOHr_sendMessage);
}

void Heavy_EQXG::cBinop_y1GsG8jG_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_YMz9wByx, HV_BINOP_MULTIPLY, 1, m, &cBinop_YMz9wByx_sendMessage);
}

void Heavy_EQXG::cBinop_YvzHSYLd_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -1.0f, 0, m, &cBinop_aGRKryyj_sendMessage);
}

void Heavy_EQXG::cBinop_FO3qp0XZ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_LS8f7DkT, HV_BINOP_ADD, 0, m, &cBinop_LS8f7DkT_sendMessage);
}

void Heavy_EQXG::cBinop_LS8f7DkT_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_moK6xZuj, HV_BINOP_SUBTRACT, 0, m, &cBinop_moK6xZuj_sendMessage);
}

void Heavy_EQXG::cBinop_yKN5PAar_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_LS8f7DkT, HV_BINOP_ADD, 1, m, &cBinop_LS8f7DkT_sendMessage);
}

void Heavy_EQXG::cBinop_moK6xZuj_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_Sa0qkLxo, HV_BINOP_MULTIPLY, 0, m, &cBinop_Sa0qkLxo_sendMessage);
}

void Heavy_EQXG::cCast_23R9k38w_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 1.0f, 0, m, &cBinop_YvzHSYLd_sendMessage);
}

void Heavy_EQXG::cCast_wFrK34La_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_Sa0qkLxo, HV_BINOP_MULTIPLY, 1, m, &cBinop_Sa0qkLxo_sendMessage);
}

void Heavy_EQXG::cCast_iyAR74NN_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_yKN5PAar_sendMessage);
}

void Heavy_EQXG::cBinop_Sa0qkLxo_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_NTdHNla3, HV_BINOP_MULTIPLY, 1, m, &cBinop_NTdHNla3_sendMessage);
}

void Heavy_EQXG::cBinop_aGRKryyj_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_FO3qp0XZ, HV_BINOP_MULTIPLY, 1, m, &cBinop_FO3qp0XZ_sendMessage);
}

void Heavy_EQXG::cBinop_DNFJJJPX_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_IaQhLkuV, HV_BINOP_ADD, 1, m, &cBinop_IaQhLkuV_sendMessage);
}

void Heavy_EQXG::cBinop_IaQhLkuV_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -2.0f, 0, m, &cBinop_Fgnx9ggy_sendMessage);
}

void Heavy_EQXG::cBinop_izguGgsp_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_KzfnvdkG, HV_BINOP_MULTIPLY, 1, m, &cBinop_KzfnvdkG_sendMessage);
}

void Heavy_EQXG::cBinop_KzfnvdkG_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_IaQhLkuV, HV_BINOP_ADD, 0, m, &cBinop_IaQhLkuV_sendMessage);
}

void Heavy_EQXG::cCast_gu28yKEc_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 1.0f, 0, m, &cBinop_DNFJJJPX_sendMessage);
}

void Heavy_EQXG::cCast_dqwlPwns_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_izguGgsp_sendMessage);
}

void Heavy_EQXG::cBinop_Fgnx9ggy_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_fdGYRU7q, HV_BINOP_MULTIPLY, 1, m, &cBinop_fdGYRU7q_sendMessage);
}

void Heavy_EQXG::cBinop_XcaDAOVI_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_mJsYp4lP, HV_BINOP_MULTIPLY, 1, m, &cBinop_mJsYp4lP_sendMessage);
}

void Heavy_EQXG::cBinop_mJsYp4lP_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_EX3FHxHl, HV_BINOP_ADD, 0, m, &cBinop_EX3FHxHl_sendMessage);
}

void Heavy_EQXG::cBinop_EX3FHxHl_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_wFLksmzi, HV_BINOP_SUBTRACT, 0, m, &cBinop_wFLksmzi_sendMessage);
}

void Heavy_EQXG::cBinop_aXqXfv3V_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_EX3FHxHl, HV_BINOP_ADD, 1, m, &cBinop_EX3FHxHl_sendMessage);
}

void Heavy_EQXG::cCast_Nr9U7NAN_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 1.0f, 0, m, &cBinop_XcaDAOVI_sendMessage);
}

void Heavy_EQXG::cCast_Ce5jwpB4_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_aXqXfv3V_sendMessage);
}

void Heavy_EQXG::cBinop_wFLksmzi_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_eZtjwU8Q, HV_BINOP_MULTIPLY, 1, m, &cBinop_eZtjwU8Q_sendMessage);
}

void Heavy_EQXG::cMsg_bb1bFldt_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  cUnop_onMessage(_c, HV_UNOP_ATAN, m, &cUnop_pXWYql9B_sendMessage);
}

void Heavy_EQXG::cBinop_B4L6CsEE_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_jmGS1eTI, HV_BINOP_DIVIDE, 0, m, &cBinop_jmGS1eTI_sendMessage);
}

void Heavy_EQXG::cCast_hPLvRJhq_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_bb1bFldt_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_jmGS1eTI_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_LWuzZ4NZ, HV_BINOP_MULTIPLY, 1, m, &cBinop_LWuzZ4NZ_sendMessage);
}

void Heavy_EQXG::cBinop_LWuzZ4NZ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_pmRxxPsb_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_vqdli3CW_sendMessage);
}

void Heavy_EQXG::cBinop_vLQeM3no_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_5xL3amem, HV_BINOP_MULTIPLY, 1, m, &cBinop_5xL3amem_sendMessage);
}

void Heavy_EQXG::cBinop_5xL3amem_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_I2wcByUj, HV_BINOP_ADD, 0, m, &cBinop_I2wcByUj_sendMessage);
}

void Heavy_EQXG::cBinop_I2wcByUj_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_1MbC7QSp, HV_BINOP_ADD, 0, m, &cBinop_1MbC7QSp_sendMessage);
}

void Heavy_EQXG::cBinop_jQVsVmSu_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_I2wcByUj, HV_BINOP_ADD, 1, m, &cBinop_I2wcByUj_sendMessage);
}

void Heavy_EQXG::cCast_aqo0HP3N_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_jQVsVmSu_sendMessage);
}

void Heavy_EQXG::cCast_gEIPUN3x_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 1.0f, 0, m, &cBinop_vLQeM3no_sendMessage);
}

void Heavy_EQXG::cBinop_1MbC7QSp_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_8wMLcTLv, 1, m, &cVar_8wMLcTLv_sendMessage);
}

void Heavy_EQXG::cBinop_rIH3KrHO_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 0.2f, 0, m, &cBinop_wbgkumP9_sendMessage);
}

void Heavy_EQXG::cBinop_wbgkumP9_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 3.0f, 0, m, &cBinop_t5ehTDWr_sendMessage);
}

void Heavy_EQXG::cUnop_AnrKMDyg_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_XlpJiQ5s_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cUnop_ECaPCZk9_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_64D2dKzy_sendMessage(_c, 0, m);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -2.0f, 0, m, &cBinop_IfE0C7cZ_sendMessage);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -2.0f, 0, m, &cBinop_mmFLBWMH_sendMessage);
}

void Heavy_EQXG::cBinop_wdlmhIQY_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 20.0f, 0, m, &cBinop_MLk2oPwp_sendMessage);
}

void Heavy_EQXG::cBinop_MLk2oPwp_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_TDFMrtJw, HV_BINOP_MULTIPLY, 0, m, &cBinop_TDFMrtJw_sendMessage);
}

void Heavy_EQXG::cVar_35DfO4jz_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_6L5g087h_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_V7L10guq_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, -24.0f, 0, m, &cBinop_sgjTZqHo_sendMessage);
}

void Heavy_EQXG::cBinop_sgjTZqHo_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 40.0f, 0, m, &cBinop_DF3BG2Cx_sendMessage);
}

void Heavy_EQXG::cVar_GwROfLTq_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_7NMx2tEb_sendMessage);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 20000.0f, 0, m, &cBinop_wdlmhIQY_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_RVbavY2O_sendMessage);
}

void Heavy_EQXG::cVar_o2UmZQ3B_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 100.0f, 0, m, &cBinop_JFIdaRgs_sendMessage);
}

void Heavy_EQXG::cVar_6sSuUCaK_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 24.0f, 0, m, &cBinop_V7L10guq_sendMessage);
}

void Heavy_EQXG::cMsg_Aawzbz4H_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setSymbol(m, 0, "samplerate");
  cSystem_onMessage(_c, NULL, 0, m, &cSystem_BaPwNUUt_sendMessage);
}

void Heavy_EQXG::cSystem_BaPwNUUt_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_pZiSmF00, HV_BINOP_DIVIDE, 1, m, &cBinop_pZiSmF00_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_WQCIw0QD_sendMessage);
}

void Heavy_EQXG::cUnop_Zemo2Hdq_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 8.0f, 0, m, &cBinop_QgDhKEl1_sendMessage);
}

void Heavy_EQXG::cBinop_2TK8wp3Q_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_GwROfLTq, 0, m, &cVar_GwROfLTq_sendMessage);
}

void Heavy_EQXG::cBinop_oxJaJ1Fy_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 12.0f, 0, m, &cBinop_RKbUrW9r_sendMessage);
}

void Heavy_EQXG::cBinop_RKbUrW9r_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_Bvu0xRQp, HV_BINOP_POW, 1, m, &cBinop_Bvu0xRQp_sendMessage);
  cMsg_3fHenJbC_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_Bvu0xRQp_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 440.0f, 0, m, &cBinop_2TK8wp3Q_sendMessage);
}

void Heavy_EQXG::cMsg_3fHenJbC_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 2.0f);
  cBinop_onMessage(_c, &Context(_c)->cBinop_Bvu0xRQp, HV_BINOP_POW, 0, m, &cBinop_Bvu0xRQp_sendMessage);
}

void Heavy_EQXG::cIf_NKBBx3XR_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  switch (letIn) {
    case 0: {
      cMsg_VHikVT6H_sendMessage(_c, 0, m);
      break;
    }
    case 1: {
      cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 440.0f, 0, m, &cBinop_6r3dUfbC_sendMessage);
      break;
    }
    default: return;
  }
}

void Heavy_EQXG::cUnop_vNeNQvHQ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 12.0f, 0, m, &cBinop_cPpFScJd_sendMessage);
}

void Heavy_EQXG::cBinop_6r3dUfbC_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_LOG2, m, &cUnop_vNeNQvHQ_sendMessage);
}

void Heavy_EQXG::cBinop_cPpFScJd_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 69.0f, 0, m, &cBinop_Mqsyf6Gk_sendMessage);
}

void Heavy_EQXG::cBinop_Mqsyf6Gk_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 69.0f, 0, m, &cBinop_oxJaJ1Fy_sendMessage);
}

void Heavy_EQXG::cCast_ujGtMhWa_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cIf_onMessage(_c, &Context(_c)->cIf_NKBBx3XR, 0, m, &cIf_NKBBx3XR_sendMessage);
}

void Heavy_EQXG::cCast_qJGdv7wZ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_GREATER_THAN, 0.0f, 0, m, &cBinop_zWibo5gB_sendMessage);
}

void Heavy_EQXG::cBinop_zWibo5gB_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cIf_onMessage(_c, &Context(_c)->cIf_NKBBx3XR, 1, m, &cIf_NKBBx3XR_sendMessage);
}

void Heavy_EQXG::cMsg_VHikVT6H_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, -1500.0f);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 69.0f, 0, m, &cBinop_oxJaJ1Fy_sendMessage);
}

void Heavy_EQXG::cBinop_JFIdaRgs_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 0.1f, 0, m, &cBinop_LMB4dONj_sendMessage);
}

void Heavy_EQXG::cBinop_LMB4dONj_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_2X3hoJyy_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_AnU62qdX_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 0.1f, 0, m, &cBinop_gICp0Od0_sendMessage);
}

void Heavy_EQXG::cBinop_gICp0Od0_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_Ly6ToEyQ_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_ENkmr0tm_sendMessage);
}

void Heavy_EQXG::cMsg_Fd4pUeOb_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_nZsHhqQa, 0, m, NULL);
}

void Heavy_EQXG::cMsg_HSBK4Vo5_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_XzPyo4Fb, 0, m, NULL);
}

void Heavy_EQXG::cMsg_58QI76KT_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_4rPgkFbc, 0, m, NULL);
}

void Heavy_EQXG::cMsg_YV6IGhvV_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_bPD7AoOX, 0, m, NULL);
}

void Heavy_EQXG::cMsg_QUyRAYAx_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_fEPfEfAZ, 0, m, NULL);
}

void Heavy_EQXG::cCast_DkEBUhg1_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_SIN, m, &cUnop_AnrKMDyg_sendMessage);
}

void Heavy_EQXG::cCast_Ixd3SKLv_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_COS, m, &cUnop_ECaPCZk9_sendMessage);
}

void Heavy_EQXG::cSend_XlpJiQ5s_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cReceive_sETn01qM_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cSend_64D2dKzy_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cSend_VPtfYVD9_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cMsg_2X3hoJyy_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 0.0f, 0, m, &cBinop_4MczRtGv_sendMessage);
}

void Heavy_EQXG::cBinop_4MczRtGv_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_xmME8jTe, HV_BINOP_MULTIPLY, 1, m, &cBinop_xmME8jTe_sendMessage);
}

void Heavy_EQXG::cBinop_xmME8jTe_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 0.5f, 0, m, &cBinop_3qL6RLXg_sendMessage);
}

void Heavy_EQXG::cBinop_3qL6RLXg_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_VPtfYVD9_sendMessage(_c, 0, m);
  cBinop_onMessage(_c, &Context(_c)->cBinop_NlYBg7Pj, HV_BINOP_DIVIDE, 0, m, &cBinop_NlYBg7Pj_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_IB6CgVD7, HV_BINOP_MULTIPLY, 0, m, &cBinop_IB6CgVD7_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_uOVRzxpw, HV_BINOP_MULTIPLY, 0, m, &cBinop_uOVRzxpw_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_MZBVtj6N, HV_BINOP_DIVIDE, 0, m, &cBinop_MZBVtj6N_sendMessage);
}

void Heavy_EQXG::cMsg_6L5g087h_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 0.0f, 0, m, &cBinop_PUXJA1Q6_sendMessage);
}

void Heavy_EQXG::cBinop_PUXJA1Q6_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_rsjkiNuC_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_qxgeKEHZ_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_Yvjfcvx2_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_KqOhNoAq_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_dmeksBSN_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_i56RwEhq_sendMessage);
}

void Heavy_EQXG::cBinop_3COGahD8_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_Fd4pUeOb_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_3GNEhJf2_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_HSBK4Vo5_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_HVPzfaUi_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_58QI76KT_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_2U2pXZHn_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_YV6IGhvV_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_htrqCgtS_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_QUyRAYAx_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cCast_Ly6ToEyQ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_o2UmZQ3B, 1, m, &cVar_o2UmZQ3B_sendMessage);
}

void Heavy_EQXG::cCast_ENkmr0tm_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_GwROfLTq, 0, m, &cVar_GwROfLTq_sendMessage);
}

void Heavy_EQXG::cCast_i56RwEhq_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_3COGahD8, HV_BINOP_MULTIPLY, 0, m, &cBinop_3COGahD8_sendMessage);
}

void Heavy_EQXG::cCast_KqOhNoAq_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_HVPzfaUi, HV_BINOP_MULTIPLY, 0, m, &cBinop_HVPzfaUi_sendMessage);
}

void Heavy_EQXG::cCast_qxgeKEHZ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_htrqCgtS, HV_BINOP_MULTIPLY, 0, m, &cBinop_htrqCgtS_sendMessage);
}

void Heavy_EQXG::cCast_dmeksBSN_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_3GNEhJf2, HV_BINOP_MULTIPLY, 0, m, &cBinop_3GNEhJf2_sendMessage);
}

void Heavy_EQXG::cCast_rsjkiNuC_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cCast_Yvjfcvx2_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_2U2pXZHn, HV_BINOP_MULTIPLY, 0, m, &cBinop_2U2pXZHn_sendMessage);
}

void Heavy_EQXG::cCast_7NMx2tEb_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_o2UmZQ3B, 0, m, &cVar_o2UmZQ3B_sendMessage);
}

void Heavy_EQXG::cCast_RVbavY2O_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_35DfO4jz, 0, m, &cVar_35DfO4jz_sendMessage);
}

void Heavy_EQXG::cSend_50I2AYI1_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cBinop_DF3BG2Cx_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_HT71vFRB_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_1uYlxEph_sendMessage);
}

void Heavy_EQXG::cCast_1uYlxEph_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_WAS4xRTr_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cCast_HT71vFRB_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_48yPb4h5, HV_BINOP_POW, 1, m, &cBinop_48yPb4h5_sendMessage);
}

void Heavy_EQXG::cMsg_WAS4xRTr_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 10.0f);
  cBinop_onMessage(_c, &Context(_c)->cBinop_48yPb4h5, HV_BINOP_POW, 0, m, &cBinop_48yPb4h5_sendMessage);
}

void Heavy_EQXG::cBinop_48yPb4h5_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_50I2AYI1_sendMessage(_c, 0, m);
  cBinop_onMessage(_c, &Context(_c)->cBinop_NlYBg7Pj, HV_BINOP_DIVIDE, 1, m, &cBinop_NlYBg7Pj_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_IB6CgVD7, HV_BINOP_MULTIPLY, 1, m, &cBinop_IB6CgVD7_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_uOVRzxpw, HV_BINOP_MULTIPLY, 1, m, &cBinop_uOVRzxpw_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_MZBVtj6N, HV_BINOP_DIVIDE, 1, m, &cBinop_MZBVtj6N_sendMessage);
}

void Heavy_EQXG::cCast_mOFOfYY3_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_6sSuUCaK, 0, m, &cVar_6sSuUCaK_sendMessage);
}

void Heavy_EQXG::cCast_zyXRzaXH_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_GwROfLTq, 0, m, &cVar_GwROfLTq_sendMessage);
}

void Heavy_EQXG::cCast_fMPYcni4_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_GwROfLTq, 0, m, &cVar_GwROfLTq_sendMessage);
}

void Heavy_EQXG::cCast_LMThCY30_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_6sSuUCaK, 0, m, &cVar_6sSuUCaK_sendMessage);
}

void Heavy_EQXG::cBinop_80smjmUx_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_35DfO4jz, 1, m, &cVar_35DfO4jz_sendMessage);
}

void Heavy_EQXG::cBinop_NlYBg7Pj_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_80smjmUx_sendMessage);
}

void Heavy_EQXG::cBinop_IB6CgVD7_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_Qp4s9Umu_sendMessage);
}

void Heavy_EQXG::cBinop_Qp4s9Umu_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_3COGahD8, HV_BINOP_MULTIPLY, 1, m, &cBinop_3COGahD8_sendMessage);
}

void Heavy_EQXG::cBinop_IfE0C7cZ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_3GNEhJf2, HV_BINOP_MULTIPLY, 1, m, &cBinop_3GNEhJf2_sendMessage);
}

void Heavy_EQXG::cBinop_uOVRzxpw_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_PLN71wwL_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cMsg_PLN71wwL_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 0.0f, 0, m, &cBinop_nvp9dWnB_sendMessage);
}

void Heavy_EQXG::cBinop_nvp9dWnB_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_HVPzfaUi, HV_BINOP_MULTIPLY, 1, m, &cBinop_HVPzfaUi_sendMessage);
}

void Heavy_EQXG::cBinop_mmFLBWMH_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_2U2pXZHn, HV_BINOP_MULTIPLY, 1, m, &cBinop_2U2pXZHn_sendMessage);
}

void Heavy_EQXG::cBinop_MZBVtj6N_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_FQyF4vXW_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cMsg_FQyF4vXW_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 0.0f, 0, m, &cBinop_5W9hPHBf_sendMessage);
}

void Heavy_EQXG::cBinop_5W9hPHBf_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_htrqCgtS, HV_BINOP_MULTIPLY, 1, m, &cBinop_htrqCgtS_sendMessage);
}

void Heavy_EQXG::cMsg_PT7h5w0r_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  cUnop_onMessage(_c, HV_UNOP_ATAN, m, &cUnop_Zemo2Hdq_sendMessage);
}

void Heavy_EQXG::cBinop_QgDhKEl1_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_pZiSmF00, HV_BINOP_DIVIDE, 0, m, &cBinop_pZiSmF00_sendMessage);
}

void Heavy_EQXG::cCast_WQCIw0QD_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_PT7h5w0r_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_pZiSmF00_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_TDFMrtJw, HV_BINOP_MULTIPLY, 1, m, &cBinop_TDFMrtJw_sendMessage);
}

void Heavy_EQXG::cBinop_TDFMrtJw_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_DkEBUhg1_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_Ixd3SKLv_sendMessage);
}

void Heavy_EQXG::cBinop_CZAuGODj_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 0.2f, 0, m, &cBinop_tJQI7BaO_sendMessage);
}

void Heavy_EQXG::cBinop_tJQI7BaO_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 3.0f, 0, m, &cBinop_AnU62qdX_sendMessage);
}

void Heavy_EQXG::cUnop_7YbCa5b4_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_2tjsnc5a_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cUnop_dyjBCenY_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_5zFiJwFj_sendMessage(_c, 0, m);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -2.0f, 0, m, &cBinop_wj69sfAj_sendMessage);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -2.0f, 0, m, &cBinop_u2BavPAE_sendMessage);
}

void Heavy_EQXG::cBinop_LwISlLfj_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 20.0f, 0, m, &cBinop_Co6kcbW5_sendMessage);
}

void Heavy_EQXG::cBinop_Co6kcbW5_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_JINScce4, HV_BINOP_MULTIPLY, 0, m, &cBinop_JINScce4_sendMessage);
}

void Heavy_EQXG::cVar_l7nXL7ZP_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_gKyQzxri_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_dlidwi37_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, -24.0f, 0, m, &cBinop_P2x0cWpZ_sendMessage);
}

void Heavy_EQXG::cBinop_P2x0cWpZ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 40.0f, 0, m, &cBinop_uvdFfiZx_sendMessage);
}

void Heavy_EQXG::cVar_OUgR2NC5_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_UHZr4rdl_sendMessage);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 20000.0f, 0, m, &cBinop_LwISlLfj_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_fY4vKVKO_sendMessage);
}

void Heavy_EQXG::cVar_7obNbeKG_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 100.0f, 0, m, &cBinop_goGsaTXI_sendMessage);
}

void Heavy_EQXG::cVar_o7F4NWbG_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 24.0f, 0, m, &cBinop_dlidwi37_sendMessage);
}

void Heavy_EQXG::cMsg_jqbaNu97_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setSymbol(m, 0, "samplerate");
  cSystem_onMessage(_c, NULL, 0, m, &cSystem_Vca36L6W_sendMessage);
}

void Heavy_EQXG::cSystem_Vca36L6W_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_EvLwhReo, HV_BINOP_DIVIDE, 1, m, &cBinop_EvLwhReo_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_mwQrRZ21_sendMessage);
}

void Heavy_EQXG::cUnop_ZNB1iiUb_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 8.0f, 0, m, &cBinop_YdravLiy_sendMessage);
}

void Heavy_EQXG::cBinop_nOE2fPkO_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_OUgR2NC5, 0, m, &cVar_OUgR2NC5_sendMessage);
}

void Heavy_EQXG::cBinop_KI82rwcm_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 12.0f, 0, m, &cBinop_lfHkmSVw_sendMessage);
}

void Heavy_EQXG::cBinop_lfHkmSVw_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_h6rxrDWX, HV_BINOP_POW, 1, m, &cBinop_h6rxrDWX_sendMessage);
  cMsg_I39BSckj_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_h6rxrDWX_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 440.0f, 0, m, &cBinop_nOE2fPkO_sendMessage);
}

void Heavy_EQXG::cMsg_I39BSckj_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 2.0f);
  cBinop_onMessage(_c, &Context(_c)->cBinop_h6rxrDWX, HV_BINOP_POW, 0, m, &cBinop_h6rxrDWX_sendMessage);
}

void Heavy_EQXG::cIf_7n3CLJFM_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  switch (letIn) {
    case 0: {
      cMsg_6DFOT6M0_sendMessage(_c, 0, m);
      break;
    }
    case 1: {
      cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 440.0f, 0, m, &cBinop_SiA3XhX2_sendMessage);
      break;
    }
    default: return;
  }
}

void Heavy_EQXG::cUnop_zpX0JfDi_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 12.0f, 0, m, &cBinop_9N1PyTWv_sendMessage);
}

void Heavy_EQXG::cBinop_SiA3XhX2_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_LOG2, m, &cUnop_zpX0JfDi_sendMessage);
}

void Heavy_EQXG::cBinop_9N1PyTWv_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 69.0f, 0, m, &cBinop_DOETkDuP_sendMessage);
}

void Heavy_EQXG::cBinop_DOETkDuP_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 69.0f, 0, m, &cBinop_KI82rwcm_sendMessage);
}

void Heavy_EQXG::cCast_hdl2TR08_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cIf_onMessage(_c, &Context(_c)->cIf_7n3CLJFM, 0, m, &cIf_7n3CLJFM_sendMessage);
}

void Heavy_EQXG::cCast_XvW8K2u5_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_GREATER_THAN, 0.0f, 0, m, &cBinop_saA0FBKj_sendMessage);
}

void Heavy_EQXG::cBinop_saA0FBKj_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cIf_onMessage(_c, &Context(_c)->cIf_7n3CLJFM, 1, m, &cIf_7n3CLJFM_sendMessage);
}

void Heavy_EQXG::cMsg_6DFOT6M0_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, -1500.0f);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 69.0f, 0, m, &cBinop_KI82rwcm_sendMessage);
}

void Heavy_EQXG::cBinop_4QmOdw2d_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 0.1f, 0, m, &cBinop_7zRWuOwO_sendMessage);
}

void Heavy_EQXG::cBinop_7zRWuOwO_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_HyHTJxpM_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_gLphGRsC_sendMessage);
}

void Heavy_EQXG::cBinop_goGsaTXI_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 0.1f, 0, m, &cBinop_FkyY3g8f_sendMessage);
}

void Heavy_EQXG::cBinop_FkyY3g8f_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_fnPZsLpu_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cMsg_0J0798AI_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_M5MdyXVa, 0, m, NULL);
}

void Heavy_EQXG::cMsg_0ANDS1zR_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_Au4NMxWh, 0, m, NULL);
}

void Heavy_EQXG::cMsg_sZcF00jq_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_2p9tPAWo, 0, m, NULL);
}

void Heavy_EQXG::cMsg_HhoEhB2X_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_VyxAfLkq, 0, m, NULL);
}

void Heavy_EQXG::cMsg_XbZgWjsW_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_NJMJ9A3T, 0, m, NULL);
}

void Heavy_EQXG::cCast_fkP0j3Ec_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_COS, m, &cUnop_dyjBCenY_sendMessage);
}

void Heavy_EQXG::cCast_xeQTsr4G_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_SIN, m, &cUnop_7YbCa5b4_sendMessage);
}

void Heavy_EQXG::cSend_2tjsnc5a_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cReceive_sETn01qM_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cSend_5zFiJwFj_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cSend_7DBcffts_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cMsg_fnPZsLpu_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 0.0f, 0, m, &cBinop_hcWtfRvy_sendMessage);
}

void Heavy_EQXG::cBinop_hcWtfRvy_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_XDkxgdjQ, HV_BINOP_MULTIPLY, 1, m, &cBinop_XDkxgdjQ_sendMessage);
}

void Heavy_EQXG::cBinop_XDkxgdjQ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 0.5f, 0, m, &cBinop_BbsANusM_sendMessage);
}

void Heavy_EQXG::cBinop_BbsANusM_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_7DBcffts_sendMessage(_c, 0, m);
  cBinop_onMessage(_c, &Context(_c)->cBinop_itEJDUYw, HV_BINOP_DIVIDE, 0, m, &cBinop_itEJDUYw_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_r55bYmbR, HV_BINOP_MULTIPLY, 0, m, &cBinop_r55bYmbR_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_JYbyacpz, HV_BINOP_MULTIPLY, 0, m, &cBinop_JYbyacpz_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_hmoiiBdj, HV_BINOP_DIVIDE, 0, m, &cBinop_hmoiiBdj_sendMessage);
}

void Heavy_EQXG::cMsg_gKyQzxri_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 0.0f, 0, m, &cBinop_4iGp7QTy_sendMessage);
}

void Heavy_EQXG::cBinop_4iGp7QTy_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_T4hDipX9_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_PiGmrijC_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_ldn7Dek4_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_tSFPgRAV_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_2ClVwST6_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_ctjbPwPv_sendMessage);
}

void Heavy_EQXG::cBinop_lzqROrgU_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_0J0798AI_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_PYGGk0OX_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_0ANDS1zR_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_U3JFXviw_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_sZcF00jq_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_qOciTCFL_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_HhoEhB2X_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_9mIcSLgc_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_XbZgWjsW_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cCast_HyHTJxpM_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_7obNbeKG, 1, m, &cVar_7obNbeKG_sendMessage);
}

void Heavy_EQXG::cCast_gLphGRsC_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_OUgR2NC5, 0, m, &cVar_OUgR2NC5_sendMessage);
}

void Heavy_EQXG::cCast_ctjbPwPv_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_lzqROrgU, HV_BINOP_MULTIPLY, 0, m, &cBinop_lzqROrgU_sendMessage);
}

void Heavy_EQXG::cCast_T4hDipX9_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cCast_2ClVwST6_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_PYGGk0OX, HV_BINOP_MULTIPLY, 0, m, &cBinop_PYGGk0OX_sendMessage);
}

void Heavy_EQXG::cCast_tSFPgRAV_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_U3JFXviw, HV_BINOP_MULTIPLY, 0, m, &cBinop_U3JFXviw_sendMessage);
}

void Heavy_EQXG::cCast_ldn7Dek4_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_qOciTCFL, HV_BINOP_MULTIPLY, 0, m, &cBinop_qOciTCFL_sendMessage);
}

void Heavy_EQXG::cCast_PiGmrijC_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_9mIcSLgc, HV_BINOP_MULTIPLY, 0, m, &cBinop_9mIcSLgc_sendMessage);
}

void Heavy_EQXG::cCast_UHZr4rdl_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_7obNbeKG, 0, m, &cVar_7obNbeKG_sendMessage);
}

void Heavy_EQXG::cCast_fY4vKVKO_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_l7nXL7ZP, 0, m, &cVar_l7nXL7ZP_sendMessage);
}

void Heavy_EQXG::cSend_3ArKG91G_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cBinop_uvdFfiZx_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_oHtH4ftT_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_hW6QQQiI_sendMessage);
}

void Heavy_EQXG::cCast_hW6QQQiI_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_un9zsldw_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cCast_oHtH4ftT_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_ldE2pCmW, HV_BINOP_POW, 1, m, &cBinop_ldE2pCmW_sendMessage);
}

void Heavy_EQXG::cMsg_un9zsldw_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 10.0f);
  cBinop_onMessage(_c, &Context(_c)->cBinop_ldE2pCmW, HV_BINOP_POW, 0, m, &cBinop_ldE2pCmW_sendMessage);
}

void Heavy_EQXG::cBinop_ldE2pCmW_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_3ArKG91G_sendMessage(_c, 0, m);
  cBinop_onMessage(_c, &Context(_c)->cBinop_itEJDUYw, HV_BINOP_DIVIDE, 1, m, &cBinop_itEJDUYw_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_r55bYmbR, HV_BINOP_MULTIPLY, 1, m, &cBinop_r55bYmbR_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_JYbyacpz, HV_BINOP_MULTIPLY, 1, m, &cBinop_JYbyacpz_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_hmoiiBdj, HV_BINOP_DIVIDE, 1, m, &cBinop_hmoiiBdj_sendMessage);
}

void Heavy_EQXG::cCast_5CfWRX4K_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_o7F4NWbG, 0, m, &cVar_o7F4NWbG_sendMessage);
}

void Heavy_EQXG::cCast_EE5vDQyY_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_OUgR2NC5, 0, m, &cVar_OUgR2NC5_sendMessage);
}

void Heavy_EQXG::cCast_KMDyXfku_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_o7F4NWbG, 0, m, &cVar_o7F4NWbG_sendMessage);
}

void Heavy_EQXG::cCast_4ale86bw_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_OUgR2NC5, 0, m, &cVar_OUgR2NC5_sendMessage);
}

void Heavy_EQXG::cBinop_PQ18TajS_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_l7nXL7ZP, 1, m, &cVar_l7nXL7ZP_sendMessage);
}

void Heavy_EQXG::cBinop_itEJDUYw_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_PQ18TajS_sendMessage);
}

void Heavy_EQXG::cBinop_r55bYmbR_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_yfE4Kb5y_sendMessage);
}

void Heavy_EQXG::cBinop_yfE4Kb5y_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_lzqROrgU, HV_BINOP_MULTIPLY, 1, m, &cBinop_lzqROrgU_sendMessage);
}

void Heavy_EQXG::cBinop_wj69sfAj_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_PYGGk0OX, HV_BINOP_MULTIPLY, 1, m, &cBinop_PYGGk0OX_sendMessage);
}

void Heavy_EQXG::cBinop_JYbyacpz_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_NOdBAubF_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cMsg_NOdBAubF_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 0.0f, 0, m, &cBinop_2W3Q2wJx_sendMessage);
}

void Heavy_EQXG::cBinop_2W3Q2wJx_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_U3JFXviw, HV_BINOP_MULTIPLY, 1, m, &cBinop_U3JFXviw_sendMessage);
}

void Heavy_EQXG::cBinop_u2BavPAE_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_qOciTCFL, HV_BINOP_MULTIPLY, 1, m, &cBinop_qOciTCFL_sendMessage);
}

void Heavy_EQXG::cBinop_hmoiiBdj_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_NJGIg3Qu_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cMsg_NJGIg3Qu_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 0.0f, 0, m, &cBinop_ntyHkSQu_sendMessage);
}

void Heavy_EQXG::cBinop_ntyHkSQu_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_9mIcSLgc, HV_BINOP_MULTIPLY, 1, m, &cBinop_9mIcSLgc_sendMessage);
}

void Heavy_EQXG::cMsg_UlMkRSJI_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  cUnop_onMessage(_c, HV_UNOP_ATAN, m, &cUnop_ZNB1iiUb_sendMessage);
}

void Heavy_EQXG::cBinop_YdravLiy_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_EvLwhReo, HV_BINOP_DIVIDE, 0, m, &cBinop_EvLwhReo_sendMessage);
}

void Heavy_EQXG::cCast_mwQrRZ21_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_UlMkRSJI_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_EvLwhReo_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_JINScce4, HV_BINOP_MULTIPLY, 1, m, &cBinop_JINScce4_sendMessage);
}

void Heavy_EQXG::cBinop_JINScce4_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_xeQTsr4G_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_fkP0j3Ec_sendMessage);
}

void Heavy_EQXG::cBinop_2na66f76_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 0.2f, 0, m, &cBinop_RXzY8RDT_sendMessage);
}

void Heavy_EQXG::cBinop_RXzY8RDT_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 3.0f, 0, m, &cBinop_4QmOdw2d_sendMessage);
}

void Heavy_EQXG::cUnop_5BBaLqxK_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_X13pgMzI_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cUnop_cPz6hitu_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_vNUNFPHf_sendMessage(_c, 0, m);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -2.0f, 0, m, &cBinop_XdQigJeC_sendMessage);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -2.0f, 0, m, &cBinop_AD23Gn4N_sendMessage);
}

void Heavy_EQXG::cBinop_YUaSFpOh_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 20.0f, 0, m, &cBinop_Ct5j7bdE_sendMessage);
}

void Heavy_EQXG::cBinop_Ct5j7bdE_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_zWwIMay1, HV_BINOP_MULTIPLY, 0, m, &cBinop_zWwIMay1_sendMessage);
}

void Heavy_EQXG::cVar_9lVWR3ub_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_mYNV1fYg_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_8uIEWhkn_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, -24.0f, 0, m, &cBinop_qYU2Rfta_sendMessage);
}

void Heavy_EQXG::cBinop_qYU2Rfta_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 40.0f, 0, m, &cBinop_fYlGhJZy_sendMessage);
}

void Heavy_EQXG::cVar_ataxigwR_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_My4V6Dtm_sendMessage);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 20000.0f, 0, m, &cBinop_YUaSFpOh_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_jyNRkyjL_sendMessage);
}

void Heavy_EQXG::cVar_nFgkWlTx_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 100.0f, 0, m, &cBinop_FRlUiJZG_sendMessage);
}

void Heavy_EQXG::cVar_5uRrxHzu_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 24.0f, 0, m, &cBinop_8uIEWhkn_sendMessage);
}

void Heavy_EQXG::cMsg_LYp0Ygs4_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setSymbol(m, 0, "samplerate");
  cSystem_onMessage(_c, NULL, 0, m, &cSystem_NIGJ1kjG_sendMessage);
}

void Heavy_EQXG::cSystem_NIGJ1kjG_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_xbPFE0iT, HV_BINOP_DIVIDE, 1, m, &cBinop_xbPFE0iT_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_L5IcRcCW_sendMessage);
}

void Heavy_EQXG::cUnop_ODIYzd6O_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 8.0f, 0, m, &cBinop_asFnzRLK_sendMessage);
}

void Heavy_EQXG::cBinop_35R6cPaA_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_ataxigwR, 0, m, &cVar_ataxigwR_sendMessage);
}

void Heavy_EQXG::cBinop_N6er2A7I_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 12.0f, 0, m, &cBinop_7KOMp8mc_sendMessage);
}

void Heavy_EQXG::cBinop_7KOMp8mc_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_P9sNnmtu, HV_BINOP_POW, 1, m, &cBinop_P9sNnmtu_sendMessage);
  cMsg_lbWcXKlL_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_P9sNnmtu_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 440.0f, 0, m, &cBinop_35R6cPaA_sendMessage);
}

void Heavy_EQXG::cMsg_lbWcXKlL_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 2.0f);
  cBinop_onMessage(_c, &Context(_c)->cBinop_P9sNnmtu, HV_BINOP_POW, 0, m, &cBinop_P9sNnmtu_sendMessage);
}

void Heavy_EQXG::cIf_Y8FoNwRx_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  switch (letIn) {
    case 0: {
      cMsg_YxREA8hQ_sendMessage(_c, 0, m);
      break;
    }
    case 1: {
      cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 440.0f, 0, m, &cBinop_EPb72V2G_sendMessage);
      break;
    }
    default: return;
  }
}

void Heavy_EQXG::cUnop_3TEaxeB8_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 12.0f, 0, m, &cBinop_4HCnEGUQ_sendMessage);
}

void Heavy_EQXG::cBinop_EPb72V2G_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_LOG2, m, &cUnop_3TEaxeB8_sendMessage);
}

void Heavy_EQXG::cBinop_4HCnEGUQ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 69.0f, 0, m, &cBinop_l2PXdbZ8_sendMessage);
}

void Heavy_EQXG::cBinop_l2PXdbZ8_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 69.0f, 0, m, &cBinop_N6er2A7I_sendMessage);
}

void Heavy_EQXG::cCast_LXyLdGKE_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_GREATER_THAN, 0.0f, 0, m, &cBinop_sMR96lsf_sendMessage);
}

void Heavy_EQXG::cCast_eS7RKjkt_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cIf_onMessage(_c, &Context(_c)->cIf_Y8FoNwRx, 0, m, &cIf_Y8FoNwRx_sendMessage);
}

void Heavy_EQXG::cBinop_sMR96lsf_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cIf_onMessage(_c, &Context(_c)->cIf_Y8FoNwRx, 1, m, &cIf_Y8FoNwRx_sendMessage);
}

void Heavy_EQXG::cMsg_YxREA8hQ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, -1500.0f);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 69.0f, 0, m, &cBinop_N6er2A7I_sendMessage);
}

void Heavy_EQXG::cBinop_VdP8norl_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 0.1f, 0, m, &cBinop_QxTdiMVO_sendMessage);
}

void Heavy_EQXG::cBinop_QxTdiMVO_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_wch7fLV7_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_V2Jr5Oto_sendMessage);
}

void Heavy_EQXG::cBinop_FRlUiJZG_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 0.1f, 0, m, &cBinop_4dvTT99t_sendMessage);
}

void Heavy_EQXG::cBinop_4dvTT99t_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_DToXNMrl_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cMsg_oAikBOh8_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_xzYAORI8, 0, m, NULL);
}

void Heavy_EQXG::cMsg_hPQqNRoQ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_jkO3N5Eu, 0, m, NULL);
}

void Heavy_EQXG::cMsg_JSOvVmzV_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_1zbO8QCm, 0, m, NULL);
}

void Heavy_EQXG::cMsg_4S7p9XFT_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_MmTpPFlc, 0, m, NULL);
}

void Heavy_EQXG::cMsg_ZwJvdFYw_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_pgDeE4OS, 0, m, NULL);
}

void Heavy_EQXG::cCast_ft8G9EoC_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_COS, m, &cUnop_cPz6hitu_sendMessage);
}

void Heavy_EQXG::cCast_Nv8n7iyy_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_SIN, m, &cUnop_5BBaLqxK_sendMessage);
}

void Heavy_EQXG::cSend_X13pgMzI_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cReceive_sETn01qM_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cSend_vNUNFPHf_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cSend_yw4xNMjk_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cMsg_DToXNMrl_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 0.0f, 0, m, &cBinop_fbdiq3Mj_sendMessage);
}

void Heavy_EQXG::cBinop_fbdiq3Mj_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_mjHowSRL, HV_BINOP_MULTIPLY, 1, m, &cBinop_mjHowSRL_sendMessage);
}

void Heavy_EQXG::cBinop_mjHowSRL_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 0.5f, 0, m, &cBinop_TYdl8i7d_sendMessage);
}

void Heavy_EQXG::cBinop_TYdl8i7d_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_yw4xNMjk_sendMessage(_c, 0, m);
  cBinop_onMessage(_c, &Context(_c)->cBinop_EWh7MO26, HV_BINOP_DIVIDE, 0, m, &cBinop_EWh7MO26_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_cB30ZWhk, HV_BINOP_MULTIPLY, 0, m, &cBinop_cB30ZWhk_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_7GnztpIl, HV_BINOP_MULTIPLY, 0, m, &cBinop_7GnztpIl_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_Hmhup659, HV_BINOP_DIVIDE, 0, m, &cBinop_Hmhup659_sendMessage);
}

void Heavy_EQXG::cMsg_mYNV1fYg_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 0.0f, 0, m, &cBinop_vM9cbWVk_sendMessage);
}

void Heavy_EQXG::cBinop_vM9cbWVk_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_EhUa3k9C_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_g5tLfTuC_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_x72ZkoS7_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_xDtLAVvJ_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_HjySxc2V_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_b6GsPaPY_sendMessage);
}

void Heavy_EQXG::cBinop_gQjQQ4vr_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_oAikBOh8_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_S8dbcGF7_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_hPQqNRoQ_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_0uuG5uaQ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_JSOvVmzV_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_bmaov9yu_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_4S7p9XFT_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_hhBJdOfJ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_ZwJvdFYw_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cCast_wch7fLV7_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_nFgkWlTx, 1, m, &cVar_nFgkWlTx_sendMessage);
}

void Heavy_EQXG::cCast_V2Jr5Oto_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_ataxigwR, 0, m, &cVar_ataxigwR_sendMessage);
}

void Heavy_EQXG::cCast_g5tLfTuC_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_hhBJdOfJ, HV_BINOP_MULTIPLY, 0, m, &cBinop_hhBJdOfJ_sendMessage);
}

void Heavy_EQXG::cCast_xDtLAVvJ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_0uuG5uaQ, HV_BINOP_MULTIPLY, 0, m, &cBinop_0uuG5uaQ_sendMessage);
}

void Heavy_EQXG::cCast_HjySxc2V_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_S8dbcGF7, HV_BINOP_MULTIPLY, 0, m, &cBinop_S8dbcGF7_sendMessage);
}

void Heavy_EQXG::cCast_EhUa3k9C_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cCast_x72ZkoS7_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_bmaov9yu, HV_BINOP_MULTIPLY, 0, m, &cBinop_bmaov9yu_sendMessage);
}

void Heavy_EQXG::cCast_b6GsPaPY_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_gQjQQ4vr, HV_BINOP_MULTIPLY, 0, m, &cBinop_gQjQQ4vr_sendMessage);
}

void Heavy_EQXG::cCast_jyNRkyjL_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_9lVWR3ub, 0, m, &cVar_9lVWR3ub_sendMessage);
}

void Heavy_EQXG::cCast_My4V6Dtm_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_nFgkWlTx, 0, m, &cVar_nFgkWlTx_sendMessage);
}

void Heavy_EQXG::cSend_GxJlrN0k_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cBinop_fYlGhJZy_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_WOwPi7HN_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_BYq4TsGd_sendMessage);
}

void Heavy_EQXG::cCast_BYq4TsGd_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_fuQ3Vnt7_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cCast_WOwPi7HN_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_RjfE78Zb, HV_BINOP_POW, 1, m, &cBinop_RjfE78Zb_sendMessage);
}

void Heavy_EQXG::cMsg_fuQ3Vnt7_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 10.0f);
  cBinop_onMessage(_c, &Context(_c)->cBinop_RjfE78Zb, HV_BINOP_POW, 0, m, &cBinop_RjfE78Zb_sendMessage);
}

void Heavy_EQXG::cBinop_RjfE78Zb_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_GxJlrN0k_sendMessage(_c, 0, m);
  cBinop_onMessage(_c, &Context(_c)->cBinop_EWh7MO26, HV_BINOP_DIVIDE, 1, m, &cBinop_EWh7MO26_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_cB30ZWhk, HV_BINOP_MULTIPLY, 1, m, &cBinop_cB30ZWhk_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_7GnztpIl, HV_BINOP_MULTIPLY, 1, m, &cBinop_7GnztpIl_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_Hmhup659, HV_BINOP_DIVIDE, 1, m, &cBinop_Hmhup659_sendMessage);
}

void Heavy_EQXG::cCast_w9HHDPpp_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_ataxigwR, 0, m, &cVar_ataxigwR_sendMessage);
}

void Heavy_EQXG::cCast_YteJvDxa_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_5uRrxHzu, 0, m, &cVar_5uRrxHzu_sendMessage);
}

void Heavy_EQXG::cCast_mS6NvoeK_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_ataxigwR, 0, m, &cVar_ataxigwR_sendMessage);
}

void Heavy_EQXG::cCast_dKIey1w5_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_5uRrxHzu, 0, m, &cVar_5uRrxHzu_sendMessage);
}

void Heavy_EQXG::cBinop_J94lPSGc_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_9lVWR3ub, 1, m, &cVar_9lVWR3ub_sendMessage);
}

void Heavy_EQXG::cBinop_EWh7MO26_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_J94lPSGc_sendMessage);
}

void Heavy_EQXG::cBinop_cB30ZWhk_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_cBqeqcRh_sendMessage);
}

void Heavy_EQXG::cBinop_cBqeqcRh_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_gQjQQ4vr, HV_BINOP_MULTIPLY, 1, m, &cBinop_gQjQQ4vr_sendMessage);
}

void Heavy_EQXG::cBinop_XdQigJeC_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_S8dbcGF7, HV_BINOP_MULTIPLY, 1, m, &cBinop_S8dbcGF7_sendMessage);
}

void Heavy_EQXG::cBinop_7GnztpIl_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_DhHiZYoZ_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cMsg_DhHiZYoZ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 0.0f, 0, m, &cBinop_no8ubg4g_sendMessage);
}

void Heavy_EQXG::cBinop_no8ubg4g_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_0uuG5uaQ, HV_BINOP_MULTIPLY, 1, m, &cBinop_0uuG5uaQ_sendMessage);
}

void Heavy_EQXG::cBinop_AD23Gn4N_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_bmaov9yu, HV_BINOP_MULTIPLY, 1, m, &cBinop_bmaov9yu_sendMessage);
}

void Heavy_EQXG::cBinop_Hmhup659_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_0g94jc4T_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cMsg_0g94jc4T_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 0.0f, 0, m, &cBinop_n5909xya_sendMessage);
}

void Heavy_EQXG::cBinop_n5909xya_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_hhBJdOfJ, HV_BINOP_MULTIPLY, 1, m, &cBinop_hhBJdOfJ_sendMessage);
}

void Heavy_EQXG::cMsg_z8pT9J3R_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  cUnop_onMessage(_c, HV_UNOP_ATAN, m, &cUnop_ODIYzd6O_sendMessage);
}

void Heavy_EQXG::cBinop_asFnzRLK_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_xbPFE0iT, HV_BINOP_DIVIDE, 0, m, &cBinop_xbPFE0iT_sendMessage);
}

void Heavy_EQXG::cCast_L5IcRcCW_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_z8pT9J3R_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_xbPFE0iT_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_zWwIMay1, HV_BINOP_MULTIPLY, 1, m, &cBinop_zWwIMay1_sendMessage);
}

void Heavy_EQXG::cBinop_zWwIMay1_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_Nv8n7iyy_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_ft8G9EoC_sendMessage);
}

void Heavy_EQXG::cBinop_2uGGQO98_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 0.2f, 0, m, &cBinop_wPBvWPt4_sendMessage);
}

void Heavy_EQXG::cBinop_wPBvWPt4_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 3.0f, 0, m, &cBinop_VdP8norl_sendMessage);
}

void Heavy_EQXG::cUnop_d0Yu5qXm_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_rJUaD2iK_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cUnop_TN9zawtE_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_tFwXXe5h_sendMessage(_c, 0, m);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -2.0f, 0, m, &cBinop_nOjJHzY7_sendMessage);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -2.0f, 0, m, &cBinop_1pGy5ysJ_sendMessage);
}

void Heavy_EQXG::cBinop_LIz0vQoc_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 20.0f, 0, m, &cBinop_oMsqrT5k_sendMessage);
}

void Heavy_EQXG::cBinop_oMsqrT5k_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_52uWYgrv, HV_BINOP_MULTIPLY, 0, m, &cBinop_52uWYgrv_sendMessage);
}

void Heavy_EQXG::cVar_W4LGt2tX_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_NDSXvzvy_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_cqroxhHv_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, -24.0f, 0, m, &cBinop_ppJhhod5_sendMessage);
}

void Heavy_EQXG::cBinop_ppJhhod5_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 40.0f, 0, m, &cBinop_ccxqaUL7_sendMessage);
}

void Heavy_EQXG::cVar_eMQnRg9A_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_fieKIyYF_sendMessage);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 20000.0f, 0, m, &cBinop_LIz0vQoc_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_7erM1kNQ_sendMessage);
}

void Heavy_EQXG::cVar_5pDdUbg2_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 100.0f, 0, m, &cBinop_3QOwbw41_sendMessage);
}

void Heavy_EQXG::cVar_liIWQIbN_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 24.0f, 0, m, &cBinop_cqroxhHv_sendMessage);
}

void Heavy_EQXG::cMsg_FJHCNNHG_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setSymbol(m, 0, "samplerate");
  cSystem_onMessage(_c, NULL, 0, m, &cSystem_WOyzKmmK_sendMessage);
}

void Heavy_EQXG::cSystem_WOyzKmmK_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_lde22gjG, HV_BINOP_DIVIDE, 1, m, &cBinop_lde22gjG_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_Lj0vKvzo_sendMessage);
}

void Heavy_EQXG::cUnop_T1py5ve3_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 8.0f, 0, m, &cBinop_Yt0Jicxc_sendMessage);
}

void Heavy_EQXG::cBinop_AIYoVefd_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_eMQnRg9A, 0, m, &cVar_eMQnRg9A_sendMessage);
}

void Heavy_EQXG::cBinop_gU6n2VL4_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 12.0f, 0, m, &cBinop_UwlMZRzN_sendMessage);
}

void Heavy_EQXG::cBinop_UwlMZRzN_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_cEu8ec9A, HV_BINOP_POW, 1, m, &cBinop_cEu8ec9A_sendMessage);
  cMsg_1CaIDFun_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_cEu8ec9A_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 440.0f, 0, m, &cBinop_AIYoVefd_sendMessage);
}

void Heavy_EQXG::cMsg_1CaIDFun_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 2.0f);
  cBinop_onMessage(_c, &Context(_c)->cBinop_cEu8ec9A, HV_BINOP_POW, 0, m, &cBinop_cEu8ec9A_sendMessage);
}

void Heavy_EQXG::cIf_msvaJsMd_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  switch (letIn) {
    case 0: {
      cMsg_0tGKdQhN_sendMessage(_c, 0, m);
      break;
    }
    case 1: {
      cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 440.0f, 0, m, &cBinop_jYzQJrM4_sendMessage);
      break;
    }
    default: return;
  }
}

void Heavy_EQXG::cUnop_4iSHeMRy_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 12.0f, 0, m, &cBinop_zBksRQ9w_sendMessage);
}

void Heavy_EQXG::cBinop_jYzQJrM4_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_LOG2, m, &cUnop_4iSHeMRy_sendMessage);
}

void Heavy_EQXG::cBinop_zBksRQ9w_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 69.0f, 0, m, &cBinop_Sa5YhFfT_sendMessage);
}

void Heavy_EQXG::cBinop_Sa5YhFfT_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 69.0f, 0, m, &cBinop_gU6n2VL4_sendMessage);
}

void Heavy_EQXG::cCast_TOzaZisJ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cIf_onMessage(_c, &Context(_c)->cIf_msvaJsMd, 0, m, &cIf_msvaJsMd_sendMessage);
}

void Heavy_EQXG::cCast_smlZreZr_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_GREATER_THAN, 0.0f, 0, m, &cBinop_seLfMwjS_sendMessage);
}

void Heavy_EQXG::cBinop_seLfMwjS_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cIf_onMessage(_c, &Context(_c)->cIf_msvaJsMd, 1, m, &cIf_msvaJsMd_sendMessage);
}

void Heavy_EQXG::cMsg_0tGKdQhN_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, -1500.0f);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 69.0f, 0, m, &cBinop_gU6n2VL4_sendMessage);
}

void Heavy_EQXG::cBinop_3QOwbw41_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 0.1f, 0, m, &cBinop_VAlswjfY_sendMessage);
}

void Heavy_EQXG::cBinop_VAlswjfY_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_HwDwzYxU_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_rgOTUCrH_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 0.1f, 0, m, &cBinop_asXNUqjx_sendMessage);
}

void Heavy_EQXG::cBinop_asXNUqjx_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_9oH4iMf3_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_KE7Zzetd_sendMessage);
}

void Heavy_EQXG::cMsg_9cH33C6Z_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_155H8MeN, 0, m, NULL);
}

void Heavy_EQXG::cMsg_WKZFmIt6_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_qjVZNmDs, 0, m, NULL);
}

void Heavy_EQXG::cMsg_pyySLyF5_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_maIsr8Jz, 0, m, NULL);
}

void Heavy_EQXG::cMsg_bkUyS195_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_A2E1S2eK, 0, m, NULL);
}

void Heavy_EQXG::cMsg_jBBfrQQi_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_YTZ21Ar9, 0, m, NULL);
}

void Heavy_EQXG::cCast_1DY8QKJq_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_COS, m, &cUnop_TN9zawtE_sendMessage);
}

void Heavy_EQXG::cCast_itCVvMKw_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_SIN, m, &cUnop_d0Yu5qXm_sendMessage);
}

void Heavy_EQXG::cSend_rJUaD2iK_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cReceive_sETn01qM_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cSend_tFwXXe5h_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cSend_OHn3fYnT_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cMsg_HwDwzYxU_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 0.0f, 0, m, &cBinop_MekA4ixz_sendMessage);
}

void Heavy_EQXG::cBinop_MekA4ixz_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_Y4ATJTUd, HV_BINOP_MULTIPLY, 1, m, &cBinop_Y4ATJTUd_sendMessage);
}

void Heavy_EQXG::cBinop_Y4ATJTUd_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 0.5f, 0, m, &cBinop_LzW3uMA6_sendMessage);
}

void Heavy_EQXG::cBinop_LzW3uMA6_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_OHn3fYnT_sendMessage(_c, 0, m);
  cBinop_onMessage(_c, &Context(_c)->cBinop_ZEZyewg4, HV_BINOP_DIVIDE, 0, m, &cBinop_ZEZyewg4_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_Q5YynIRf, HV_BINOP_MULTIPLY, 0, m, &cBinop_Q5YynIRf_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_tJF0Nuw7, HV_BINOP_MULTIPLY, 0, m, &cBinop_tJF0Nuw7_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_mTtPPXQl, HV_BINOP_DIVIDE, 0, m, &cBinop_mTtPPXQl_sendMessage);
}

void Heavy_EQXG::cMsg_NDSXvzvy_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 0.0f, 0, m, &cBinop_eRBXJYxA_sendMessage);
}

void Heavy_EQXG::cBinop_eRBXJYxA_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_5fU83Lbv_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_VrRVlpCz_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_oVPA60Wp_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_ib8eru3C_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_q7biAcpC_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_wAi0wIpq_sendMessage);
}

void Heavy_EQXG::cBinop_7jmnwMCy_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_9cH33C6Z_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_7vZweQM2_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_WKZFmIt6_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_8Ndd3DW3_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_pyySLyF5_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_HhibIAMp_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_bkUyS195_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_ey7rSAFu_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_jBBfrQQi_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cCast_9oH4iMf3_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_5pDdUbg2, 1, m, &cVar_5pDdUbg2_sendMessage);
}

void Heavy_EQXG::cCast_KE7Zzetd_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_eMQnRg9A, 0, m, &cVar_eMQnRg9A_sendMessage);
}

void Heavy_EQXG::cCast_q7biAcpC_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_7vZweQM2, HV_BINOP_MULTIPLY, 0, m, &cBinop_7vZweQM2_sendMessage);
}

void Heavy_EQXG::cCast_oVPA60Wp_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_HhibIAMp, HV_BINOP_MULTIPLY, 0, m, &cBinop_HhibIAMp_sendMessage);
}

void Heavy_EQXG::cCast_ib8eru3C_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_8Ndd3DW3, HV_BINOP_MULTIPLY, 0, m, &cBinop_8Ndd3DW3_sendMessage);
}

void Heavy_EQXG::cCast_5fU83Lbv_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cCast_wAi0wIpq_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_7jmnwMCy, HV_BINOP_MULTIPLY, 0, m, &cBinop_7jmnwMCy_sendMessage);
}

void Heavy_EQXG::cCast_VrRVlpCz_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_ey7rSAFu, HV_BINOP_MULTIPLY, 0, m, &cBinop_ey7rSAFu_sendMessage);
}

void Heavy_EQXG::cCast_7erM1kNQ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_W4LGt2tX, 0, m, &cVar_W4LGt2tX_sendMessage);
}

void Heavy_EQXG::cCast_fieKIyYF_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_5pDdUbg2, 0, m, &cVar_5pDdUbg2_sendMessage);
}

void Heavy_EQXG::cSend_ktKzw16r_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cBinop_ccxqaUL7_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_EN5e4YVF_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_G3iXrfXt_sendMessage);
}

void Heavy_EQXG::cCast_G3iXrfXt_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_FKK3rBpP_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cCast_EN5e4YVF_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_FX0VI0Uu, HV_BINOP_POW, 1, m, &cBinop_FX0VI0Uu_sendMessage);
}

void Heavy_EQXG::cMsg_FKK3rBpP_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 10.0f);
  cBinop_onMessage(_c, &Context(_c)->cBinop_FX0VI0Uu, HV_BINOP_POW, 0, m, &cBinop_FX0VI0Uu_sendMessage);
}

void Heavy_EQXG::cBinop_FX0VI0Uu_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_ktKzw16r_sendMessage(_c, 0, m);
  cBinop_onMessage(_c, &Context(_c)->cBinop_ZEZyewg4, HV_BINOP_DIVIDE, 1, m, &cBinop_ZEZyewg4_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_Q5YynIRf, HV_BINOP_MULTIPLY, 1, m, &cBinop_Q5YynIRf_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_tJF0Nuw7, HV_BINOP_MULTIPLY, 1, m, &cBinop_tJF0Nuw7_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_mTtPPXQl, HV_BINOP_DIVIDE, 1, m, &cBinop_mTtPPXQl_sendMessage);
}

void Heavy_EQXG::cCast_AWqBnvlH_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_eMQnRg9A, 0, m, &cVar_eMQnRg9A_sendMessage);
}

void Heavy_EQXG::cCast_c2Z9k4Gt_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_liIWQIbN, 0, m, &cVar_liIWQIbN_sendMessage);
}

void Heavy_EQXG::cCast_UbxAwkhq_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_liIWQIbN, 0, m, &cVar_liIWQIbN_sendMessage);
}

void Heavy_EQXG::cCast_Fw9et5It_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_eMQnRg9A, 0, m, &cVar_eMQnRg9A_sendMessage);
}

void Heavy_EQXG::cBinop_nUo3KZmV_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_W4LGt2tX, 1, m, &cVar_W4LGt2tX_sendMessage);
}

void Heavy_EQXG::cBinop_ZEZyewg4_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_nUo3KZmV_sendMessage);
}

void Heavy_EQXG::cBinop_Q5YynIRf_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_sWaVYb7G_sendMessage);
}

void Heavy_EQXG::cBinop_sWaVYb7G_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_7jmnwMCy, HV_BINOP_MULTIPLY, 1, m, &cBinop_7jmnwMCy_sendMessage);
}

void Heavy_EQXG::cBinop_nOjJHzY7_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_7vZweQM2, HV_BINOP_MULTIPLY, 1, m, &cBinop_7vZweQM2_sendMessage);
}

void Heavy_EQXG::cBinop_tJF0Nuw7_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_vHQ9ET3h_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cMsg_vHQ9ET3h_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 0.0f, 0, m, &cBinop_gfjSNRhJ_sendMessage);
}

void Heavy_EQXG::cBinop_gfjSNRhJ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_8Ndd3DW3, HV_BINOP_MULTIPLY, 1, m, &cBinop_8Ndd3DW3_sendMessage);
}

void Heavy_EQXG::cBinop_1pGy5ysJ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_HhibIAMp, HV_BINOP_MULTIPLY, 1, m, &cBinop_HhibIAMp_sendMessage);
}

void Heavy_EQXG::cBinop_mTtPPXQl_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_ZS4D5O5k_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cMsg_ZS4D5O5k_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 0.0f, 0, m, &cBinop_PkH0k8Bf_sendMessage);
}

void Heavy_EQXG::cBinop_PkH0k8Bf_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_ey7rSAFu, HV_BINOP_MULTIPLY, 1, m, &cBinop_ey7rSAFu_sendMessage);
}

void Heavy_EQXG::cMsg_UoHAfXvl_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  cUnop_onMessage(_c, HV_UNOP_ATAN, m, &cUnop_T1py5ve3_sendMessage);
}

void Heavy_EQXG::cBinop_Yt0Jicxc_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_lde22gjG, HV_BINOP_DIVIDE, 0, m, &cBinop_lde22gjG_sendMessage);
}

void Heavy_EQXG::cCast_Lj0vKvzo_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_UoHAfXvl_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_lde22gjG_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_52uWYgrv, HV_BINOP_MULTIPLY, 1, m, &cBinop_52uWYgrv_sendMessage);
}

void Heavy_EQXG::cBinop_52uWYgrv_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_itCVvMKw_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_1DY8QKJq_sendMessage);
}

void Heavy_EQXG::cBinop_VpiPV1Gd_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 0.2f, 0, m, &cBinop_7MupAus5_sendMessage);
}

void Heavy_EQXG::cBinop_7MupAus5_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 3.0f, 0, m, &cBinop_rgOTUCrH_sendMessage);
}

void Heavy_EQXG::cUnop_vtbgcMVV_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_7ek1oqWC_sendMessage(_c, 0, m);
  cBinop_onMessage(_c, &Context(_c)->cBinop_fN3enji8, HV_BINOP_MULTIPLY, 0, m, &cBinop_fN3enji8_sendMessage);
}

void Heavy_EQXG::cUnop_ilxsDLaK_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_FkrS28SD_sendMessage(_c, 0, m);
  cBinop_onMessage(_c, &Context(_c)->cBinop_tf9PBytf, HV_BINOP_MULTIPLY, 0, m, &cBinop_tf9PBytf_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_vR2m7Zgi, HV_BINOP_MULTIPLY, 0, m, &cBinop_vR2m7Zgi_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_D00TzFPJ, HV_BINOP_MULTIPLY, 0, m, &cBinop_D00TzFPJ_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_F5Z7lB8D, HV_BINOP_MULTIPLY, 0, m, &cBinop_F5Z7lB8D_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_i7cOWIzw, HV_BINOP_MULTIPLY, 0, m, &cBinop_i7cOWIzw_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_PKqQbfjY, HV_BINOP_MULTIPLY, 0, m, &cBinop_PKqQbfjY_sendMessage);
}

void Heavy_EQXG::cBinop_vgykucFE_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 20.0f, 0, m, &cBinop_ifeUeQnN_sendMessage);
}

void Heavy_EQXG::cBinop_ifeUeQnN_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_KO2uv9Fi, HV_BINOP_MULTIPLY, 0, m, &cBinop_KO2uv9Fi_sendMessage);
}

void Heavy_EQXG::cVar_M3oQp4Ve_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_r9ztqeaF_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_5NCBTfPw_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, -24.0f, 0, m, &cBinop_1HAwkmcL_sendMessage);
}

void Heavy_EQXG::cBinop_1HAwkmcL_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 40.0f, 0, m, &cBinop_05mpVZsu_sendMessage);
}

void Heavy_EQXG::cVar_SHJb5Ynb_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_siUDVdDK_sendMessage);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 20000.0f, 0, m, &cBinop_vgykucFE_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_MjFHxnvC_sendMessage);
}

void Heavy_EQXG::cVar_wJEHGN67_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 100.0f, 0, m, &cBinop_OriLioCx_sendMessage);
}

void Heavy_EQXG::cVar_EFcqmf1S_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 24.0f, 0, m, &cBinop_5NCBTfPw_sendMessage);
}

void Heavy_EQXG::cUnop_jyTLC8hr_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 2.0f, 0, m, &cBinop_mdGdorGl_sendMessage);
}

void Heavy_EQXG::cMsg_z6aRaYvc_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setSymbol(m, 0, "samplerate");
  cSystem_onMessage(_c, NULL, 0, m, &cSystem_iFKMwxYw_sendMessage);
}

void Heavy_EQXG::cSystem_iFKMwxYw_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_726lQ9WK, HV_BINOP_DIVIDE, 1, m, &cBinop_726lQ9WK_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_8BSZWlf3_sendMessage);
}

void Heavy_EQXG::cUnop_RiANvkgV_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 8.0f, 0, m, &cBinop_TBV9IVhp_sendMessage);
}

void Heavy_EQXG::cBinop_uqAbNvhg_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_SHJb5Ynb, 0, m, &cVar_SHJb5Ynb_sendMessage);
}

void Heavy_EQXG::cBinop_7rRUO3rN_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 12.0f, 0, m, &cBinop_BwvbXfep_sendMessage);
}

void Heavy_EQXG::cBinop_BwvbXfep_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_VwIhOZJu, HV_BINOP_POW, 1, m, &cBinop_VwIhOZJu_sendMessage);
  cMsg_0ZaM3jsG_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_VwIhOZJu_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 440.0f, 0, m, &cBinop_uqAbNvhg_sendMessage);
}

void Heavy_EQXG::cMsg_0ZaM3jsG_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 2.0f);
  cBinop_onMessage(_c, &Context(_c)->cBinop_VwIhOZJu, HV_BINOP_POW, 0, m, &cBinop_VwIhOZJu_sendMessage);
}

void Heavy_EQXG::cIf_hPxtjKuy_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  switch (letIn) {
    case 0: {
      cMsg_kpaHv5tW_sendMessage(_c, 0, m);
      break;
    }
    case 1: {
      cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 440.0f, 0, m, &cBinop_JKkpphRv_sendMessage);
      break;
    }
    default: return;
  }
}

void Heavy_EQXG::cUnop_jO9GMmmW_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 12.0f, 0, m, &cBinop_pEfm562K_sendMessage);
}

void Heavy_EQXG::cBinop_JKkpphRv_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_LOG2, m, &cUnop_jO9GMmmW_sendMessage);
}

void Heavy_EQXG::cBinop_pEfm562K_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 69.0f, 0, m, &cBinop_ddU2H1g2_sendMessage);
}

void Heavy_EQXG::cBinop_ddU2H1g2_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 69.0f, 0, m, &cBinop_7rRUO3rN_sendMessage);
}

void Heavy_EQXG::cCast_hf67HOhZ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_GREATER_THAN, 0.0f, 0, m, &cBinop_HXwcDYI6_sendMessage);
}

void Heavy_EQXG::cCast_cKUHE21O_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cIf_onMessage(_c, &Context(_c)->cIf_hPxtjKuy, 0, m, &cIf_hPxtjKuy_sendMessage);
}

void Heavy_EQXG::cBinop_HXwcDYI6_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cIf_onMessage(_c, &Context(_c)->cIf_hPxtjKuy, 1, m, &cIf_hPxtjKuy_sendMessage);
}

void Heavy_EQXG::cMsg_kpaHv5tW_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, -1500.0f);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 69.0f, 0, m, &cBinop_7rRUO3rN_sendMessage);
}

void Heavy_EQXG::cBinop_OriLioCx_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 0.1f, 0, m, &cBinop_JhkJMkLe_sendMessage);
}

void Heavy_EQXG::cBinop_JhkJMkLe_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_x3EcdrRH_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_7HyeCdGz_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 0.1f, 0, m, &cBinop_SrY4aIYE_sendMessage);
}

void Heavy_EQXG::cBinop_SrY4aIYE_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_kUcO7wAK_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_WrZMPPhm_sendMessage);
}

void Heavy_EQXG::cMsg_VufFhwE2_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_ash1rAvt, 0, m, NULL);
}

void Heavy_EQXG::cMsg_iiCFXcFc_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_DrZuI3C7, 0, m, NULL);
}

void Heavy_EQXG::cMsg_R6k6nR3U_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_21dWG5fr, 0, m, NULL);
}

void Heavy_EQXG::cMsg_TT87KWO6_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_bmu98AIv, 0, m, NULL);
}

void Heavy_EQXG::cMsg_hugPSTMM_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_Dg5eZUUB, 0, m, NULL);
}

void Heavy_EQXG::cCast_JmfAmxF3_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_COS, m, &cUnop_ilxsDLaK_sendMessage);
}

void Heavy_EQXG::cCast_X92786mX_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_SIN, m, &cUnop_vtbgcMVV_sendMessage);
}

void Heavy_EQXG::cSend_7ek1oqWC_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cReceive_sETn01qM_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cSend_FkrS28SD_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cSend_hIvpriNV_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cMsg_x3EcdrRH_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 0.0f, 0, m, &cBinop_3xrHvlHd_sendMessage);
}

void Heavy_EQXG::cBinop_3xrHvlHd_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_fN3enji8, HV_BINOP_MULTIPLY, 1, m, &cBinop_fN3enji8_sendMessage);
}

void Heavy_EQXG::cBinop_fN3enji8_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 0.5f, 0, m, &cBinop_o280a4pI_sendMessage);
}

void Heavy_EQXG::cBinop_o280a4pI_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_AtypO6h7_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_7Z3thvID_sendMessage);
}

void Heavy_EQXG::cMsg_r9ztqeaF_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 0.0f, 0, m, &cBinop_36bU6pFT_sendMessage);
}

void Heavy_EQXG::cBinop_36bU6pFT_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_tFAD8uEp_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_JZoEkUpp_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_1M54WAvD_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_GvoqVTvl_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_SuX7CWMy_sendMessage);
}

void Heavy_EQXG::cBinop_ThndDvab_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_VufFhwE2_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_YGfCiaYk_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_iiCFXcFc_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_FYmNLWuE_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_R6k6nR3U_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_52nxqyyV_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_TT87KWO6_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_XJe9QmCK_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_hugPSTMM_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cCast_WrZMPPhm_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_SHJb5Ynb, 0, m, &cVar_SHJb5Ynb_sendMessage);
}

void Heavy_EQXG::cCast_kUcO7wAK_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_wJEHGN67, 1, m, &cVar_wJEHGN67_sendMessage);
}

void Heavy_EQXG::cCast_MjFHxnvC_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_M3oQp4Ve, 0, m, &cVar_M3oQp4Ve_sendMessage);
}

void Heavy_EQXG::cCast_siUDVdDK_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_wJEHGN67, 0, m, &cVar_wJEHGN67_sendMessage);
}

void Heavy_EQXG::cSend_43wbf5x7_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cBinop_05mpVZsu_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_0iIY8ZGt_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_LpZpH8TS_sendMessage);
}

void Heavy_EQXG::cCast_LpZpH8TS_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_plRXX4GU_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cCast_0iIY8ZGt_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_i4Nlf9D8, HV_BINOP_POW, 1, m, &cBinop_i4Nlf9D8_sendMessage);
}

void Heavy_EQXG::cMsg_plRXX4GU_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 10.0f);
  cBinop_onMessage(_c, &Context(_c)->cBinop_i4Nlf9D8, HV_BINOP_POW, 0, m, &cBinop_i4Nlf9D8_sendMessage);
}

void Heavy_EQXG::cBinop_i4Nlf9D8_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_I3H6IcfZ_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_fQZek5np_sendMessage);
}

void Heavy_EQXG::cCast_2aOJqMq0_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_SHJb5Ynb, 0, m, &cVar_SHJb5Ynb_sendMessage);
}

void Heavy_EQXG::cCast_cFfYNWbv_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_EFcqmf1S, 0, m, &cVar_EFcqmf1S_sendMessage);
}

void Heavy_EQXG::cCast_dAOgNjNh_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_EFcqmf1S, 0, m, &cVar_EFcqmf1S_sendMessage);
}

void Heavy_EQXG::cCast_0AzEPzan_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_SHJb5Ynb, 0, m, &cVar_SHJb5Ynb_sendMessage);
}

void Heavy_EQXG::cBinop_mdGdorGl_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_WJqwwhtg, HV_BINOP_MULTIPLY, 1, m, &cBinop_WJqwwhtg_sendMessage);
}

void Heavy_EQXG::cBinop_WJqwwhtg_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_1GDsC3bD_sendMessage(_c, 0, m);
  cBinop_onMessage(_c, &Context(_c)->cBinop_nAzcy9pH, HV_BINOP_ADD, 1, m, &cBinop_nAzcy9pH_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_zllYAxK9, HV_BINOP_ADD, 1, m, &cBinop_zllYAxK9_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_XwQmnbq4, HV_BINOP_SUBTRACT, 1, m, &cBinop_XwQmnbq4_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_XUhMlWKg, HV_BINOP_SUBTRACT, 1, m, &cBinop_XUhMlWKg_sendMessage);
}

void Heavy_EQXG::cCast_7Z3thvID_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_WJqwwhtg, HV_BINOP_MULTIPLY, 0, m, &cBinop_WJqwwhtg_sendMessage);
}

void Heavy_EQXG::cCast_AtypO6h7_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_hIvpriNV_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cCast_1M54WAvD_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_FYmNLWuE, HV_BINOP_MULTIPLY, 0, m, &cBinop_FYmNLWuE_sendMessage);
}

void Heavy_EQXG::cCast_JZoEkUpp_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_52nxqyyV, HV_BINOP_MULTIPLY, 0, m, &cBinop_52nxqyyV_sendMessage);
}

void Heavy_EQXG::cCast_SuX7CWMy_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_ThndDvab, HV_BINOP_MULTIPLY, 0, m, &cBinop_ThndDvab_sendMessage);
}

void Heavy_EQXG::cCast_tFAD8uEp_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_XJe9QmCK, HV_BINOP_MULTIPLY, 0, m, &cBinop_XJe9QmCK_sendMessage);
}

void Heavy_EQXG::cCast_GvoqVTvl_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_YGfCiaYk, HV_BINOP_MULTIPLY, 0, m, &cBinop_YGfCiaYk_sendMessage);
}

void Heavy_EQXG::cCast_fQZek5np_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_SQRT, m, &cUnop_jyTLC8hr_sendMessage);
}

void Heavy_EQXG::cCast_I3H6IcfZ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_43wbf5x7_sendMessage(_c, 0, m);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_l77u1hFz_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_9EDReQ3X_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_h6Osm9we_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_rckASi7w_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_iQLbUFMO_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_s3yrS5eV_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_Udf3BgTH_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_UehBKjQa_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_vkt3cQPq_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_cmhiMn4f_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_vYCifZ1N_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_13zxYc4z_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_rMurpjgV_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_R26t2V0I_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_LfbS2WhN_sendMessage);
}

void Heavy_EQXG::cSend_1GDsC3bD_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cMsg_AB6zpsC3_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  cUnop_onMessage(_c, HV_UNOP_ATAN, m, &cUnop_RiANvkgV_sendMessage);
}

void Heavy_EQXG::cBinop_TBV9IVhp_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_726lQ9WK, HV_BINOP_DIVIDE, 0, m, &cBinop_726lQ9WK_sendMessage);
}

void Heavy_EQXG::cCast_8BSZWlf3_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_AB6zpsC3_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_726lQ9WK_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_KO2uv9Fi, HV_BINOP_MULTIPLY, 1, m, &cBinop_KO2uv9Fi_sendMessage);
}

void Heavy_EQXG::cBinop_KO2uv9Fi_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_X92786mX_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_JmfAmxF3_sendMessage);
}

void Heavy_EQXG::cBinop_U7ZHDDdy_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -1.0f, 0, m, &cBinop_6KEl2dI0_sendMessage);
}

void Heavy_EQXG::cBinop_tf9PBytf_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_fkYtbevu, HV_BINOP_ADD, 0, m, &cBinop_fkYtbevu_sendMessage);
}

void Heavy_EQXG::cBinop_fkYtbevu_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_nAzcy9pH, HV_BINOP_ADD, 0, m, &cBinop_nAzcy9pH_sendMessage);
}

void Heavy_EQXG::cBinop_gd1gGpB3_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_fkYtbevu, HV_BINOP_ADD, 1, m, &cBinop_fkYtbevu_sendMessage);
}

void Heavy_EQXG::cCast_9EDReQ3X_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 1.0f, 0, m, &cBinop_U7ZHDDdy_sendMessage);
}

void Heavy_EQXG::cCast_l77u1hFz_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_gd1gGpB3_sendMessage);
}

void Heavy_EQXG::cBinop_nAzcy9pH_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_M3oQp4Ve, 1, m, &cVar_M3oQp4Ve_sendMessage);
}

void Heavy_EQXG::cBinop_6KEl2dI0_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_tf9PBytf, HV_BINOP_MULTIPLY, 1, m, &cBinop_tf9PBytf_sendMessage);
}

void Heavy_EQXG::cBinop_0hibnKX5_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_vR2m7Zgi, HV_BINOP_MULTIPLY, 1, m, &cBinop_vR2m7Zgi_sendMessage);
}

void Heavy_EQXG::cBinop_vR2m7Zgi_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_Nln7hMTr, HV_BINOP_ADD, 0, m, &cBinop_Nln7hMTr_sendMessage);
}

void Heavy_EQXG::cBinop_vfndx3m5_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_Nln7hMTr, HV_BINOP_ADD, 1, m, &cBinop_Nln7hMTr_sendMessage);
}

void Heavy_EQXG::cCast_iQLbUFMO_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 1.0f, 0, m, &cBinop_0hibnKX5_sendMessage);
}

void Heavy_EQXG::cCast_rckASi7w_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_vfndx3m5_sendMessage);
}

void Heavy_EQXG::cCast_h6Osm9we_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_13JXjWfK, HV_BINOP_MULTIPLY, 1, m, &cBinop_13JXjWfK_sendMessage);
}

void Heavy_EQXG::cBinop_13JXjWfK_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_ThndDvab, HV_BINOP_MULTIPLY, 1, m, &cBinop_ThndDvab_sendMessage);
}

void Heavy_EQXG::cBinop_Nln7hMTr_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_zllYAxK9, HV_BINOP_ADD, 0, m, &cBinop_zllYAxK9_sendMessage);
}

void Heavy_EQXG::cBinop_zllYAxK9_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_13JXjWfK, HV_BINOP_MULTIPLY, 0, m, &cBinop_13JXjWfK_sendMessage);
}

void Heavy_EQXG::cBinop_AgaoxF5M_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_GMGVSidx, HV_BINOP_ADD, 1, m, &cBinop_GMGVSidx_sendMessage);
}

void Heavy_EQXG::cBinop_1zDmVkmg_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_D00TzFPJ, HV_BINOP_MULTIPLY, 1, m, &cBinop_D00TzFPJ_sendMessage);
}

void Heavy_EQXG::cBinop_D00TzFPJ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_GMGVSidx, HV_BINOP_ADD, 0, m, &cBinop_GMGVSidx_sendMessage);
}

void Heavy_EQXG::cCast_UehBKjQa_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_1zDmVkmg_sendMessage);
}

void Heavy_EQXG::cCast_Udf3BgTH_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 1.0f, 0, m, &cBinop_AgaoxF5M_sendMessage);
}

void Heavy_EQXG::cCast_s3yrS5eV_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -2.0f, 0, m, &cBinop_0y0oTfqk_sendMessage);
}

void Heavy_EQXG::cBinop_0FLQ2YKl_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_YGfCiaYk, HV_BINOP_MULTIPLY, 1, m, &cBinop_YGfCiaYk_sendMessage);
}

void Heavy_EQXG::cBinop_GMGVSidx_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_0FLQ2YKl, HV_BINOP_MULTIPLY, 0, m, &cBinop_0FLQ2YKl_sendMessage);
}

void Heavy_EQXG::cBinop_0y0oTfqk_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_0FLQ2YKl, HV_BINOP_MULTIPLY, 1, m, &cBinop_0FLQ2YKl_sendMessage);
}

void Heavy_EQXG::cBinop_MMkLVjnp_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_F5Z7lB8D, HV_BINOP_MULTIPLY, 1, m, &cBinop_F5Z7lB8D_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_F5Z7lB8D, HV_BINOP_MULTIPLY, 0, m, &cBinop_F5Z7lB8D_sendMessage);
}

void Heavy_EQXG::cBinop_F5Z7lB8D_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_0bzDLlAS, HV_BINOP_ADD, 0, m, &cBinop_0bzDLlAS_sendMessage);
}

void Heavy_EQXG::cBinop_0bzDLlAS_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_XwQmnbq4, HV_BINOP_SUBTRACT, 0, m, &cBinop_XwQmnbq4_sendMessage);
}

void Heavy_EQXG::cBinop_Byk82mJp_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_0bzDLlAS, HV_BINOP_ADD, 1, m, &cBinop_0bzDLlAS_sendMessage);
}

void Heavy_EQXG::cBinop_XwQmnbq4_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_WULOXzmB, HV_BINOP_MULTIPLY, 0, m, &cBinop_WULOXzmB_sendMessage);
}

void Heavy_EQXG::cCast_vkt3cQPq_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_WULOXzmB, HV_BINOP_MULTIPLY, 1, m, &cBinop_WULOXzmB_sendMessage);
}

void Heavy_EQXG::cCast_cmhiMn4f_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_Byk82mJp_sendMessage);
}

void Heavy_EQXG::cCast_vYCifZ1N_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 1.0f, 0, m, &cBinop_MMkLVjnp_sendMessage);
}

void Heavy_EQXG::cBinop_WULOXzmB_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_FYmNLWuE, HV_BINOP_MULTIPLY, 1, m, &cBinop_FYmNLWuE_sendMessage);
}

void Heavy_EQXG::cBinop_SgRtBilL_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_XeK9sjnq, HV_BINOP_ADD, 1, m, &cBinop_XeK9sjnq_sendMessage);
}

void Heavy_EQXG::cBinop_XeK9sjnq_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 2.0f, 0, m, &cBinop_WLsmQ8Hi_sendMessage);
}

void Heavy_EQXG::cBinop_GjJhxsMB_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -1.0f, 0, m, &cBinop_6wchWmpw_sendMessage);
}

void Heavy_EQXG::cBinop_i7cOWIzw_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_XeK9sjnq, HV_BINOP_ADD, 0, m, &cBinop_XeK9sjnq_sendMessage);
}

void Heavy_EQXG::cCast_13zxYc4z_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 1.0f, 0, m, &cBinop_SgRtBilL_sendMessage);
}

void Heavy_EQXG::cCast_rMurpjgV_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_GjJhxsMB_sendMessage);
}

void Heavy_EQXG::cBinop_WLsmQ8Hi_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_52nxqyyV, HV_BINOP_MULTIPLY, 1, m, &cBinop_52nxqyyV_sendMessage);
}

void Heavy_EQXG::cBinop_6wchWmpw_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_i7cOWIzw, HV_BINOP_MULTIPLY, 1, m, &cBinop_i7cOWIzw_sendMessage);
}

void Heavy_EQXG::cBinop_3S9aUh8D_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -1.0f, 0, m, &cBinop_RwgWuxDe_sendMessage);
}

void Heavy_EQXG::cBinop_PKqQbfjY_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_GpBW1SB8, HV_BINOP_ADD, 0, m, &cBinop_GpBW1SB8_sendMessage);
}

void Heavy_EQXG::cBinop_GpBW1SB8_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_XUhMlWKg, HV_BINOP_SUBTRACT, 0, m, &cBinop_XUhMlWKg_sendMessage);
}

void Heavy_EQXG::cBinop_joWbRvMO_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_GpBW1SB8, HV_BINOP_ADD, 1, m, &cBinop_GpBW1SB8_sendMessage);
}

void Heavy_EQXG::cCast_LfbS2WhN_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 1.0f, 0, m, &cBinop_3S9aUh8D_sendMessage);
}

void Heavy_EQXG::cCast_R26t2V0I_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_joWbRvMO_sendMessage);
}

void Heavy_EQXG::cBinop_XUhMlWKg_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_XJe9QmCK, HV_BINOP_MULTIPLY, 1, m, &cBinop_XJe9QmCK_sendMessage);
}

void Heavy_EQXG::cBinop_RwgWuxDe_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_PKqQbfjY, HV_BINOP_MULTIPLY, 1, m, &cBinop_PKqQbfjY_sendMessage);
}

void Heavy_EQXG::cBinop_yjUIc8pD_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 0.2f, 0, m, &cBinop_3QDnPD2i_sendMessage);
}

void Heavy_EQXG::cBinop_3QDnPD2i_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 3.0f, 0, m, &cBinop_7HyeCdGz_sendMessage);
}

void Heavy_EQXG::cUnop_zIbjPcGw_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_hYq8HO2f_sendMessage(_c, 0, m);
  cBinop_onMessage(_c, &Context(_c)->cBinop_PeWNsROi, HV_BINOP_MULTIPLY, 0, m, &cBinop_PeWNsROi_sendMessage);
}

void Heavy_EQXG::cUnop_EsinmAUl_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_vWzqS0XU_sendMessage(_c, 0, m);
  cBinop_onMessage(_c, &Context(_c)->cBinop_PDa1hSnp, HV_BINOP_MULTIPLY, 0, m, &cBinop_PDa1hSnp_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_DV2iIsRs, HV_BINOP_MULTIPLY, 0, m, &cBinop_DV2iIsRs_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_RHySeYtN, HV_BINOP_MULTIPLY, 0, m, &cBinop_RHySeYtN_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_RQxBgPhx, HV_BINOP_MULTIPLY, 0, m, &cBinop_RQxBgPhx_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_cbtP7agn, HV_BINOP_MULTIPLY, 0, m, &cBinop_cbtP7agn_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_btEpF8I6, HV_BINOP_MULTIPLY, 0, m, &cBinop_btEpF8I6_sendMessage);
}

void Heavy_EQXG::cBinop_Xqcn5u3J_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 20.0f, 0, m, &cBinop_L7VnBAuW_sendMessage);
}

void Heavy_EQXG::cBinop_L7VnBAuW_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_szOx6k8q, HV_BINOP_MULTIPLY, 0, m, &cBinop_szOx6k8q_sendMessage);
}

void Heavy_EQXG::cVar_RFDk3Fcc_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_ofiB07lj_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_GLjX4TFF_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, -24.0f, 0, m, &cBinop_DCcTeflH_sendMessage);
}

void Heavy_EQXG::cBinop_DCcTeflH_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 40.0f, 0, m, &cBinop_VMJ3h4mX_sendMessage);
}

void Heavy_EQXG::cVar_IbwJ1A2I_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_xsiHEDOh_sendMessage);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 20000.0f, 0, m, &cBinop_Xqcn5u3J_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_KpvOcb0k_sendMessage);
}

void Heavy_EQXG::cVar_F3oBGzNB_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 100.0f, 0, m, &cBinop_dihwHIKc_sendMessage);
}

void Heavy_EQXG::cVar_aJK8Z7Zx_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 24.0f, 0, m, &cBinop_GLjX4TFF_sendMessage);
}

void Heavy_EQXG::cUnop_oUAoBvrJ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 2.0f, 0, m, &cBinop_zdm0hhVz_sendMessage);
}

void Heavy_EQXG::cMsg_FbKonHpH_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setSymbol(m, 0, "samplerate");
  cSystem_onMessage(_c, NULL, 0, m, &cSystem_QT5HI0EI_sendMessage);
}

void Heavy_EQXG::cSystem_QT5HI0EI_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_OMxLiEzC, HV_BINOP_DIVIDE, 1, m, &cBinop_OMxLiEzC_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_ETLc5b9a_sendMessage);
}

void Heavy_EQXG::cUnop_9PY93ZWe_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 8.0f, 0, m, &cBinop_ktgs3cCq_sendMessage);
}

void Heavy_EQXG::cBinop_TcPQgihY_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_IbwJ1A2I, 0, m, &cVar_IbwJ1A2I_sendMessage);
}

void Heavy_EQXG::cBinop_dNjFpgiD_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 12.0f, 0, m, &cBinop_pjnFUkQx_sendMessage);
}

void Heavy_EQXG::cBinop_pjnFUkQx_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_sKjq2O7D, HV_BINOP_POW, 1, m, &cBinop_sKjq2O7D_sendMessage);
  cMsg_ZywHwPBi_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_sKjq2O7D_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 440.0f, 0, m, &cBinop_TcPQgihY_sendMessage);
}

void Heavy_EQXG::cMsg_ZywHwPBi_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 2.0f);
  cBinop_onMessage(_c, &Context(_c)->cBinop_sKjq2O7D, HV_BINOP_POW, 0, m, &cBinop_sKjq2O7D_sendMessage);
}

void Heavy_EQXG::cIf_0QrFuHq1_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  switch (letIn) {
    case 0: {
      cMsg_1mJS3WjU_sendMessage(_c, 0, m);
      break;
    }
    case 1: {
      cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 440.0f, 0, m, &cBinop_WTipcfb6_sendMessage);
      break;
    }
    default: return;
  }
}

void Heavy_EQXG::cUnop_vnK0Dyc3_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 12.0f, 0, m, &cBinop_RYvzXK7Q_sendMessage);
}

void Heavy_EQXG::cBinop_WTipcfb6_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_LOG2, m, &cUnop_vnK0Dyc3_sendMessage);
}

void Heavy_EQXG::cBinop_RYvzXK7Q_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 69.0f, 0, m, &cBinop_hiLv83Js_sendMessage);
}

void Heavy_EQXG::cBinop_hiLv83Js_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 69.0f, 0, m, &cBinop_dNjFpgiD_sendMessage);
}

void Heavy_EQXG::cCast_XwFw5ZMu_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cIf_onMessage(_c, &Context(_c)->cIf_0QrFuHq1, 0, m, &cIf_0QrFuHq1_sendMessage);
}

void Heavy_EQXG::cCast_4epP6vZs_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_GREATER_THAN, 0.0f, 0, m, &cBinop_g6ejIURS_sendMessage);
}

void Heavy_EQXG::cBinop_g6ejIURS_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cIf_onMessage(_c, &Context(_c)->cIf_0QrFuHq1, 1, m, &cIf_0QrFuHq1_sendMessage);
}

void Heavy_EQXG::cMsg_1mJS3WjU_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, -1500.0f);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 69.0f, 0, m, &cBinop_dNjFpgiD_sendMessage);
}

void Heavy_EQXG::cBinop_CshGex4m_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 0.1f, 0, m, &cBinop_35DHWZVk_sendMessage);
}

void Heavy_EQXG::cBinop_35DHWZVk_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_6TPkqD2T_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_SKrtJX3O_sendMessage);
}

void Heavy_EQXG::cBinop_dihwHIKc_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 0.1f, 0, m, &cBinop_lZGjLgcC_sendMessage);
}

void Heavy_EQXG::cBinop_lZGjLgcC_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_5wsQKa1g_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cMsg_bEAWlCsI_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_OzcbV3S7, 0, m, NULL);
}

void Heavy_EQXG::cMsg_OSuuDheU_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_gCEJnBeR, 0, m, NULL);
}

void Heavy_EQXG::cMsg_QqrcvFTl_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_ZckGuuDs, 0, m, NULL);
}

void Heavy_EQXG::cMsg_8b6mPF3b_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_5mGWt5zM, 0, m, NULL);
}

void Heavy_EQXG::cMsg_KS9rPdfg_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setElementToFrom(m, 0, n, 0);
  msg_setFloat(m, 1, 10.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_9E0MgvAm, 0, m, NULL);
}

void Heavy_EQXG::cCast_6ZB4arB6_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_COS, m, &cUnop_EsinmAUl_sendMessage);
}

void Heavy_EQXG::cCast_nM1Jm9Gq_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_SIN, m, &cUnop_zIbjPcGw_sendMessage);
}

void Heavy_EQXG::cSend_hYq8HO2f_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cReceive_sETn01qM_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cSend_vWzqS0XU_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cSend_3yJ9VeKt_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cMsg_5wsQKa1g_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 0.0f, 0, m, &cBinop_UYeLraoO_sendMessage);
}

void Heavy_EQXG::cBinop_UYeLraoO_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_PeWNsROi, HV_BINOP_MULTIPLY, 1, m, &cBinop_PeWNsROi_sendMessage);
}

void Heavy_EQXG::cBinop_PeWNsROi_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 0.5f, 0, m, &cBinop_qwyb14RL_sendMessage);
}

void Heavy_EQXG::cBinop_qwyb14RL_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_5yIdMwpt_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_taXTiZN6_sendMessage);
}

void Heavy_EQXG::cMsg_ofiB07lj_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 0.0f, 0, m, &cBinop_Pyb6lyYn_sendMessage);
}

void Heavy_EQXG::cBinop_Pyb6lyYn_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_CLbTXQcp_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_EcCoxsUI_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_1yrJxmE7_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_7ZKeTAVM_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_V9VmyCSM_sendMessage);
}

void Heavy_EQXG::cBinop_0uBhdAT2_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_bEAWlCsI_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_xLKz4gsf_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_OSuuDheU_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_PAKkz2sB_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_QqrcvFTl_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_npXMRj4V_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_8b6mPF3b_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_JSHQxc1D_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_KS9rPdfg_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cCast_SKrtJX3O_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_IbwJ1A2I, 0, m, &cVar_IbwJ1A2I_sendMessage);
}

void Heavy_EQXG::cCast_6TPkqD2T_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_F3oBGzNB, 1, m, &cVar_F3oBGzNB_sendMessage);
}

void Heavy_EQXG::cCast_KpvOcb0k_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_RFDk3Fcc, 0, m, &cVar_RFDk3Fcc_sendMessage);
}

void Heavy_EQXG::cCast_xsiHEDOh_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_F3oBGzNB, 0, m, &cVar_F3oBGzNB_sendMessage);
}

void Heavy_EQXG::cSend_u5T0VXvo_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cBinop_VMJ3h4mX_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_TnBKpDbH_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_k5iKamN0_sendMessage);
}

void Heavy_EQXG::cCast_TnBKpDbH_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_A4Ky0zBO, HV_BINOP_POW, 1, m, &cBinop_A4Ky0zBO_sendMessage);
}

void Heavy_EQXG::cCast_k5iKamN0_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_K6WsXez8_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cMsg_K6WsXez8_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 10.0f);
  cBinop_onMessage(_c, &Context(_c)->cBinop_A4Ky0zBO, HV_BINOP_POW, 0, m, &cBinop_A4Ky0zBO_sendMessage);
}

void Heavy_EQXG::cBinop_A4Ky0zBO_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_wcfk5onx_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_CYagtx6w_sendMessage);
}

void Heavy_EQXG::cCast_NsYj5ptU_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_IbwJ1A2I, 0, m, &cVar_IbwJ1A2I_sendMessage);
}

void Heavy_EQXG::cCast_OK34KQ45_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_aJK8Z7Zx, 0, m, &cVar_aJK8Z7Zx_sendMessage);
}

void Heavy_EQXG::cCast_lEtb9ANA_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_aJK8Z7Zx, 0, m, &cVar_aJK8Z7Zx_sendMessage);
}

void Heavy_EQXG::cCast_2RLLTSO3_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_IbwJ1A2I, 0, m, &cVar_IbwJ1A2I_sendMessage);
}

void Heavy_EQXG::cBinop_zdm0hhVz_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_YHWEnaKF, HV_BINOP_MULTIPLY, 1, m, &cBinop_YHWEnaKF_sendMessage);
}

void Heavy_EQXG::cBinop_YHWEnaKF_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_PI6AN0tt_sendMessage(_c, 0, m);
  cBinop_onMessage(_c, &Context(_c)->cBinop_svft0jJU, HV_BINOP_ADD, 1, m, &cBinop_svft0jJU_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_fNox5GFo, HV_BINOP_ADD, 1, m, &cBinop_fNox5GFo_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_xVUbs3aG, HV_BINOP_SUBTRACT, 1, m, &cBinop_xVUbs3aG_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_o3TKnGQP, HV_BINOP_SUBTRACT, 1, m, &cBinop_o3TKnGQP_sendMessage);
}

void Heavy_EQXG::cCast_taXTiZN6_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_YHWEnaKF, HV_BINOP_MULTIPLY, 0, m, &cBinop_YHWEnaKF_sendMessage);
}

void Heavy_EQXG::cCast_5yIdMwpt_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_3yJ9VeKt_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cCast_1yrJxmE7_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_PAKkz2sB, HV_BINOP_MULTIPLY, 0, m, &cBinop_PAKkz2sB_sendMessage);
}

void Heavy_EQXG::cCast_EcCoxsUI_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_npXMRj4V, HV_BINOP_MULTIPLY, 0, m, &cBinop_npXMRj4V_sendMessage);
}

void Heavy_EQXG::cCast_V9VmyCSM_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_0uBhdAT2, HV_BINOP_MULTIPLY, 0, m, &cBinop_0uBhdAT2_sendMessage);
}

void Heavy_EQXG::cCast_CLbTXQcp_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_JSHQxc1D, HV_BINOP_MULTIPLY, 0, m, &cBinop_JSHQxc1D_sendMessage);
}

void Heavy_EQXG::cCast_7ZKeTAVM_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_xLKz4gsf, HV_BINOP_MULTIPLY, 0, m, &cBinop_xLKz4gsf_sendMessage);
}

void Heavy_EQXG::cCast_wcfk5onx_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cSend_u5T0VXvo_sendMessage(_c, 0, m);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_c0X81ErV_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_xxsJMab1_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_8DsUB41U_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_1lbGCVgB_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_MfKHtjbO_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_qMeDhPOY_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_Y7vElsPo_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_jxmnnMWz_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_V6fXjxdc_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_30nq3flG_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_eQxCUda3_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_IcIbrAcE_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_NyaCUtfm_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_gVYfOqGW_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_TSNm0dQO_sendMessage);
}

void Heavy_EQXG::cCast_CYagtx6w_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cUnop_onMessage(_c, HV_UNOP_SQRT, m, &cUnop_oUAoBvrJ_sendMessage);
}

void Heavy_EQXG::cSend_PI6AN0tt_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
}

void Heavy_EQXG::cMsg_69QYeORQ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  cUnop_onMessage(_c, HV_UNOP_ATAN, m, &cUnop_9PY93ZWe_sendMessage);
}

void Heavy_EQXG::cBinop_ktgs3cCq_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_OMxLiEzC, HV_BINOP_DIVIDE, 0, m, &cBinop_OMxLiEzC_sendMessage);
}

void Heavy_EQXG::cCast_ETLc5b9a_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_69QYeORQ_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cBinop_OMxLiEzC_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_szOx6k8q, HV_BINOP_MULTIPLY, 1, m, &cBinop_szOx6k8q_sendMessage);
}

void Heavy_EQXG::cBinop_szOx6k8q_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_nM1Jm9Gq_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_6ZB4arB6_sendMessage);
}

void Heavy_EQXG::cBinop_7PTkO5qo_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -1.0f, 0, m, &cBinop_zK9Sao0q_sendMessage);
}

void Heavy_EQXG::cBinop_PDa1hSnp_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_c0iBPaVV, HV_BINOP_ADD, 0, m, &cBinop_c0iBPaVV_sendMessage);
}

void Heavy_EQXG::cBinop_c0iBPaVV_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_svft0jJU, HV_BINOP_ADD, 0, m, &cBinop_svft0jJU_sendMessage);
}

void Heavy_EQXG::cBinop_39zliifx_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_c0iBPaVV, HV_BINOP_ADD, 1, m, &cBinop_c0iBPaVV_sendMessage);
}

void Heavy_EQXG::cCast_c0X81ErV_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_39zliifx_sendMessage);
}

void Heavy_EQXG::cCast_xxsJMab1_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 1.0f, 0, m, &cBinop_7PTkO5qo_sendMessage);
}

void Heavy_EQXG::cBinop_svft0jJU_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_RFDk3Fcc, 1, m, &cVar_RFDk3Fcc_sendMessage);
}

void Heavy_EQXG::cBinop_zK9Sao0q_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_PDa1hSnp, HV_BINOP_MULTIPLY, 1, m, &cBinop_PDa1hSnp_sendMessage);
}

void Heavy_EQXG::cBinop_IxjuRY6z_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_DV2iIsRs, HV_BINOP_MULTIPLY, 1, m, &cBinop_DV2iIsRs_sendMessage);
}

void Heavy_EQXG::cBinop_DV2iIsRs_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_dQe8j2Ro, HV_BINOP_ADD, 0, m, &cBinop_dQe8j2Ro_sendMessage);
}

void Heavy_EQXG::cBinop_p8ipZRgw_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_dQe8j2Ro, HV_BINOP_ADD, 1, m, &cBinop_dQe8j2Ro_sendMessage);
}

void Heavy_EQXG::cCast_1lbGCVgB_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_p8ipZRgw_sendMessage);
}

void Heavy_EQXG::cCast_8DsUB41U_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_3eI1PbLG, HV_BINOP_MULTIPLY, 1, m, &cBinop_3eI1PbLG_sendMessage);
}

void Heavy_EQXG::cCast_MfKHtjbO_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 1.0f, 0, m, &cBinop_IxjuRY6z_sendMessage);
}

void Heavy_EQXG::cBinop_3eI1PbLG_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_0uBhdAT2, HV_BINOP_MULTIPLY, 1, m, &cBinop_0uBhdAT2_sendMessage);
}

void Heavy_EQXG::cBinop_dQe8j2Ro_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_fNox5GFo, HV_BINOP_ADD, 0, m, &cBinop_fNox5GFo_sendMessage);
}

void Heavy_EQXG::cBinop_fNox5GFo_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_3eI1PbLG, HV_BINOP_MULTIPLY, 0, m, &cBinop_3eI1PbLG_sendMessage);
}

void Heavy_EQXG::cBinop_2tJvSQyt_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_loZzczJH, HV_BINOP_ADD, 1, m, &cBinop_loZzczJH_sendMessage);
}

void Heavy_EQXG::cBinop_cUvH21kq_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_RHySeYtN, HV_BINOP_MULTIPLY, 1, m, &cBinop_RHySeYtN_sendMessage);
}

void Heavy_EQXG::cBinop_RHySeYtN_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_loZzczJH, HV_BINOP_ADD, 0, m, &cBinop_loZzczJH_sendMessage);
}

void Heavy_EQXG::cCast_qMeDhPOY_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -2.0f, 0, m, &cBinop_o7n5SRri_sendMessage);
}

void Heavy_EQXG::cCast_Y7vElsPo_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 1.0f, 0, m, &cBinop_2tJvSQyt_sendMessage);
}

void Heavy_EQXG::cCast_jxmnnMWz_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_cUvH21kq_sendMessage);
}

void Heavy_EQXG::cBinop_fT7eVLpo_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_xLKz4gsf, HV_BINOP_MULTIPLY, 1, m, &cBinop_xLKz4gsf_sendMessage);
}

void Heavy_EQXG::cBinop_loZzczJH_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_fT7eVLpo, HV_BINOP_MULTIPLY, 0, m, &cBinop_fT7eVLpo_sendMessage);
}

void Heavy_EQXG::cBinop_o7n5SRri_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_fT7eVLpo, HV_BINOP_MULTIPLY, 1, m, &cBinop_fT7eVLpo_sendMessage);
}

void Heavy_EQXG::cBinop_M5Ynz17P_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_RQxBgPhx, HV_BINOP_MULTIPLY, 1, m, &cBinop_RQxBgPhx_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_RQxBgPhx, HV_BINOP_MULTIPLY, 0, m, &cBinop_RQxBgPhx_sendMessage);
}

void Heavy_EQXG::cBinop_RQxBgPhx_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_CvFRt24M, HV_BINOP_ADD, 0, m, &cBinop_CvFRt24M_sendMessage);
}

void Heavy_EQXG::cBinop_CvFRt24M_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_xVUbs3aG, HV_BINOP_SUBTRACT, 0, m, &cBinop_xVUbs3aG_sendMessage);
}

void Heavy_EQXG::cBinop_yAiWNlHp_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_CvFRt24M, HV_BINOP_ADD, 1, m, &cBinop_CvFRt24M_sendMessage);
}

void Heavy_EQXG::cBinop_xVUbs3aG_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_5ZIb5bXT, HV_BINOP_MULTIPLY, 0, m, &cBinop_5ZIb5bXT_sendMessage);
}

void Heavy_EQXG::cCast_30nq3flG_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_yAiWNlHp_sendMessage);
}

void Heavy_EQXG::cCast_eQxCUda3_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 1.0f, 0, m, &cBinop_M5Ynz17P_sendMessage);
}

void Heavy_EQXG::cCast_V6fXjxdc_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_5ZIb5bXT, HV_BINOP_MULTIPLY, 1, m, &cBinop_5ZIb5bXT_sendMessage);
}

void Heavy_EQXG::cBinop_5ZIb5bXT_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_PAKkz2sB, HV_BINOP_MULTIPLY, 1, m, &cBinop_PAKkz2sB_sendMessage);
}

void Heavy_EQXG::cBinop_G573rdMi_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_Q1GuReFw, HV_BINOP_ADD, 1, m, &cBinop_Q1GuReFw_sendMessage);
}

void Heavy_EQXG::cBinop_Q1GuReFw_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 2.0f, 0, m, &cBinop_I242LwjO_sendMessage);
}

void Heavy_EQXG::cBinop_5vHsA72N_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -1.0f, 0, m, &cBinop_t1jSrdX2_sendMessage);
}

void Heavy_EQXG::cBinop_cbtP7agn_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_Q1GuReFw, HV_BINOP_ADD, 0, m, &cBinop_Q1GuReFw_sendMessage);
}

void Heavy_EQXG::cCast_IcIbrAcE_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 1.0f, 0, m, &cBinop_G573rdMi_sendMessage);
}

void Heavy_EQXG::cCast_NyaCUtfm_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_5vHsA72N_sendMessage);
}

void Heavy_EQXG::cBinop_I242LwjO_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_npXMRj4V, HV_BINOP_MULTIPLY, 1, m, &cBinop_npXMRj4V_sendMessage);
}

void Heavy_EQXG::cBinop_t1jSrdX2_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_cbtP7agn, HV_BINOP_MULTIPLY, 1, m, &cBinop_cbtP7agn_sendMessage);
}

void Heavy_EQXG::cBinop_AR5o86bQ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, -1.0f, 0, m, &cBinop_xpqmzi1k_sendMessage);
}

void Heavy_EQXG::cBinop_btEpF8I6_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_wkTxKhXH, HV_BINOP_ADD, 0, m, &cBinop_wkTxKhXH_sendMessage);
}

void Heavy_EQXG::cBinop_wkTxKhXH_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_o3TKnGQP, HV_BINOP_SUBTRACT, 0, m, &cBinop_o3TKnGQP_sendMessage);
}

void Heavy_EQXG::cBinop_kxT39s8c_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_wkTxKhXH, HV_BINOP_ADD, 1, m, &cBinop_wkTxKhXH_sendMessage);
}

void Heavy_EQXG::cCast_gVYfOqGW_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1.0f, 0, m, &cBinop_kxT39s8c_sendMessage);
}

void Heavy_EQXG::cCast_TSNm0dQO_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 1.0f, 0, m, &cBinop_AR5o86bQ_sendMessage);
}

void Heavy_EQXG::cBinop_o3TKnGQP_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_JSHQxc1D, HV_BINOP_MULTIPLY, 1, m, &cBinop_JSHQxc1D_sendMessage);
}

void Heavy_EQXG::cBinop_xpqmzi1k_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_btEpF8I6, HV_BINOP_MULTIPLY, 1, m, &cBinop_btEpF8I6_sendMessage);
}

void Heavy_EQXG::cBinop_dz0idCbn_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 0.2f, 0, m, &cBinop_tv25iyLc_sendMessage);
}

void Heavy_EQXG::cBinop_tv25iyLc_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 3.0f, 0, m, &cBinop_CshGex4m_sendMessage);
}

void Heavy_EQXG::cExpr_ACaiVDZs_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  sVarf_onMessage(_c, &Context(_c)->sVarf_auxpCdpT, m);
  sVarf_onMessage(_c, &Context(_c)->sVarf_IO2nLrVI, m);
}

float Heavy_EQXG::cExpr_ACaiVDZs_evaluate(const float* args) {
  	return ((float)(args[0])) / 10;
}

void Heavy_EQXG::cExpr_rGnQ6PCJ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  sVarf_onMessage(_c, &Context(_c)->sVarf_C4FV78so, m);
  sVarf_onMessage(_c, &Context(_c)->sVarf_52RZEkY8, m);
}

float Heavy_EQXG::cExpr_rGnQ6PCJ_evaluate(const float* args) {
  	return ((float)(args[0])) / 10;
}

void Heavy_EQXG::cVar_ArBpLlYR_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_qJGdv7wZ_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_ujGtMhWa_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_XvW8K2u5_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_hdl2TR08_sendMessage);
}

void Heavy_EQXG::cVar_ZdOguBOi_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_LXyLdGKE_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_eS7RKjkt_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_smlZreZr_sendMessage);
  cCast_onMessage(_c, HV_CAST_FLOAT, 0, m, &cCast_TOzaZisJ_sendMessage);
}

void Heavy_EQXG::cReceive_sETn01qM_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_xmME8jTe, HV_BINOP_MULTIPLY, 0, m, &cBinop_xmME8jTe_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_XDkxgdjQ, HV_BINOP_MULTIPLY, 0, m, &cBinop_XDkxgdjQ_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_mjHowSRL, HV_BINOP_MULTIPLY, 0, m, &cBinop_mjHowSRL_sendMessage);
  cBinop_onMessage(_c, &Context(_c)->cBinop_Y4ATJTUd, HV_BINOP_MULTIPLY, 0, m, &cBinop_Y4ATJTUd_sendMessage);
}

void Heavy_EQXG::cReceive_5TU0b4z2_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_1YsbiTXI_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_OSg9Cp2v_sendMessage);
  cMsg_r2nB1aCr_sendMessage(_c, 0, m);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_mqtGSCWy_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_uqdqcmfA_sendMessage);
  cMsg_EcpnNrhI_sendMessage(_c, 0, m);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_LMThCY30_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_fMPYcni4_sendMessage);
  cMsg_Aawzbz4H_sendMessage(_c, 0, m);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_KMDyXfku_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_4ale86bw_sendMessage);
  cMsg_jqbaNu97_sendMessage(_c, 0, m);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_dKIey1w5_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_mS6NvoeK_sendMessage);
  cMsg_LYp0Ygs4_sendMessage(_c, 0, m);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_UbxAwkhq_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_Fw9et5It_sendMessage);
  cMsg_FJHCNNHG_sendMessage(_c, 0, m);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_dAOgNjNh_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_0AzEPzan_sendMessage);
  cMsg_z6aRaYvc_sendMessage(_c, 0, m);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_lEtb9ANA_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_2RLLTSO3_sendMessage);
  cMsg_FbKonHpH_sendMessage(_c, 0, m);
}

void Heavy_EQXG::cReceive_YycZaRiu_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_l0We788u, 0, m, &cVar_l0We788u_sendMessage);
}

void Heavy_EQXG::cReceive_dwuZER69_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_3UFyK7Cd, 0, m, &cVar_3UFyK7Cd_sendMessage);
}

void Heavy_EQXG::cReceive_OFDmCy9C_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_V9hQ4Qon, 0, m, &cVar_V9hQ4Qon_sendMessage);
}

void Heavy_EQXG::cReceive_UinlIhJL_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_7VpUeZAn, 0, m, &cVar_7VpUeZAn_sendMessage);
}

void Heavy_EQXG::cReceive_vIcGdniV_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_LZhobZcH, 0, m, &cVar_LZhobZcH_sendMessage);
}

void Heavy_EQXG::cReceive_P3ajtPLY_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_0cjZ6r5S, 0, m, &cVar_0cjZ6r5S_sendMessage);
}

void Heavy_EQXG::cReceive_KINERtMe_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_JpOdF2Ww, 0, m, &cVar_JpOdF2Ww_sendMessage);
}

void Heavy_EQXG::cReceive_HLJOjE3V_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_6KGdmx3c, 0, m, &cVar_6KGdmx3c_sendMessage);
}

void Heavy_EQXG::cReceive_T8uOsa4p_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_w4qHAfcN, 0, m, &cVar_w4qHAfcN_sendMessage);
}

void Heavy_EQXG::cReceive_1EFEUnSY_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_Uk1jXxWe, 0, m, &cVar_Uk1jXxWe_sendMessage);
}

void Heavy_EQXG::cReceive_ymQeFfZQ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_NdC6URMp, 0, m, &cVar_NdC6URMp_sendMessage);
}

void Heavy_EQXG::cReceive_kLoG54H5_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_0OkImWsp, 0, m, &cVar_0OkImWsp_sendMessage);
}

void Heavy_EQXG::cReceive_Nhj9GLBN_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_vb33XxG3, 0, m, &cVar_vb33XxG3_sendMessage);
}

void Heavy_EQXG::cReceive_grhiBA9v_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_C1CtRy2Y, 0, m, &cVar_C1CtRy2Y_sendMessage);
}

void Heavy_EQXG::cReceive_Mmt0bjH7_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_1ndrvePX, 0, m, &cVar_1ndrvePX_sendMessage);
}

void Heavy_EQXG::cReceive_vh5cTuVK_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_PEjDmpB9, 0, m, &cVar_PEjDmpB9_sendMessage);
}

void Heavy_EQXG::cReceive_WYIQQJvS_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_ArBpLlYR, 0, m, &cVar_ArBpLlYR_sendMessage);
}

void Heavy_EQXG::cReceive_AR0E0n41_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_ZdOguBOi, 0, m, &cVar_ZdOguBOi_sendMessage);
}



/*
 * Code for expr~ implementation
 * Write out the generic implementation code
 */

 // per class code

 // per object code


/*
 * Context Process Implementation
 */

int Heavy_EQXG::process(float **inputBuffers, float **outputBuffers, int n) {
  while (hLp_hasData(&inQueue)) {
    hv_uint32_t numBytes = 0;
    ReceiverMessagePair *p = reinterpret_cast<ReceiverMessagePair *>(hLp_getReadBuffer(&inQueue, &numBytes));
    hv_assert(numBytes >= sizeof(ReceiverMessagePair));
    scheduleMessageForReceiver(p->receiverHash, &p->msg);
    hLp_consume(&inQueue);
  }

  sendBangToReceiver(0xDD21C0EB); // send to __hv_bang~ on next cycle
  const int n4 = n & ~HV_N_SIMD_MASK; // ensure that the block size is a multiple of HV_N_SIMD

  // temporary signal vars
  hv_bufferf_t Bf0, Bf1, Bf2, Bf3, Bf4, Bf5, Bf6, Bf7, Bf8;

  // input and output vars
  hv_bufferf_t O0, O1;
  hv_bufferf_t I0, I1;

  // declare and init the zero buffer
  hv_bufferf_t ZERO; __hv_zero_f(VOf(ZERO));

  hv_uint32_t nextBlock = blockStartTimestamp;
  for (int n = 0; n < n4; n += HV_N_SIMD) {

    // process all of the messages for this block
    nextBlock += HV_N_SIMD;
    while (mq_hasMessageBefore(&mq, nextBlock)) {
      MessageNode *const node = mq_peek(&mq);
      node->sendMessage(this, node->let, node->m);
      mq_pop(&mq);
    }

    // load input buffers
    __hv_load_f(inputBuffers[0]+n, VOf(I0));
    __hv_load_f(inputBuffers[1]+n, VOf(I1));

    // zero output buffers
    __hv_zero_f(VOf(O0));
    __hv_zero_f(VOf(O1));

    // process all signal functions
    __hv_varread_f(&sVarf_7fsqzj0S, VOf(Bf0));
    __hv_mul_f(VIf(I0), VIf(Bf0), VOf(Bf0));
    __hv_varread_f(&sVarf_qdb4mxol, VOf(Bf1));
    __hv_mul_f(VIf(I1), VIf(Bf1), VOf(Bf1));
    __hv_line_f(&sLine_a1h8OI0F, VOf(Bf2));
    __hv_line_f(&sLine_iXq9G3dq, VOf(Bf3));
    __hv_line_f(&sLine_J8bo8D5A, VOf(Bf4));
    __hv_line_f(&sLine_nQC9UoFF, VOf(Bf5));
    __hv_line_f(&sLine_Fdgoci8h, VOf(Bf6));
    __hv_biquad_f(&sBiquad_s_Tci8RSJ6, VIf(Bf0), VIf(Bf2), VIf(Bf3), VIf(Bf4), VIf(Bf5), VIf(Bf6), VOf(Bf6));
    __hv_line_f(&sLine_bLFyKYuK, VOf(Bf5));
    __hv_line_f(&sLine_h3r8mTrw, VOf(Bf4));
    __hv_line_f(&sLine_Ht5dOgWg, VOf(Bf3));
    __hv_line_f(&sLine_AryZBwSH, VOf(Bf2));
    __hv_line_f(&sLine_PEKBNvbj, VOf(Bf7));
    __hv_biquad_f(&sBiquad_s_gd8SwpqA, VIf(Bf1), VIf(Bf5), VIf(Bf4), VIf(Bf3), VIf(Bf2), VIf(Bf7), VOf(Bf7));
    __hv_line_f(&sLine_M5MdyXVa, VOf(Bf2));
    __hv_line_f(&sLine_Au4NMxWh, VOf(Bf3));
    __hv_line_f(&sLine_2p9tPAWo, VOf(Bf4));
    __hv_line_f(&sLine_VyxAfLkq, VOf(Bf5));
    __hv_line_f(&sLine_NJMJ9A3T, VOf(Bf8));
    __hv_biquad_f(&sBiquad_s_pd5Vn7tk, VIf(Bf6), VIf(Bf2), VIf(Bf3), VIf(Bf4), VIf(Bf5), VIf(Bf8), VOf(Bf8));
    __hv_line_f(&sLine_nZsHhqQa, VOf(Bf5));
    __hv_line_f(&sLine_XzPyo4Fb, VOf(Bf4));
    __hv_line_f(&sLine_4rPgkFbc, VOf(Bf3));
    __hv_line_f(&sLine_bPD7AoOX, VOf(Bf2));
    __hv_line_f(&sLine_fEPfEfAZ, VOf(Bf6));
    __hv_biquad_f(&sBiquad_s_MgvNYUMf, VIf(Bf7), VIf(Bf5), VIf(Bf4), VIf(Bf3), VIf(Bf2), VIf(Bf6), VOf(Bf6));
    __hv_line_f(&sLine_155H8MeN, VOf(Bf2));
    __hv_line_f(&sLine_qjVZNmDs, VOf(Bf3));
    __hv_line_f(&sLine_maIsr8Jz, VOf(Bf4));
    __hv_line_f(&sLine_A2E1S2eK, VOf(Bf5));
    __hv_line_f(&sLine_YTZ21Ar9, VOf(Bf7));
    __hv_biquad_f(&sBiquad_s_qOAHNAK7, VIf(Bf8), VIf(Bf2), VIf(Bf3), VIf(Bf4), VIf(Bf5), VIf(Bf7), VOf(Bf7));
    __hv_line_f(&sLine_xzYAORI8, VOf(Bf5));
    __hv_line_f(&sLine_jkO3N5Eu, VOf(Bf4));
    __hv_line_f(&sLine_1zbO8QCm, VOf(Bf3));
    __hv_line_f(&sLine_MmTpPFlc, VOf(Bf2));
    __hv_line_f(&sLine_pgDeE4OS, VOf(Bf8));
    __hv_biquad_f(&sBiquad_s_ydhVuJA5, VIf(Bf6), VIf(Bf5), VIf(Bf4), VIf(Bf3), VIf(Bf2), VIf(Bf8), VOf(Bf8));
    __hv_line_f(&sLine_OzcbV3S7, VOf(Bf2));
    __hv_line_f(&sLine_gCEJnBeR, VOf(Bf3));
    __hv_line_f(&sLine_ZckGuuDs, VOf(Bf4));
    __hv_line_f(&sLine_5mGWt5zM, VOf(Bf5));
    __hv_line_f(&sLine_9E0MgvAm, VOf(Bf6));
    __hv_biquad_f(&sBiquad_s_uqPQwIrc, VIf(Bf7), VIf(Bf2), VIf(Bf3), VIf(Bf4), VIf(Bf5), VIf(Bf6), VOf(Bf6));
    __hv_line_f(&sLine_ash1rAvt, VOf(Bf5));
    __hv_line_f(&sLine_DrZuI3C7, VOf(Bf4));
    __hv_line_f(&sLine_21dWG5fr, VOf(Bf3));
    __hv_line_f(&sLine_bmu98AIv, VOf(Bf2));
    __hv_line_f(&sLine_Dg5eZUUB, VOf(Bf7));
    __hv_biquad_f(&sBiquad_s_jmhJ71LR, VIf(Bf8), VIf(Bf5), VIf(Bf4), VIf(Bf3), VIf(Bf2), VIf(Bf7), VOf(Bf7));
    __hv_varread_f(&sVarf_IO2nLrVI, VOf(Bf2));
    __hv_mul_f(VIf(Bf1), VIf(Bf2), VOf(Bf2));
    __hv_varread_f(&sVarf_auxpCdpT, VOf(Bf1));
    __hv_mul_f(VIf(Bf0), VIf(Bf1), VOf(Bf1));
    __hv_varread_f(&sVarf_52RZEkY8, VOf(Bf0));
    __hv_mul_f(VIf(Bf7), VIf(Bf0), VOf(Bf0));
    __hv_varread_f(&sVarf_C4FV78so, VOf(Bf7));
    __hv_mul_f(VIf(Bf6), VIf(Bf7), VOf(Bf7));
    __hv_add_f(VIf(Bf1), VIf(Bf7), VOf(Bf7));
    __hv_add_f(VIf(Bf2), VIf(Bf0), VOf(Bf0));
    __hv_varread_f(&sVarf_W0PxtU51, VOf(Bf2));
    __hv_mul_f(VIf(Bf0), VIf(Bf2), VOf(Bf2));
    __hv_varread_f(&sVarf_8tT1Yfnx, VOf(Bf0));
    __hv_mul_f(VIf(Bf7), VIf(Bf0), VOf(Bf0));
    __hv_add_f(VIf(Bf0), VIf(O0), VOf(O0));
    __hv_add_f(VIf(Bf2), VIf(O1), VOf(O1));

    // save output vars to output buffer
    __hv_store_f(outputBuffers[0]+n, VIf(O0));
    __hv_store_f(outputBuffers[1]+n, VIf(O1));
  }

  blockStartTimestamp = nextBlock;

  return n4; // return the number of frames processed

}

int Heavy_EQXG::processInline(float *inputBuffers, float *outputBuffers, int n4) {
  hv_assert(!(n4 & HV_N_SIMD_MASK)); // ensure that n4 is a multiple of HV_N_SIMD

  // define the heavy input buffer for 2 channel(s)
  float **const bIn = reinterpret_cast<float **>(hv_alloca(2*sizeof(float *)));
  bIn[0] = inputBuffers+(0*n4);
  bIn[1] = inputBuffers+(1*n4);

  // define the heavy output buffer for 2 channel(s)
  float **const bOut = reinterpret_cast<float **>(hv_alloca(2*sizeof(float *)));
  bOut[0] = outputBuffers+(0*n4);
  bOut[1] = outputBuffers+(1*n4);

  int n = process(bIn, bOut, n4);
  return n;
}

int Heavy_EQXG::processInlineInterleaved(float *inputBuffers, float *outputBuffers, int n4) {
  hv_assert(n4 & ~HV_N_SIMD_MASK); // ensure that n4 is a multiple of HV_N_SIMD

  // define the heavy input buffer for 2 channel(s), uninterleave
  float *const bIn = reinterpret_cast<float *>(hv_alloca(2*n4*sizeof(float)));
  #if HV_SIMD_SSE || HV_SIMD_AVX
  for (int i = 0, j = 0; j < n4; j += 4, i += 8) {
    __m128 a = _mm_load_ps(inputBuffers+i);                // LRLR
    __m128 b = _mm_load_ps(inputBuffers+4+i);              // LRLR
    __m128 x = _mm_shuffle_ps(a, b, _MM_SHUFFLE(2,0,2,0)); // LLLL
    __m128 y = _mm_shuffle_ps(a, b, _MM_SHUFFLE(3,1,3,1)); // RRRR
    _mm_store_ps(bIn+j, x);
    _mm_store_ps(bIn+n4+j, y);
  }
  #elif HV_SIMD_NEON
  for (int i = 0, j = 0; j < n4; j += 4, i += 8) {
    float32x4x2_t a = vld2q_f32(inputBuffers+i); // load and uninterleave
    vst1q_f32(bIn+j, a.val[0]);
    vst1q_f32(bIn+n4+j, a.val[1]);
  }
  #else // HV_SIMD_NONE
  for (int j = 0; j < n4; ++j) {
    bIn[0*n4+j] = inputBuffers[0+2*j];
    bIn[1*n4+j] = inputBuffers[1+2*j];
  }
  #endif

  // define the heavy output buffer for 2 channel(s)
  float *const bOut = reinterpret_cast<float *>(hv_alloca(2*n4*sizeof(float)));

  int n = processInline(bIn, bOut, n4);

  // interleave the heavy output into the output buffer
  #if HV_SIMD_AVX
  for (int i = 0, j = 0; j < n4; j += 8, i += 16) {
    __m256 x = _mm256_load_ps(bOut+j);    // LLLLLLLL
    __m256 y = _mm256_load_ps(bOut+n4+j); // RRRRRRRR
    __m256 a = _mm256_unpacklo_ps(x, y);  // LRLRLRLR
    __m256 b = _mm256_unpackhi_ps(x, y);  // LRLRLRLR
    _mm256_store_ps(outputBuffers+i, a);
    _mm256_store_ps(outputBuffers+8+i, b);
  }
  #elif HV_SIMD_SSE
  for (int i = 0, j = 0; j < n4; j += 4, i += 8) {
    __m128 x = _mm_load_ps(bOut+j);    // LLLL
    __m128 y = _mm_load_ps(bOut+n4+j); // RRRR
    __m128 a = _mm_unpacklo_ps(x, y);  // LRLR
    __m128 b = _mm_unpackhi_ps(x, y);  // LRLR
    _mm_store_ps(outputBuffers+i, a);
    _mm_store_ps(outputBuffers+4+i, b);
  }
  #elif HV_SIMD_NEON
  // https://community.arm.com/groups/processors/blog/2012/03/13/coding-for-neon--part-5-rearranging-vectors
  for (int i = 0, j = 0; j < n4; j += 4, i += 8) {
    float32x4_t x = vld1q_f32(bOut+j);
    float32x4_t y = vld1q_f32(bOut+n4+j);
    float32x4x2_t z = {x, y};
    vst2q_f32(outputBuffers+i, z); // interleave and store
  }
  #else // HV_SIMD_NONE
  for (int i = 0; i < 2; ++i) {
    for (int j = 0; j < n4; ++j) {
      outputBuffers[i+2*j] = bOut[i*n4+j];
    }
  }
  #endif

  return n;
}
