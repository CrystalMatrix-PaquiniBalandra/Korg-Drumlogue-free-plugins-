/**
 * Copyright (c) 2026 Enzien Audio, Ltd.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions, and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the phrase "powered by heavy",
 *    the heavy logo, and a hyperlink to https://enzienaudio.com, all in a visible
 *    form.
 * 
 *   2.1 If the Application is distributed in a store system (for example,
 *       the Apple "App Store" or "Google Play"), the phrase "powered by heavy"
 *       shall be included in the app description or the copyright text as well as
 *       the in the app itself. The heavy logo will shall be visible in the app
 *       itself as well.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */

#ifndef _HEAVY_EQXG_H_
#define _HEAVY_EQXG_H_

#include "HvHeavy.h"

#ifdef __cplusplus
extern "C" {
#endif

#if HV_APPLE
#pragma mark - Heavy Context
#endif

typedef enum {
  HV_EQXG_PARAM_IN__10_QLMF_F = 0xFF8E6281, // _10_QLMF_f
  HV_EQXG_PARAM_IN__11_HZLMF = 0x37A5C60F, // _11_HzLMF
  HV_EQXG_PARAM_IN__12_HZLMF2 = 0xD21C13A, // _12_HzLMF2
  HV_EQXG_PARAM_IN__13_DBHMF = 0x98569D43, // _13_dBHMF
  HV_EQXG_PARAM_IN__14_QHMF_F = 0x5B350C53, // _14_QHMF_f
  HV_EQXG_PARAM_IN__15_HZHMF = 0x53BB4812, // _15_HzHMF
  HV_EQXG_PARAM_IN__16_HZHMF2 = 0x5A37DAD4, // _16_HzHMF2
  HV_EQXG_PARAM_IN__17_DBHF = 0x24953B24, // _17_dBHF
  HV_EQXG_PARAM_IN__19_QHF_F = 0x4C756476, // _19_QHF_f
  HV_EQXG_PARAM_IN__1_INPUT = 0x5A63170A, // _1_INPUT
  HV_EQXG_PARAM_IN__20_HZHF = 0x169C2AB2, // _20_HzHF
  HV_EQXG_PARAM_IN__2_DRY = 0x49127601, // _2_DRY
  HV_EQXG_PARAM_IN__3_WET = 0x685033DE, // _3_WET
  HV_EQXG_PARAM_IN__4_OUTPUT = 0xAC813ECB, // _4_OUTPUT
  HV_EQXG_PARAM_IN__5_DBLF = 0x22D96F77, // _5_dBLF
  HV_EQXG_PARAM_IN__7_QLF_F = 0xBFBBD1AA, // _7_QLF_f
  HV_EQXG_PARAM_IN__8_HZLF = 0xA539E829, // _8_HzLF
  HV_EQXG_PARAM_IN__9_DBLMF = 0xBD14ABDA, // _9_dBLMF
} Hv_EQXG_ParameterIn;


/**
 * Creates a new patch instance.
 * Sample rate should be positive and in Hertz, e.g. 44100.0.
 */
HeavyContextInterface *hv_EQXG_new(double sampleRate);

/**
 * Creates a new patch instance.
 * @param sampleRate  Sample rate should be positive (> 0) and in Hertz, e.g. 48000.0.
 * @param poolKb  Pool size is in kilobytes, and determines the maximum amount of memory
 *   allocated to messages at any time. By default this is 10 KB.
 * @param inQueueKb  The size of the input message queue in kilobytes. It determines the
 *   amount of memory dedicated to holding scheduled messages between calls to
 *   process(). Default is 2 KB.
 * @param outQueueKb  The size of the output message queue in kilobytes. It determines the
 *   amount of memory dedicated to holding scheduled messages to the default sendHook.
 *   See getNextSentMessage() for info on accessing these messages. Default is 0 KB.
 */
HeavyContextInterface *hv_EQXG_new_with_options(double sampleRate, int poolKb, int inQueueKb, int outQueueKb);

/**
 * Free the patch instance.
 */
void hv_EQXG_free(HeavyContextInterface *instance);


#ifdef __cplusplus
} // extern "C"
#endif

#endif // _HEAVY_EQXG_H_
