/*
 *  File: header.c
 *
 *  drumlogue unit header definition
 *
 */

#include "unit_drumlogue.h"

#ifndef PROJECT_DEV_ID
 #define PROJECT_DEV_ID (0x0U)
#endif

#ifndef PROJECT_UNIT_ID
 #define PROJECT_UNIT_ID (0x0U)
#endif

const __unit_header drumlogue_unit_header_t unit_header = {
  .common = {
    .header_size = sizeof(unit_header_t),
    .target = UNIT_TARGET_PLATFORM | k_unit_module_delfx,
    .api = UNIT_API_VERSION,
    .dev_id = PROJECT_DEV_ID,
    .unit_id = PROJECT_UNIT_ID,
    .version = 0x00010000U,
    .name = "EQXG",
    .num_params = 20,
    .params = {
        // Format:
        // min, max, center, default, type, frac. bits, frac. mode, <reserved>, name
        // Page 1
        // Page 1
        {-20, 20, 0, 0, k_unit_param_type_none, 0, 0, 0, {"INPUT"}},
        {0, 10, 0, 0, k_unit_param_type_none, 0, 0, 0, {"DRY"}},
        {0, 10, 10, 10, k_unit_param_type_none, 0, 0, 0, {"WET"}},
        {-20, 20, 0, 0, k_unit_param_type_none, 0, 0, 0, {"OUTPUT"}},
        // Page 2
        {-15, 15, 0, 0, k_unit_param_type_none, 0, 0, 0, {"dBLF"}},
        {0, 0, 0, 0, k_unit_param_type_none, 0, 0, 0, {""}},
        {0, 100, 20, 20, k_unit_param_type_strings, 10, 1, 0, {"QLF"}},
        {30, 450, 100, 100, k_unit_param_type_none, 0, 0, 0, {"HzLF"}},
        // Page 3
        {-15, 15, 0, 0, k_unit_param_type_none, 0, 0, 0, {"dBLMF"}},
        {0, 100, 17, 17, k_unit_param_type_strings, 10, 1, 0, {"QLMF"}},
        {200, 2500, 700, 700, k_unit_param_type_none, 0, 0, 0, {"HzLMF"}},
        {65, 830, 700, 700, k_unit_param_type_none, 0, 0, 0, {"HzLMF2"}},
        // Page 4
        {-15, 15, 0, 0, k_unit_param_type_none, 0, 0, 0, {"dBHMF"}},
        {0, 100, 17, 17, k_unit_param_type_strings, 10, 1, 0, {"QHMF"}},
        {600, 7000, 2500, 2500, k_unit_param_type_none, 0, 0, 0, {"HzHMF"}},
        {1800, 21000, 2500, 2500, k_unit_param_type_none, 0, 0, 0, {"HzHMF2"}},
        // Page 5
        {-15, 15, 0, 0, k_unit_param_type_none, 0, 0, 0, {"dBHF"}},
        {0, 0, 0, 0, k_unit_param_type_none, 0, 0, 0, {""}},
        {0, 100, 0, 0, k_unit_param_type_strings, 10, 1, 0, {"QHF"}},
        {1500, 16000, 10000, 10000, k_unit_param_type_none, 0, 0, 0, {"HzHF"}},
        // Page 6
        {0, 0, 0, 0, k_unit_param_type_none, 0, 0, 0, {""}},
        {0, 0, 0, 0, k_unit_param_type_none, 0, 0, 0, {""}},
        {0, 0, 0, 0, k_unit_param_type_none, 0, 0, 0, {""}},
        {0, 0, 0, 0, k_unit_param_type_none, 0, 0, 0, {""}}},
  }
};